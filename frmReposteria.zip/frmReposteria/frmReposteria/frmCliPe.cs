﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace frmReposteria
{
    public partial class frmCliPe : Form
    {
        public frmCliPe()
        {
            InitializeComponent();
        }
        private ArrayList lista = new ArrayList();
        private Pedidos pedi;


        private Boolean siExiste(int idPedidos)
        {
            Boolean existe = false;
            foreach (Pedidos co in lista)
            {
                if (co.IdPedidos == int.Parse(txtIdPedidosP.Text))
                {
                    existe = true;
                }
            }


            return existe;
        }
        private Clientes clie;
        private ArrayList listaC = new ArrayList();
        private Boolean siExistee(int idCliente)
        {
            Boolean existe = false;
            foreach (Clientes co in listaC)
            {
                if (co.IdCliente == int.Parse(txtIdClienteC.Text))
                {
                    existe = true;
                }
            }
            return existe;
        }

        private void btnNuevoE_Click(object sender, EventArgs e)
        {

           
        }

        private void btnGuardarP_Click(object sender, EventArgs e)
        {
           
            
        }

        private void btnModificarP_Click(object sender, EventArgs e)
        {
            
        }

        private void btnBorrarP_Click(object sender, EventArgs e)
        {
            
        }

        private void btnLimpiarP_Click(object sender, EventArgs e)
        {
            

        }

        private void btnCancelarP_Click(object sender, EventArgs e)
        {
            
        }

        private void btnSalirP_Click(object sender, EventArgs e)
        {
           
        }

        private void btnBuscarP_Click(object sender, EventArgs e)
        {
            
            
        }

        private void btnBorrar_Click(object sender, EventArgs e)
        {
            DialogResult res = MessageBox.Show("¿Deseas borrar el registro?", "Clientes ♥",
         MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);

            if (res == DialogResult.Yes)
            {

                listaC.Remove(clie);
                dbgListaC.DataSource = null;
                dbgListaC.DataSource = listaC;
                txtClaveC.Text = "";
                txtIdClienteC.Text = "";
                txtNombreC.Text = "";
                txtCurpC.Text = "";
                txtCorreoC.Text = "";
                txtTelefonoC.Text = "";
                txtApellidoMatC.Text = "";
                txtApellidoPatC.Text = "";
                txtColoniaC.Text = "";
                txtCalleC.Text = "";
                txtNumeroC.Text = "";
                txtCodigoPostC.Text = "";
                cmbStatusC.Text = "";
                txtFotoC.Text = "";
                ptbFotoC.Image = frmReposteria.Properties.Resources.imagen;
                txtNombreC.Enabled = false;
                txtCurpC.Enabled = false;
                txtCorreoC.Enabled = false;
                txtTelefonoC.Enabled = false;
                txtApellidoMatC.Enabled = false;
                txtApellidoPatC.Enabled = false;
                txtColoniaC.Enabled = false;
                txtCalleC.Enabled = false;
                txtNumeroC.Enabled = false;
                txtCodigoPostC.Enabled = false;
                cmbStatusC.Enabled = false;
                txtIdClienteC.Enabled = false;
            }

           
        }

        private void btnNuevoP_Click(object sender, EventArgs e)
        {
            pedi = new Pedidos();
            txtIdPedidosP.Text = pedi.IdPedidos.ToString();
          
            btnGuardarP.Enabled = true;
         
            txtIdPedidosP.Enabled = true;
            txtDescripcionP.Enabled = true;
            dtpFechaP.Enabled = true;
            cmbStatusP.Enabled = true;
            txtAnticipoP.Enabled = true;
            txtClaveP.Enabled = true;

    
   
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtClaveP.Text.Equals("") == true)
            {
                MessageBox.Show("Faltó Capturar la Cable", "Pedidos ♥");
                txtClaveP.Focus();
            }
            else
            {
                Boolean encontro = false;
                foreach (Pedidos pe in lista)
                {
                    if (pe.Clave == int.Parse(txtClaveP.Text))
                    {
                        encontro = true;
                        txtClaveP.Text = pe.Clave.ToString();
                        txtIdPedidosP.Text = pe.IdPedidos.ToString();
                        txtDescripcionP.Text = pe.Descripcion.ToString();
                        txtAnticipoP.Text = pe.Anticipo.ToString();
                        cmbStatusP.Text = pe.StatusP.ToString();
                        dtpFechaP.Value = DateTime.Parse(pe.FechaPedido.ToString());
                        txtIdClienteP.Text = pe.IdCliente.ToString();
                        txtNombreP.Text = pe.Nombre.ToString();
                        txtCurpP.Text = pe.Curp.ToString();
                        txtCorreoP.Text = pe.Correo.ToString();
                        txtTelefonoP.Text = pe.Telefono.ToString();
                        txtApellidoMatP.Text = pe.ApellidoMaterno.ToString();
                        txtApellidoPatP.Text = pe.ApellidoPaterno.ToString();
                        txtColoniaP.Text = pe.Colonia.ToString();
                        txtCalleP.Text = pe.Calle.ToString();
                        txtNumeroP.Text = pe.Numero.ToString();
                        txtCodigoPostP.Text = pe.Cp.ToString();
                        cmbStatusCP.Text = pe.StatusC.ToString();
                        switch (pe.StatusP)
                        {
                            case 1: cmbStatusC.SelectedIndex = 0; break;
                            case 2: cmbStatusC.SelectedIndex = 1; break;

                        }
                        switch (pe.StatusC)
                        {
                            case 1: cmbStatusCP.SelectedIndex = 0; break;
                            case 2: cmbStatusCP.SelectedIndex = 1; break;

                        }
                        btnBorrarP.Enabled = true;
                        btnBuscarP.Enabled = false;
                        btnModificarP.Enabled = true;
                      

                        dtpFechaP.Enabled = true;
                        txtIdPedidosP.Enabled = true;
                        txtDescripcionP.Enabled = true;
                        txtAnticipoP.Enabled = true;
                        cmbStatusP.Enabled = true;


                        pedi = pe;
                        //agregarlo a nivel clase

                        break;
                    }
                }
                
                Boolean encontroo = false;
                foreach (Clientes cl  in listaC)
                {
                    if (cl.Clave == int.Parse(txtClaveP.Text))
                    {
                        encontro = true;
                        txtClaveP.Text = cl.Clave.ToString();
                        txtIdClienteP.Text = cl.IdCliente.ToString();
                        txtNombreP.Text = cl.Nombre.ToString();
                        txtCurpP.Text = cl.Curp.ToString();
                        txtCorreoP.Text = cl.Correo.ToString();
                        txtTelefonoP.Text = cl.Telefono.ToString();
                        txtApellidoMatP.Text = cl.ApellidoMaterno.ToString();
                        txtApellidoPatP.Text = cl.ApellidoPaterno.ToString();
                        txtColoniaP.Text = cl.Colonia.ToString();
                        txtCalleP.Text = cl.Calle.ToString();
                        txtNumeroP.Text = cl.Numero.ToString();
                        txtCodigoPostP.Text = cl.Cp.ToString();
                        txtFotoP.Text = cl.Foto;
                        ptbFotoP.Image = Image.FromFile(txtFotoP.Text);

                        btnModificarP.Enabled = true;
                        btnBorrarP.Enabled = true;
                        switch (cl.StatusC)
                        {
                            case 1: cmbStatusCP.SelectedIndex = 0; break;
                            case 2: cmbStatusCP.SelectedIndex = 1; break;

                        }
                       

                        dtpFechaP.Enabled = true;
                        txtIdPedidosP.Enabled = true;
                        txtDescripcionP.Enabled = true;
                        txtAnticipoP.Enabled = true;
                        cmbStatusP.Enabled = true;


                        
                        //agregarlo a nivel clase

                        break;
                    }if (encontro == false)
                {
                    MessageBox.Show("No se encontró el ID!!", "Pedidos ♥");
                }

                }
                
            }
        }

        private void btnNuevoC_Click(object sender, EventArgs e)
        {
            
            btnGuardarC.Enabled = true;
            clie = new Clientes();
            txtClaveC.Text = clie.Clave.ToString();
            txtIdClienteC.Text = clie.IdCliente.ToString();

            txtClaveC.Enabled = true;
            txtIdClienteC.Enabled = true;
            txtNombreC.Enabled = true;
            txtCurpC.Enabled = true;
            txtCorreoC.Enabled = true;
            txtTelefonoC.Enabled = true;
            txtApellidoMatC.Enabled = true;
            txtApellidoPatC.Enabled = true;
            txtColoniaC.Enabled = true;
            txtCalleC.Enabled = true;
            txtNumeroC.Enabled = true;
            txtCodigoPostC.Enabled = true;
            cmbStatusC.Enabled = true;
        }

        private void btnGuardarC_Click(object sender, EventArgs e)
        {
            Boolean exito = false;
            if (txtIdClienteC.Text.Equals("")) { MessageBox.Show("Faltó capturar el Id Cliente", "Clientes ♥"); exito = true; }
            if (txtNombreC.Text.Equals("")) { MessageBox.Show("Faltó capturar el Nombre", "Clientes ♥"); exito = true; }
            if (txtCurpC.Text.Equals("")) { MessageBox.Show("Faltó capturar el Curp", "Clientes ♥"); exito = true; }
            if (txtCorreoC.Text.Equals("")) { MessageBox.Show("Faltó capturar el Correo", "Clientes ♥"); exito = true; }
            if (txtTelefonoC.Text.Equals("")) { MessageBox.Show("Faltó capturar el Telefono", "Clientes ♥"); exito = true; }
            if (txtApellidoMatC.Text.Equals("")) { MessageBox.Show("Faltó capturar el Apellido Materno", "Clientes ♥"); exito = true; }
            if (txtApellidoPatC.Text.Equals("")) { MessageBox.Show("Faltó capturar el Apellido Paterno", "Clientes ♥"); exito = true; }
            if (txtColoniaC.Text.Equals("")) { MessageBox.Show("Faltó capturar la Colonia", "Clientes ♥"); exito = true; }
            if (txtCalleC.Text.Equals("")) { MessageBox.Show("Faltó capturar la Calle", "Clientes ♥"); exito = true; }
            if (txtNumeroC.Text.Equals("")) { MessageBox.Show("Faltó capturar el Número", "Clientes ♥"); exito = true; }
            if (txtCodigoPostC.Text.Equals("")) { MessageBox.Show("Faltó capturar el Código Postal", "Clientes ♥"); exito = true; }
            if (cmbStatusC.Text.Equals("")) { MessageBox.Show("Faltó capturar el Status", "Clientes ♥"); exito = true; }
            if (txtFotoC.Text.Equals("")) { MessageBox.Show("Faltó capturar la Foto", "Clientes ♥"); exito = true; }
            if (exito == false)
            {
                clie = new Clientes(int.Parse(txtIdClienteC.Text), txtNombreC.Text, txtCurpC.Text, txtCorreoC.Text, txtTelefonoC.Text, txtApellidoMatC.Text, txtApellidoPatC.Text, txtColoniaC.Text, txtCalleC.Text, int.Parse(txtNumeroC.Text), int.Parse(txtCodigoPostC.Text), cmbStatusC.SelectedIndex, txtFotoC.Text, int.Parse (txtClaveC.Text));
                switch (cmbStatusC.SelectedIndex)
                {
                    case 0: clie.StatusC = 1; break;
                    case 1: clie.StatusC = 2; break;
                }
                if (siExistee(int.Parse(txtClaveC.Text)) == false)
                {
                    MessageBox.Show("Se genero el objeto con éxito...", "Clientes ♥");
                    listaC.Add(clie);
                    //paso 3 visualizar el arraylist mediante un
                    dbgListaC.DataSource = null;
                    dbgListaC.DataSource = listaC;

                }

                else
                {
                    MessageBox.Show("Ya ésta uno agregado en la lista....", "Clientes ♥");
                }
               
            }
        }

        private void btnModificarC_Click(object sender, EventArgs e)
        {
            if (!txtClaveC.Text.Equals("")) clie.Clave = int.Parse(txtClaveC.Text);
            if (!txtIdClienteC.Text.Equals("")) clie.IdCliente = int.Parse(txtIdClienteC.Text);
            if (!txtNombreC.Text.Equals("")) clie.Nombre = txtNombreC.Text;
            if (!txtCurpC.Text.Equals("")) clie.Curp = txtCurpC.Text;
            if (!txtCorreoC.Text.Equals("")) clie.Correo = txtCorreoC.Text;
            if (!txtTelefonoC.Text.Equals("")) clie.Telefono = txtTelefonoC.Text;
            if (!txtApellidoMatC.Text.Equals("")) clie.ApellidoMaterno = txtApellidoMatC.Text;
            if (!txtApellidoPatC.Text.Equals("")) clie.ApellidoPaterno = txtApellidoPatC.Text;
            if (!txtColoniaC.Text.Equals("")) clie.Colonia = txtColoniaC.Text;
            if (!txtCalleC.Text.Equals("")) clie.Calle = txtCalleC.Text;
            if (!txtNumeroC.Text.Equals("")) clie.Numero = int.Parse(txtNumeroC.Text);
            if (!txtCodigoPostC.Text.Equals("")) clie.Cp = int.Parse(txtCodigoPostC.Text);
            if (!txtFotoC.Text.Equals("")) clie.Foto = txtFotoC.Text;
            ptbFotoC.Image = Image.FromFile(txtFotoC.Text);
            switch (cmbStatusC.SelectedIndex)
            {
                case 0: clie.StatusC = 1; break;
                case 1: clie.StatusC = 2; break;
            }

            dbgListaC.DataSource = null;
            dbgListaC.DataSource = listaC;
            MessageBox.Show("Se realizó la modificación con éxito!!", "Clientes ♥");
        }

        private void btnCerrarC_Click(object sender, EventArgs e)
        {
            DialogResult clie;
            clie = MessageBox.Show("¿Deseas salir?", "Clientes ♥", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
            if (clie == DialogResult.Yes) this.Close();
        }

        private void btnLimpiarC_Click(object sender, EventArgs e)
        {
            txtIdClienteC.Text = "";
            txtNombreC.Text = "";
            txtCurpC.Text = "";
            txtCorreoC.Text = "";
            txtTelefonoC.Text = "";
            txtApellidoMatC.Text = "";
            txtApellidoPatC.Text = "";
            txtColoniaC.Text = "";
            txtCalleC.Text = "";
            txtNumeroC.Text = "";
            txtCodigoPostC.Text = "";
            txtIdClienteC.Focus(); 
            cmbStatusC.SelectedIndex = -1;
            txtFotoC.Text = "";
            txtClaveC.Text = "";
            ptbFotoC.Image = frmReposteria.Properties.Resources.imagen;

            txtNombreC.Enabled = false;
            txtCurpC.Enabled = false;
            txtCorreoC.Enabled = false;
            txtTelefonoC.Enabled = false;
            txtApellidoMatC.Enabled = false;
            txtApellidoPatC.Enabled = false;
            txtColoniaC.Enabled = false;
            txtCalleC.Enabled = false;
            txtNumeroC.Enabled = false;
            txtCodigoPostC.Enabled = false;
            cmbStatusC.Enabled = false;
            btnBorrarC.Enabled = false;
            btnModificarC.Enabled = false;
            txtIdClienteC.Enabled = false;
            
        }

        private void btnCancelarC_Click(object sender, EventArgs e)
        {
            txtIdClienteC.Text = "";
            txtNombreC.Text = "";
            txtCurpC.Text = "";
            txtCorreoC.Text = "";
            txtTelefonoC.Text = "";
            txtApellidoMatC.Text = "";
            txtApellidoPatC.Text = "";
            txtColoniaC.Text = "";
            txtCalleC.Text = "";
            txtNumeroC.Text = "";
            txtCodigoPostC.Text = "";
            txtIdClienteC.Focus();
            cmbStatusC.SelectedIndex = -1;
            ptbFotoC.Image = frmReposteria.Properties.Resources.imagen;
            txtFotoC.Text = "";
            btnModificarC.Enabled = false;
            btnBorrarC.Enabled = false;
            btnGuardarC.Enabled = false;

            txtIdClienteC.Enabled = false;
            txtNombreC.Enabled = false;
            txtCurpC.Enabled = false;
            txtCorreoC.Enabled = false;
            txtTelefonoC.Enabled = false;
            txtApellidoMatC.Enabled = false;
            txtApellidoPatC.Enabled = false;
            txtColoniaC.Enabled = false;
            txtCalleC.Enabled = false;
            txtNumeroC.Enabled = false;
            txtCodigoPostC.Enabled = false;
            cmbStatusC.Enabled = false;
        }

        private void btnBuscarC_Click(object sender, EventArgs e) 
        {
            if (txtClaveC.Text.Equals("") == true)
            {
                MessageBox.Show("Faltó capturar el número de clave Cliente", "Clientes ♥");
                txtClaveC.Focus();
            }
            else
            {
                Boolean encontro = false;
                foreach (Clientes cli in listaC)
                {

                    if (cli.Clave == int.Parse(txtClaveC.Text))
                    {
                        encontro = true;
                        //mostrar informacion
                        txtClaveC.Text = cli.Clave.ToString();
                        txtIdClienteC.Text = cli.IdCliente.ToString();
                        txtNombreC.Text = cli.Nombre.ToString();
                        txtCurpC.Text = cli.Curp.ToString();
                        txtCorreoC.Text = cli.Correo.ToString();
                        txtTelefonoC.Text = cli.Telefono.ToString();
                        txtApellidoMatC.Text = cli.ApellidoMaterno.ToString();
                        txtApellidoPatC.Text = cli.ApellidoPaterno.ToString();
                        txtColoniaC.Text = cli.Colonia.ToString();
                        txtCalleC.Text = cli.Calle.ToString();
                        txtNumeroC.Text = cli.Numero.ToString();
                        txtCodigoPostC.Text = cli.Cp.ToString();
                        txtFotoC.Text = cli.Foto;
                        ptbFotoC.Image = Image.FromFile(txtFotoC.Text);

                        btnModificarC.Enabled = true;
                        txtNombreC.Enabled = true;
                        txtCurpC.Enabled = true;
                        txtCorreoC.Enabled = true;
                        txtTelefonoC.Enabled = true;
                        txtApellidoMatC.Enabled = true;
                        txtApellidoPatC.Enabled = true;
                        txtColoniaC.Enabled = true;
                        txtCalleC.Enabled = true;
                        txtNumeroC.Enabled = true;
                        txtCodigoPostC.Enabled = true;
                        cmbStatusC.Enabled = true;
                        txtIdClienteC.Enabled = true;
                        clie = cli;
                        btnBorrarC.Enabled = true;
                        btnModificarC.Enabled = true;
                        btnBuscarC.Enabled = false;
                        switch (cli.StatusC)
                        {
                            case 1: cmbStatusC.SelectedIndex = 0; break;
                            case 2: cmbStatusC.SelectedIndex = 1; break;

                        }
                        break;
                    }
                }

                if (encontro == false)
                {
                    MessageBox.Show("No se encontró la Clave!!", "Clientes ♥");
                }
            }

        }

        private void btnGuardarP_Click_1(object sender, EventArgs e)
        {
            Boolean exito = false;
            if (txtClaveP.Text.Equals("")) { MessageBox.Show("Faltó Capturar el anticipo", "Pedidos ♥"); exito = true; }
            if (txtIdPedidosP.Text.Equals("")) { MessageBox.Show("Faltó Capturar el Id Pedido", "Pedidos ♥"); exito = true; }
            if (txtDescripcionP.Text.Equals("")) { MessageBox.Show("Faltó capturar la descripción", "Pedidos ♥"); exito = true; }
            if (cmbStatusP.Text.Equals("")) { MessageBox.Show("Faltó Capturar el status", "Pedidos ♥"); exito = true; }
            if (dtpFechaP.Text.Equals("")) { MessageBox.Show("Faltó capturar la fecha", "Pedidos ♥"); exito = true; }
            if (txtAnticipoP.Text.Equals("")) { MessageBox.Show("Faltó Capturar el anticipo", "Pedidos ♥"); exito = true; }

            if (exito == false)
            {
                pedi = new Pedidos(int.Parse(txtIdClienteP.Text), txtNombreP.Text, txtCurpP.Text, txtCorreoP.Text, txtTelefonoP.Text, txtApellidoMatP.Text, txtApellidoPatP.Text, txtColoniaP.Text, txtCalleP.Text, int.Parse(txtNumeroP.Text), int.Parse(txtCodigoPostP.Text), cmbStatusCP.SelectedIndex,txtFotoP.Text, int.Parse(txtClaveP.Text), int.Parse(txtIdPedidosP.Text), txtDescripcionP.Text, dtpFechaP.Value.ToString(), cmbStatusP.SelectedIndex, float.Parse(txtAnticipoP.Text));
                switch (cmbStatusCP.SelectedIndex)
                {
                    case 0: pedi.StatusC = 1; break;
                    case 1: pedi.StatusC = 2; break;
                }
                switch (cmbStatusP.SelectedIndex)
                {
                    case 0: pedi.StatusP = 1; break;
                    case 1: pedi.StatusP = 2; break;
                }

                if (siExiste(int.Parse(txtIdPedidosP.Text)) == false)
                {
                    //agregar el objeto a la lista
                    lista.Add(pedi);
                    //relacionar la lista con el dgv
                    dgvListaP.DataSource = null;
                    dgvListaP.DataSource = lista;


                    MessageBox.Show("El objeto se construyó con éxito...", "Pedidos ♥");

                }
                else
                {
                    MessageBox.Show("Ya está uno agregado en la lista...", "Pedidos ♥");
                }
            }
        }

        private void btnModificarP_Click_1(object sender, EventArgs e)
        {
            if (!txtClaveP.Text.Equals("")) pedi.Clave = int.Parse(txtClaveP.Text);
            if (!txtIdPedidosP.Text.Equals("")) pedi.IdPedidos = int.Parse(txtIdPedidosP.Text);
            if (!txtDescripcionP.Text.Equals("")) pedi.Descripcion = txtDescripcionP.Text;
            
            pedi.FechaPedido = dtpFechaP.Value.ToString();
            if (!txtAnticipoP.Text.Equals("")) pedi.Anticipo = float.Parse(txtAnticipoP.Text);
            switch (cmbStatusP.SelectedIndex)
            {
                case 0: pedi.StatusP = 1; break;
                case 1: pedi.StatusP = 2; break;
            }



            dgvListaP.DataSource = null;
            dgvListaP.DataSource = lista;
            MessageBox.Show("Se Realizó La Modificación", "Pedidos ♥");
        }

        private void btnBorrarP_Click_1(object sender, EventArgs e)
        {
            DialogResult tip = MessageBox.Show("¿Deseas Borrar el registro?", "Pedidos ♥",
            MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
            if (tip == DialogResult.Yes)
            {
                lista.Remove(pedi);
                dgvListaP.DataSource = null;
                dgvListaP.DataSource = lista;
                txtIdPedidosP.Text = "";

                ptbFotoP.Image = frmReposteria.Properties.Resources.imagen;
                
                txtDescripcionP.Text = "";
                dtpFechaP.Value = DateTime.Now;
                txtAnticipoP.Text = "";
                txtAnticipoP.Enabled = false;
                dtpFechaP.Enabled = false;
                txtDescripcionP.Enabled = false;
                cmbStatusP.Enabled = false;
                txtIdClienteP.Text = "";
                txtNombreP.Text = "";
                txtCurpP.Text = "";
                txtCorreoP.Text = "";
                txtTelefonoP.Text = "";
                txtApellidoMatP.Text = "";
                txtApellidoPatP.Text = "";
                txtColoniaP.Text = "";
                txtCalleP.Text = "";
                txtNumeroP.Text = "";
                txtCodigoPostP.Text = "";
                txtIdClienteP.Focus();
                cmbStatusP.SelectedIndex = -1;
                cmbStatusC.SelectedIndex = -1;
                txtFotoP.Text = "";
                txtClaveP.Text = "";

            }
        }

        private void btnLimpiarP_Click_1(object sender, EventArgs e)
        {
            txtIdPedidosP.Text = "";
           
            txtDescripcionP.Text = "";
            dtpFechaP.Value = DateTime.Now;
            txtAnticipoP.Text = "";

            txtClaveP.Text = "";
            txtIdClienteP.Text = "";
            txtNombreP.Text = "";
            txtCurpP.Text = "";
            txtCorreoP.Text = "";
            txtTelefonoP.Text = "";
            txtApellidoMatP.Text = "";
            txtApellidoPatP.Text = "";
            txtColoniaP.Text = "";
            txtCalleP.Text = "";
            txtNumeroP.Text = "";
            txtCodigoPostP.Text = "";
            txtIdClienteP.Focus();
            cmbStatusP.SelectedIndex = -1;
            cmbStatusCP.SelectedIndex = -1;
            txtFotoP.Text = "";
            ptbFotoP.Image = frmReposteria.Properties.Resources.imagen;
            btnBorrarP.Enabled = false;
            btnModificarP.Enabled = false;
        }

        private void btnCancelarP_Click_1(object sender, EventArgs e)
        {
            txtIdPedidosP.Text = "";
            txtClaveP.Text = "";
            cmbStatusP.Text = "";
            txtDescripcionP.Text = "";
            dtpFechaP.Value = DateTime.Now;
            txtAnticipoP.Text = "";
            txtIdClienteP.Text = "";
            txtNombreP.Text = "";
            txtCurpP.Text = "";
            txtCorreoP.Text = "";
            txtTelefonoP.Text = "";
            txtApellidoMatP.Text = "";
            txtApellidoPatP.Text = "";
            txtColoniaP.Text = "";
            txtCalleP.Text = "";
            txtNumeroP.Text = "";
            txtCodigoPostP.Text = "";
            

            txtIdClienteC.Focus();
            cmbStatusCP.SelectedIndex = -1;
            ptbFotoC.Image = frmReposteria.Properties.Resources.imagen;
            txtFotoC.Text = "";
            txtClaveP.Enabled = false;
            txtIdClienteP.Enabled = false;
            txtIdPedidosP.Enabled = false;
            txtAnticipoP.Enabled = false;
            dtpFechaP.Enabled = true;
            txtDescripcionP.Enabled = false;
            cmbStatusP.Enabled = false;
            btnBorrarP.Enabled = false;
            btnModificarP.Enabled = false;
            btnGuardarP.Enabled = false;
        }

        private void btnSalirP_Click_1(object sender, EventArgs e)
        {
            DialogResult tipo;
            tipo = MessageBox.Show("¿Deseas Salir?", "Pedidos ♥",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question,
                MessageBoxDefaultButton.Button2);
            if (tipo == DialogResult.Yes) this.Close();
        }

        private void txtIdClienteC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void txtNumeroC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void txtCodigoPostC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void cmbStatusC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void txtIdClienteP_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void txtTelefonoP_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtTelefonoP_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void txtNumeroP_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void txtCodigoPostP_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void cmbStatusCP_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void txtIdPedidosP_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void cmbStatusP_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void txtAnticipoP_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            OpenFileDialog foto = new OpenFileDialog(); 
            foto.InitialDirectory = "C:\\";
            foto.ShowDialog();
            txtFotoC.Text = foto.FileName;
            ptbFotoC.ImageLocation = foto.FileName;
            


        }

        private void txtTelefonoC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }

        private void btnFotoP_Click(object sender, EventArgs e)
        {

        }

        private void txtClaveC_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtClaveP_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void txtClaveC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }
    }
}
