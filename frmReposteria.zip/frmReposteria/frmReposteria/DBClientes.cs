﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;
namespace frmReposteria
{
    class DBClientes
    {
        private MySqlConnection conexion;
        private string strConexion;
        private MySqlCommand sqlComando;
        private string strConsulta;
        private MySqlDataAdapter adaptador;

        public DBClientes()
        {
            //Constructor
            conexion = new MySqlConnection();
            strConexion = "Server=localHost;User=root;DataBase=bdreposteria;port=3306;Password=";

            conexion.ConnectionString = strConexion;

            sqlComando = new MySqlCommand();
            adaptador = new MySqlDataAdapter();

        }
        public Boolean Abrir()
        {
            Boolean exito = false;

            if (conexion.State == System.Data.ConnectionState.Closed)
            {

                conexion.Open();
                exito = true;

            }


            return exito;
        }

        public Boolean Cerrar()
        {
            Boolean exito = false;

            if (conexion.State == System.Data.ConnectionState.Closed)
            {

                exito = false;
            }
            else
            {
                conexion.Close();
                exito = true;
            }
            return exito;
        }
        // public Boolean Cerrar()
        // {
        //    Boolean exito = false;
        //    if (conexion.State == ConnectionState.Closed)
        //    {
        //    conexion.Close();
        //   exito = true;
        // }
        // return exito;
        // }

        //Agregar sin parametros
        // public void agregarSinParsametros(Clientes obj)
        //{
        //    string sqlConsulta = "insert into Clientes (codigo,nombre,status) values (null," + obj.Clave + "," + obj.Nombre + ",0)";
        //    this.abrir();
        //    sqlComando.Connection = conexion;
        //    sqlComando.CommandText = sqlConsulta;

        //    sqlComando.ExecuteNonQuery();
        //    this.Cerrar();
        //}


        //AGREGAR USANDO PARAMETRO
        public void agregarUsandoParametros(Clientes obj)
        {
            string sqlConsulta = "insert into tclientes (idCliente,clave,nombre,aMaterno,aPaterno,telefono,correo,curp,codigoPostal,numeroCasa,calle,colonia,foto,status)values(null, ?pclave,?pnombre,?paMaterno,?paPaterno,?ptelefono,?pcorreo,?pcurp,?pcodigoPostal,?pnumeroCasa,?pcalle,?pcolonia,?pfoto,0)";
            sqlComando.Parameters.Clear();

            sqlComando.Parameters.Add("?pnombre", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Nombre;
            sqlComando.Parameters.Add("?pcurp", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Curp;
            sqlComando.Parameters.Add("?pcorreo", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Correo;
            sqlComando.Parameters.Add("?ptelefono", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Telefono;
            sqlComando.Parameters.Add("?paMaterno", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.ApellidoMaterno;
            sqlComando.Parameters.Add("?paPaterno", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.ApellidoPaterno;
            sqlComando.Parameters.Add("?pcolonia", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Colonia;
            sqlComando.Parameters.Add("?pcalle", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Calle;
            sqlComando.Parameters.Add("?pnumeroCasa", MySql.Data.MySqlClient.MySqlDbType.Int32).Value = obj.Numero;
            sqlComando.Parameters.Add("?pcodigoPostal", MySql.Data.MySqlClient.MySqlDbType.Int32).Value = obj.Cp;
            sqlComando.Parameters.Add("?pfoto", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Foto;
            sqlComando.Parameters.Add("?pclave", MySql.Data.MySqlClient.MySqlDbType.Int32).Value = obj.Clave;


            this.Abrir();
            sqlComando.Connection = conexion;
            sqlComando.CommandText = sqlConsulta;

            sqlComando.ExecuteNonQuery();
            this.Cerrar();

        }
        //ACTUALIZAR
        public void Actualizar(Clientes obj)
        {
            string sqlConsulta = "Update tclientes set nombre= ?pnombre,aPaterno=?paPaterno,aMaterno=?paMaterno,telefono=?ptelefono,correo=?pcorreo, curp = ?pcurp,codigoPostal=?pcodigoPostal,numeroCasa=?pnumeroCasa,calle=?pcalle,colonia=?pcolonia,foto=?pfoto where clave= ?pclave and status=0";
            sqlComando.Parameters.Clear();

            sqlComando.Parameters.Add("?pclave", MySql.Data.MySqlClient.MySqlDbType.UInt32).Value = obj.Clave;
            sqlComando.Parameters.Add("?pnombre", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Nombre;
            sqlComando.Parameters.Add("?pcurp", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Clave;
            sqlComando.Parameters.Add("?pcorreo", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Correo;
            sqlComando.Parameters.Add("?ptelefono", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Telefono;
            sqlComando.Parameters.Add("?paMaterno", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.ApellidoMaterno;
            sqlComando.Parameters.Add("?paPaterno", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.ApellidoPaterno;
            sqlComando.Parameters.Add("?pcolonia", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Colonia;
            sqlComando.Parameters.Add("?pcalle", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Calle;
            sqlComando.Parameters.Add("?pnumeroCasa", MySql.Data.MySqlClient.MySqlDbType.Int32).Value = obj.Numero;
            sqlComando.Parameters.Add("?pcodigoPostal", MySql.Data.MySqlClient.MySqlDbType.Int32).Value = obj.Cp;
            sqlComando.Parameters.Add("?pfoto", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Foto;
            

            this.Abrir();
            sqlComando.Connection = conexion;
            sqlComando.CommandText = sqlConsulta;

            sqlComando.ExecuteNonQuery();
            this.Cerrar();
        }

        //DESHABILITAR 
        public void Deshabilitar(Clientes obj)
        {
            string sqlConsulta = "update tclientes set status=1 where clave= ?pclave and status=0";
            sqlComando.Parameters.Clear();

            sqlComando.Parameters.Add("?pclave", MySql.Data.MySqlClient.MySqlDbType.Int32).Value = obj.Clave;

            this.Abrir();
            sqlComando.Connection = conexion;
            sqlComando.CommandText = sqlConsulta;

            sqlComando.ExecuteNonQuery();
            this.Cerrar();

        }

        //Consultar
        public DataTable Consultar(int Clave)
        {
            DataTable datos = new DataTable();
            strConsulta = "select * from tclientes where status = 0 and clave =" + Clave;

            this.Abrir();
            sqlComando.CommandText = strConsulta;
            sqlComando.Connection = conexion;
            adaptador.SelectCommand = sqlComando;
            adaptador.Fill(datos);

            this.Cerrar();

            return datos;
        }
        //Metodo consultar todos
        public DataTable ConsultarTodos()
        {
            DataTable datos = new DataTable();
            strConsulta = "select *from tclientes where status = 0 order by clave asc";
            Abrir();
            sqlComando.CommandText = strConsulta;
            sqlComando.Connection = conexion;

            adaptador.SelectCommand = sqlComando;
            adaptador.Fill(datos);
            Cerrar();
            return datos;
        }
        public DataTable ConsultarTodosDeshabilitar()
        {
            DataTable datos = new DataTable();
            strConsulta = "select *from tclientes where status = 1 order by clave asc";
            Abrir();
            sqlComando.CommandText = strConsulta;
            sqlComando.Connection = conexion;

            adaptador.SelectCommand = sqlComando;
            adaptador.Fill(datos);
            Cerrar();
            return datos;
        }
        public void Habilitar(Clientes obj)
        {
            string sqlConsulta = "update tclientes set status=0 where clave = ?pclave and status = 1";
            sqlComando.Parameters.Clear();

            sqlComando.Parameters.Add("?pclave", MySql.Data.MySqlClient.MySqlDbType.Int32).Value = obj.Clave;

            this.Abrir();
            sqlComando.Connection = conexion;
            sqlComando.CommandText = sqlConsulta;

            sqlComando.ExecuteNonQuery();
            this.Cerrar();
        }
        public DataTable ConsultarH(int Clave)
        {
            DataTable datos = new DataTable();
            strConsulta = "select * from tclientes where status = 1 and clave =" + Clave;

            this.Abrir();
            sqlComando.CommandText = strConsulta;
            sqlComando.Connection = conexion;
            adaptador.SelectCommand = sqlComando;
            adaptador.Fill(datos);

            this.Cerrar();

            return datos;
        }
        public DataTable ConsultarTodos5()
        {
            DataTable datos = new DataTable();
            strConsulta = "select *from tclientes where status = 0 order by clave asc";
            Abrir();
            sqlComando.CommandText = strConsulta;
            sqlComando.Connection = conexion;

            adaptador.SelectCommand = sqlComando;
            adaptador.Fill(datos);
            Cerrar();
            return datos;
        }
    }
}
