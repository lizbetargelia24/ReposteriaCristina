﻿namespace frmReposteria
{
    partial class frmCompras
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cmbTipoPagoC = new System.Windows.Forms.ComboBox();
            this.cmbTiendaC = new System.Windows.Forms.ComboBox();
            this.cmbEmpleadoC = new System.Windows.Forms.ComboBox();
            this.txtFolioCompraC = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnNuevoV = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dtpFechaC = new System.Windows.Forms.DateTimePicker();
            this.btnBuscarC = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtCantidadC = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtTotalCompraC = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtPrecioCompraC = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.cmbProductoC = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtCodigoC = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnRealizarCompraC = new System.Windows.Forms.Button();
            this.dgvListaC = new System.Windows.Forms.DataGridView();
            this.btnCancelarC = new System.Windows.Forms.Button();
            this.btnGuardarC = new System.Windows.Forms.Button();
            this.btnLimpiarC = new System.Windows.Forms.Button();
            this.btnBorrarC = new System.Windows.Forms.Button();
            this.btnSalirC = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaC)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.cmbTipoPagoC);
            this.groupBox1.Controls.Add(this.cmbTiendaC);
            this.groupBox1.Controls.Add(this.cmbEmpleadoC);
            this.groupBox1.Controls.Add(this.txtFolioCompraC);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.btnNuevoV);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.dtpFechaC);
            this.groupBox1.Controls.Add(this.btnBuscarC);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(790, 217);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Compra";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label5.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label5.Location = new System.Drawing.Point(239, 80);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 16);
            this.label5.TabIndex = 32;
            this.label5.Text = "Tipo de Pago";
            // 
            // cmbTipoPagoC
            // 
            this.cmbTipoPagoC.Enabled = false;
            this.cmbTipoPagoC.FormattingEnabled = true;
            this.cmbTipoPagoC.Location = new System.Drawing.Point(242, 104);
            this.cmbTipoPagoC.Name = "cmbTipoPagoC";
            this.cmbTipoPagoC.Size = new System.Drawing.Size(121, 24);
            this.cmbTipoPagoC.TabIndex = 5;
            // 
            // cmbTiendaC
            // 
            this.cmbTiendaC.Enabled = false;
            this.cmbTiendaC.FormattingEnabled = true;
            this.cmbTiendaC.Location = new System.Drawing.Point(19, 167);
            this.cmbTiendaC.Name = "cmbTiendaC";
            this.cmbTiendaC.Size = new System.Drawing.Size(121, 24);
            this.cmbTiendaC.TabIndex = 3;
            // 
            // cmbEmpleadoC
            // 
            this.cmbEmpleadoC.Enabled = false;
            this.cmbEmpleadoC.FormattingEnabled = true;
            this.cmbEmpleadoC.Location = new System.Drawing.Point(19, 109);
            this.cmbEmpleadoC.Name = "cmbEmpleadoC";
            this.cmbEmpleadoC.Size = new System.Drawing.Size(121, 24);
            this.cmbEmpleadoC.TabIndex = 2;
            // 
            // txtFolioCompraC
            // 
            this.txtFolioCompraC.Enabled = false;
            this.txtFolioCompraC.Location = new System.Drawing.Point(19, 53);
            this.txtFolioCompraC.MaxLength = 10;
            this.txtFolioCompraC.Name = "txtFolioCompraC";
            this.txtFolioCompraC.Size = new System.Drawing.Size(116, 23);
            this.txtFolioCompraC.TabIndex = 1;
            this.txtFolioCompraC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFolioCompraC_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label4.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label4.Location = new System.Drawing.Point(16, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(93, 16);
            this.label4.TabIndex = 28;
            this.label4.Text = "Folio de compra";
            // 
            // btnNuevoV
            // 
            this.btnNuevoV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnNuevoV.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNuevoV.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNuevoV.Image = global::frmReposteria.Properties.Resources.agregar_usuario;
            this.btnNuevoV.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNuevoV.Location = new System.Drawing.Point(614, 39);
            this.btnNuevoV.Name = "btnNuevoV";
            this.btnNuevoV.Size = new System.Drawing.Size(120, 57);
            this.btnNuevoV.TabIndex = 15;
            this.btnNuevoV.Text = "Nueva Compra";
            this.btnNuevoV.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNuevoV.UseVisualStyleBackColor = false;
            this.btnNuevoV.Click += new System.EventHandler(this.btnNuevoV_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label3.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3.Location = new System.Drawing.Point(239, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 16);
            this.label3.TabIndex = 23;
            this.label3.Text = "Fecha";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label2.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.Location = new System.Drawing.Point(15, 141);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 16);
            this.label2.TabIndex = 20;
            this.label2.Text = "Tienda";
            // 
            // dtpFechaC
            // 
            this.dtpFechaC.Enabled = false;
            this.dtpFechaC.Location = new System.Drawing.Point(242, 50);
            this.dtpFechaC.Name = "dtpFechaC";
            this.dtpFechaC.Size = new System.Drawing.Size(233, 23);
            this.dtpFechaC.TabIndex = 4;
            // 
            // btnBuscarC
            // 
            this.btnBuscarC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnBuscarC.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBuscarC.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscarC.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBuscarC.Location = new System.Drawing.Point(143, 21);
            this.btnBuscarC.Name = "btnBuscarC";
            this.btnBuscarC.Size = new System.Drawing.Size(39, 25);
            this.btnBuscarC.TabIndex = 21;
            this.btnBuscarC.Text = "<<";
            this.btnBuscarC.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnBuscarC.UseVisualStyleBackColor = false;
            this.btnBuscarC.Click += new System.EventHandler(this.btnBuscarC_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(15, 85);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 16);
            this.label1.TabIndex = 13;
            this.label1.Text = "Empleado";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox2.Controls.Add(this.txtCantidadC);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.txtTotalCompraC);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.txtPrecioCompraC);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.cmbProductoC);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.txtCodigoC);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.btnRealizarCompraC);
            this.groupBox2.Controls.Add(this.dgvListaC);
            this.groupBox2.Controls.Add(this.btnCancelarC);
            this.groupBox2.Controls.Add(this.btnGuardarC);
            this.groupBox2.Controls.Add(this.btnLimpiarC);
            this.groupBox2.Controls.Add(this.btnBorrarC);
            this.groupBox2.Controls.Add(this.btnSalirC);
            this.groupBox2.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(12, 250);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(790, 289);
            this.groupBox2.TabIndex = 28;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Detalle Compra";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // txtCantidadC
            // 
            this.txtCantidadC.Enabled = false;
            this.txtCantidadC.Location = new System.Drawing.Point(332, 78);
            this.txtCantidadC.MaxLength = 10;
            this.txtCantidadC.Name = "txtCantidadC";
            this.txtCantidadC.Size = new System.Drawing.Size(116, 23);
            this.txtCantidadC.TabIndex = 8;
            this.txtCantidadC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCantidadC_KeyPress);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label13.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label13.Location = new System.Drawing.Point(242, 85);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(53, 16);
            this.label13.TabIndex = 46;
            this.label13.Text = "Cantidad";
            // 
            // txtTotalCompraC
            // 
            this.txtTotalCompraC.Enabled = false;
            this.txtTotalCompraC.Location = new System.Drawing.Point(646, 47);
            this.txtTotalCompraC.MaxLength = 10;
            this.txtTotalCompraC.Name = "txtTotalCompraC";
            this.txtTotalCompraC.Size = new System.Drawing.Size(116, 23);
            this.txtTotalCompraC.TabIndex = 39;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label10.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label10.Location = new System.Drawing.Point(556, 54);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(80, 16);
            this.label10.TabIndex = 40;
            this.label10.Text = "Total Compra";
            // 
            // txtPrecioCompraC
            // 
            this.txtPrecioCompraC.Enabled = false;
            this.txtPrecioCompraC.Location = new System.Drawing.Point(332, 49);
            this.txtPrecioCompraC.MaxLength = 10;
            this.txtPrecioCompraC.Name = "txtPrecioCompraC";
            this.txtPrecioCompraC.Size = new System.Drawing.Size(116, 23);
            this.txtPrecioCompraC.TabIndex = 7;
            this.txtPrecioCompraC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPrecioCompraC_KeyPress);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label9.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label9.Location = new System.Drawing.Point(242, 56);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(84, 16);
            this.label9.TabIndex = 36;
            this.label9.Text = "Precio Compra";
            // 
            // cmbProductoC
            // 
            this.cmbProductoC.Enabled = false;
            this.cmbProductoC.FormattingEnabled = true;
            this.cmbProductoC.Location = new System.Drawing.Point(327, 20);
            this.cmbProductoC.Name = "cmbProductoC";
            this.cmbProductoC.Size = new System.Drawing.Size(121, 24);
            this.cmbProductoC.TabIndex = 6;
            this.cmbProductoC.SelectedIndexChanged += new System.EventHandler(this.comboBox4_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label7.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label7.Location = new System.Drawing.Point(242, 28);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(54, 16);
            this.label7.TabIndex = 31;
            this.label7.Text = "Producto";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // txtCodigoC
            // 
            this.txtCodigoC.Enabled = false;
            this.txtCodigoC.Location = new System.Drawing.Point(11, 52);
            this.txtCodigoC.MaxLength = 10;
            this.txtCodigoC.Name = "txtCodigoC";
            this.txtCodigoC.Size = new System.Drawing.Size(116, 23);
            this.txtCodigoC.TabIndex = 29;
            this.txtCodigoC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCodigoC_KeyPress);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label6.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label6.Location = new System.Drawing.Point(11, 31);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(42, 16);
            this.label6.TabIndex = 30;
            this.label6.Text = "Codigo";
            // 
            // btnRealizarCompraC
            // 
            this.btnRealizarCompraC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnRealizarCompraC.Enabled = false;
            this.btnRealizarCompraC.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRealizarCompraC.Font = new System.Drawing.Font("Comic Sans MS", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRealizarCompraC.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRealizarCompraC.Location = new System.Drawing.Point(614, 137);
            this.btnRealizarCompraC.Name = "btnRealizarCompraC";
            this.btnRealizarCompraC.Size = new System.Drawing.Size(120, 67);
            this.btnRealizarCompraC.TabIndex = 28;
            this.btnRealizarCompraC.Text = "Realizar la Compra";
            this.btnRealizarCompraC.UseVisualStyleBackColor = false;
            this.btnRealizarCompraC.Click += new System.EventHandler(this.btnRealizarCompraC_Click);
            // 
            // dgvListaC
            // 
            this.dgvListaC.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.dgvListaC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvListaC.Location = new System.Drawing.Point(11, 125);
            this.dgvListaC.Name = "dgvListaC";
            this.dgvListaC.Size = new System.Drawing.Size(540, 100);
            this.dgvListaC.TabIndex = 26;
            // 
            // btnCancelarC
            // 
            this.btnCancelarC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnCancelarC.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCancelarC.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelarC.Image = global::frmReposteria.Properties.Resources.prohibido__1_;
            this.btnCancelarC.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCancelarC.Location = new System.Drawing.Point(104, 235);
            this.btnCancelarC.Name = "btnCancelarC";
            this.btnCancelarC.Size = new System.Drawing.Size(91, 39);
            this.btnCancelarC.TabIndex = 26;
            this.btnCancelarC.Text = "Cancelar";
            this.btnCancelarC.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCancelarC.UseVisualStyleBackColor = false;
            this.btnCancelarC.Click += new System.EventHandler(this.btnCancelarC_Click);
            // 
            // btnGuardarC
            // 
            this.btnGuardarC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnGuardarC.Enabled = false;
            this.btnGuardarC.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnGuardarC.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGuardarC.Image = global::frmReposteria.Properties.Resources.guardar2;
            this.btnGuardarC.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGuardarC.Location = new System.Drawing.Point(557, 129);
            this.btnGuardarC.Name = "btnGuardarC";
            this.btnGuardarC.Size = new System.Drawing.Size(34, 44);
            this.btnGuardarC.TabIndex = 9;
            this.btnGuardarC.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnGuardarC.UseVisualStyleBackColor = false;
            this.btnGuardarC.Click += new System.EventHandler(this.btnGuardarC_Click);
            // 
            // btnLimpiarC
            // 
            this.btnLimpiarC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnLimpiarC.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnLimpiarC.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpiarC.Image = global::frmReposteria.Properties.Resources.escoba_de_limpieza_para_suelos__1_;
            this.btnLimpiarC.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLimpiarC.Location = new System.Drawing.Point(10, 235);
            this.btnLimpiarC.Name = "btnLimpiarC";
            this.btnLimpiarC.Size = new System.Drawing.Size(87, 39);
            this.btnLimpiarC.TabIndex = 24;
            this.btnLimpiarC.Text = "Limpiar";
            this.btnLimpiarC.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLimpiarC.UseVisualStyleBackColor = false;
            this.btnLimpiarC.Click += new System.EventHandler(this.btnLimpiarC_Click);
            // 
            // btnBorrarC
            // 
            this.btnBorrarC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnBorrarC.Enabled = false;
            this.btnBorrarC.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBorrarC.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBorrarC.Image = global::frmReposteria.Properties.Resources.cubo_de_basura;
            this.btnBorrarC.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBorrarC.Location = new System.Drawing.Point(557, 179);
            this.btnBorrarC.Name = "btnBorrarC";
            this.btnBorrarC.Size = new System.Drawing.Size(34, 36);
            this.btnBorrarC.TabIndex = 25;
            this.btnBorrarC.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBorrarC.UseVisualStyleBackColor = false;
            this.btnBorrarC.Click += new System.EventHandler(this.btnBorrarC_Click);
            // 
            // btnSalirC
            // 
            this.btnSalirC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnSalirC.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSalirC.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalirC.Image = global::frmReposteria.Properties.Resources.salir_3;
            this.btnSalirC.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSalirC.Location = new System.Drawing.Point(202, 235);
            this.btnSalirC.Name = "btnSalirC";
            this.btnSalirC.Size = new System.Drawing.Size(70, 39);
            this.btnSalirC.TabIndex = 27;
            this.btnSalirC.Text = "Salir";
            this.btnSalirC.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSalirC.UseVisualStyleBackColor = false;
            this.btnSalirC.Click += new System.EventHandler(this.btnSalirC_Click);
            // 
            // frmCompras
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(824, 542);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "frmCompras";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmCompras";
            this.Load += new System.EventHandler(this.frmCompras_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaC)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtFolioCompraC;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnSalirC;
        private System.Windows.Forms.Button btnCancelarC;
        private System.Windows.Forms.Button btnLimpiarC;
        private System.Windows.Forms.Button btnBorrarC;
        private System.Windows.Forms.Button btnGuardarC;
        private System.Windows.Forms.Button btnNuevoV;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dtpFechaC;
        private System.Windows.Forms.Button btnBuscarC;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmbTipoPagoC;
        private System.Windows.Forms.ComboBox cmbTiendaC;
        private System.Windows.Forms.ComboBox cmbEmpleadoC;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView dgvListaC;
        private System.Windows.Forms.ComboBox cmbProductoC;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtCodigoC;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnRealizarCompraC;
        private System.Windows.Forms.TextBox txtTotalCompraC;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtPrecioCompraC;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtCantidadC;
        private System.Windows.Forms.Label label13;
    }
}