﻿namespace frmReposteria
{
    partial class frmProducto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.txtPrecioCompra = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.cmbTipoProducto = new System.Windows.Forms.ComboBox();
            this.lblId = new System.Windows.Forms.Label();
            this.txtStatus = new System.Windows.Forms.TextBox();
            this.txtClave = new System.Windows.Forms.TextBox();
            this.txtFotoP = new System.Windows.Forms.TextBox();
            this.txtPrecioVenta = new System.Windows.Forms.TextBox();
            this.txtDescripcion = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.btnFotoP = new System.Windows.Forms.Button();
            this.ptbFotoP = new System.Windows.Forms.PictureBox();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.btnBuscar = new System.Windows.Forms.Button();
            this.btnBorrar = new System.Windows.Forms.Button();
            this.btnModificar = new System.Windows.Forms.Button();
            this.btnNuevo = new System.Windows.Forms.Button();
            this.dgvLista = new System.Windows.Forms.DataGridView();
            this.btnCerrar = new System.Windows.Forms.Button();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.cmbUniPro = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.txtPrecioCompraPro = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtPrecioVentaPro = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cmbTipoProductoP = new System.Windows.Forms.ComboBox();
            this.btnHabilitarEm = new System.Windows.Forms.Button();
            this.txtStatusP = new System.Windows.Forms.TextBox();
            this.txtClaveP = new System.Windows.Forms.TextBox();
            this.txtFotoPro = new System.Windows.Forms.TextBox();
            this.txtDescripcionP = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnFotoPro = new System.Windows.Forms.Button();
            this.ptbFotoPro = new System.Windows.Forms.PictureBox();
            this.btnBuscarP = new System.Windows.Forms.Button();
            this.btnNuevoP = new System.Windows.Forms.Button();
            this.dgvListaP = new System.Windows.Forms.DataGridView();
            this.btnSalirP = new System.Windows.Forms.Button();
            this.btnCancelarP = new System.Windows.Forms.Button();
            this.btnLimpiarP = new System.Windows.Forms.Button();
            this.cmbUniProP = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptbFotoP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLista)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptbFotoPro)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaP)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(573, 509);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tabPage1.Controls.Add(this.txtPrecioCompra);
            this.tabPage1.Controls.Add(this.label11);
            this.tabPage1.Controls.Add(this.label12);
            this.tabPage1.Controls.Add(this.cmbTipoProducto);
            this.tabPage1.Controls.Add(this.lblId);
            this.tabPage1.Controls.Add(this.txtStatus);
            this.tabPage1.Controls.Add(this.txtClave);
            this.tabPage1.Controls.Add(this.txtFotoP);
            this.tabPage1.Controls.Add(this.txtPrecioVenta);
            this.tabPage1.Controls.Add(this.txtDescripcion);
            this.tabPage1.Controls.Add(this.label17);
            this.tabPage1.Controls.Add(this.btnFotoP);
            this.tabPage1.Controls.Add(this.ptbFotoP);
            this.tabPage1.Controls.Add(this.btnGuardar);
            this.tabPage1.Controls.Add(this.btnBuscar);
            this.tabPage1.Controls.Add(this.btnBorrar);
            this.tabPage1.Controls.Add(this.btnModificar);
            this.tabPage1.Controls.Add(this.btnNuevo);
            this.tabPage1.Controls.Add(this.dgvLista);
            this.tabPage1.Controls.Add(this.btnCerrar);
            this.tabPage1.Controls.Add(this.btnCancelar);
            this.tabPage1.Controls.Add(this.btnLimpiar);
            this.tabPage1.Controls.Add(this.cmbUniPro);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(565, 483);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Producto";
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // txtPrecioCompra
            // 
            this.txtPrecioCompra.Enabled = false;
            this.txtPrecioCompra.Location = new System.Drawing.Point(18, 224);
            this.txtPrecioCompra.MaxLength = 10;
            this.txtPrecioCompra.Name = "txtPrecioCompra";
            this.txtPrecioCompra.Size = new System.Drawing.Size(98, 20);
            this.txtPrecioCompra.TabIndex = 5;
            this.txtPrecioCompra.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPrecioCompra_KeyPress);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label11.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(15, 204);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(84, 16);
            this.label11.TabIndex = 164;
            this.label11.Text = "Precio Compra";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label12.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(15, 250);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(82, 16);
            this.label12.TabIndex = 162;
            this.label12.Text = "Tipo Producto";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // cmbTipoProducto
            // 
            this.cmbTipoProducto.Enabled = false;
            this.cmbTipoProducto.FormattingEnabled = true;
            this.cmbTipoProducto.Items.AddRange(new object[] {
            "1: Litro ",
            "2:Chico",
            "3: Mediano",
            "4:Grande",
            "5:Pieza"});
            this.cmbTipoProducto.Location = new System.Drawing.Point(16, 271);
            this.cmbTipoProducto.Name = "cmbTipoProducto";
            this.cmbTipoProducto.Size = new System.Drawing.Size(98, 21);
            this.cmbTipoProducto.TabIndex = 6;
            this.cmbTipoProducto.SelectedIndexChanged += new System.EventHandler(this.cmbTipoProducto_SelectedIndexChanged);
            // 
            // lblId
            // 
            this.lblId.AutoSize = true;
            this.lblId.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblId.Location = new System.Drawing.Point(128, 273);
            this.lblId.Name = "lblId";
            this.lblId.Size = new System.Drawing.Size(20, 13);
            this.lblId.TabIndex = 160;
            this.lblId.Text = "ID";
            this.lblId.Click += new System.EventHandler(this.lblId_Click);
            // 
            // txtStatus
            // 
            this.txtStatus.Enabled = false;
            this.txtStatus.Location = new System.Drawing.Point(18, 314);
            this.txtStatus.MaxLength = 10;
            this.txtStatus.Name = "txtStatus";
            this.txtStatus.Size = new System.Drawing.Size(98, 20);
            this.txtStatus.TabIndex = 133;
            // 
            // txtClave
            // 
            this.txtClave.Enabled = false;
            this.txtClave.Location = new System.Drawing.Point(16, 27);
            this.txtClave.MaxLength = 8;
            this.txtClave.Name = "txtClave";
            this.txtClave.Size = new System.Drawing.Size(98, 20);
            this.txtClave.TabIndex = 1;
            this.txtClave.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtClave_KeyPress_1);
            // 
            // txtFotoP
            // 
            this.txtFotoP.Enabled = false;
            this.txtFotoP.Location = new System.Drawing.Point(453, 353);
            this.txtFotoP.Name = "txtFotoP";
            this.txtFotoP.Size = new System.Drawing.Size(97, 20);
            this.txtFotoP.TabIndex = 150;
            // 
            // txtPrecioVenta
            // 
            this.txtPrecioVenta.Enabled = false;
            this.txtPrecioVenta.Location = new System.Drawing.Point(16, 178);
            this.txtPrecioVenta.MaxLength = 10;
            this.txtPrecioVenta.Name = "txtPrecioVenta";
            this.txtPrecioVenta.Size = new System.Drawing.Size(98, 20);
            this.txtPrecioVenta.TabIndex = 4;
            this.txtPrecioVenta.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPrecio_KeyPress_2);
            // 
            // txtDescripcion
            // 
            this.txtDescripcion.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtDescripcion.Enabled = false;
            this.txtDescripcion.Location = new System.Drawing.Point(16, 81);
            this.txtDescripcion.MaxLength = 15;
            this.txtDescripcion.Name = "txtDescripcion";
            this.txtDescripcion.Size = new System.Drawing.Size(98, 20);
            this.txtDescripcion.TabIndex = 2;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label17.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(13, 7);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(35, 16);
            this.label17.TabIndex = 151;
            this.label17.Text = "Clave";
            // 
            // btnFotoP
            // 
            this.btnFotoP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnFotoP.Enabled = false;
            this.btnFotoP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnFotoP.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFotoP.Location = new System.Drawing.Point(453, 324);
            this.btnFotoP.Name = "btnFotoP";
            this.btnFotoP.Size = new System.Drawing.Size(42, 23);
            this.btnFotoP.TabIndex = 134;
            this.btnFotoP.Text = "....";
            this.btnFotoP.UseVisualStyleBackColor = false;
            this.btnFotoP.Click += new System.EventHandler(this.btnFotoP_Click_2);
            // 
            // ptbFotoP
            // 
            this.ptbFotoP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.ptbFotoP.ErrorImage = null;
            this.ptbFotoP.Image = global::frmReposteria.Properties.Resources.imagen5;
            this.ptbFotoP.InitialImage = null;
            this.ptbFotoP.Location = new System.Drawing.Point(453, 195);
            this.ptbFotoP.Name = "ptbFotoP";
            this.ptbFotoP.Size = new System.Drawing.Size(100, 122);
            this.ptbFotoP.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ptbFotoP.TabIndex = 149;
            this.ptbFotoP.TabStop = false;
            // 
            // btnGuardar
            // 
            this.btnGuardar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnGuardar.Enabled = false;
            this.btnGuardar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnGuardar.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGuardar.ForeColor = System.Drawing.Color.Black;
            this.btnGuardar.Image = global::frmReposteria.Properties.Resources.guardar2;
            this.btnGuardar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGuardar.Location = new System.Drawing.Point(472, 55);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(81, 36);
            this.btnGuardar.TabIndex = 136;
            this.btnGuardar.Text = "Guardar";
            this.btnGuardar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnGuardar.UseVisualStyleBackColor = false;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click_2);
            // 
            // btnBuscar
            // 
            this.btnBuscar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnBuscar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBuscar.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscar.ForeColor = System.Drawing.Color.Black;
            this.btnBuscar.Image = global::frmReposteria.Properties.Resources.buscar;
            this.btnBuscar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBuscar.Location = new System.Drawing.Point(134, 12);
            this.btnBuscar.Name = "btnBuscar";
            this.btnBuscar.Size = new System.Drawing.Size(73, 37);
            this.btnBuscar.TabIndex = 137;
            this.btnBuscar.Text = "Buscar";
            this.btnBuscar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBuscar.UseVisualStyleBackColor = false;
            this.btnBuscar.Click += new System.EventHandler(this.btnBuscar_Click_2);
            // 
            // btnBorrar
            // 
            this.btnBorrar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnBorrar.Enabled = false;
            this.btnBorrar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBorrar.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBorrar.ForeColor = System.Drawing.Color.Black;
            this.btnBorrar.Image = global::frmReposteria.Properties.Resources.cubo_de_basura;
            this.btnBorrar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBorrar.Location = new System.Drawing.Point(481, 143);
            this.btnBorrar.Name = "btnBorrar";
            this.btnBorrar.Size = new System.Drawing.Size(72, 32);
            this.btnBorrar.TabIndex = 140;
            this.btnBorrar.Text = "Borrar";
            this.btnBorrar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBorrar.UseVisualStyleBackColor = false;
            this.btnBorrar.Click += new System.EventHandler(this.btnBorrar_Click_2);
            // 
            // btnModificar
            // 
            this.btnModificar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnModificar.Enabled = false;
            this.btnModificar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnModificar.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnModificar.ForeColor = System.Drawing.Color.Black;
            this.btnModificar.Image = global::frmReposteria.Properties.Resources.herramientas_del_empleado_de_mantenimiento;
            this.btnModificar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnModificar.Location = new System.Drawing.Point(463, 99);
            this.btnModificar.Name = "btnModificar";
            this.btnModificar.Size = new System.Drawing.Size(90, 36);
            this.btnModificar.TabIndex = 138;
            this.btnModificar.Text = "Modificar";
            this.btnModificar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnModificar.UseVisualStyleBackColor = false;
            this.btnModificar.Click += new System.EventHandler(this.btnModificar_Click_2);
            // 
            // btnNuevo
            // 
            this.btnNuevo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnNuevo.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNuevo.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNuevo.ForeColor = System.Drawing.Color.Black;
            this.btnNuevo.Image = global::frmReposteria.Properties.Resources.agregar_usuario;
            this.btnNuevo.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNuevo.Location = new System.Drawing.Point(478, 12);
            this.btnNuevo.Name = "btnNuevo";
            this.btnNuevo.Size = new System.Drawing.Size(75, 37);
            this.btnNuevo.TabIndex = 135;
            this.btnNuevo.Text = "Nuevo";
            this.btnNuevo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNuevo.UseVisualStyleBackColor = false;
            this.btnNuevo.Click += new System.EventHandler(this.btnNuevo_Click_2);
            // 
            // dgvLista
            // 
            this.dgvLista.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.dgvLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLista.Location = new System.Drawing.Point(16, 386);
            this.dgvLista.Name = "dgvLista";
            this.dgvLista.Size = new System.Drawing.Size(534, 91);
            this.dgvLista.TabIndex = 148;
            this.dgvLista.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvLista_CellContentClick);
            // 
            // btnCerrar
            // 
            this.btnCerrar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnCerrar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCerrar.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCerrar.ForeColor = System.Drawing.Color.Black;
            this.btnCerrar.Image = global::frmReposteria.Properties.Resources.salir_3;
            this.btnCerrar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCerrar.Location = new System.Drawing.Point(182, 340);
            this.btnCerrar.Name = "btnCerrar";
            this.btnCerrar.Size = new System.Drawing.Size(65, 33);
            this.btnCerrar.TabIndex = 142;
            this.btnCerrar.Text = "Salir";
            this.btnCerrar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCerrar.UseVisualStyleBackColor = false;
            this.btnCerrar.Click += new System.EventHandler(this.btnCerrar_Click_2);
            // 
            // btnCancelar
            // 
            this.btnCancelar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnCancelar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCancelar.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelar.ForeColor = System.Drawing.Color.Black;
            this.btnCancelar.Image = global::frmReposteria.Properties.Resources.prohibido__1_;
            this.btnCancelar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCancelar.Location = new System.Drawing.Point(100, 340);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(76, 33);
            this.btnCancelar.TabIndex = 141;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCancelar.UseVisualStyleBackColor = false;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click_2);
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnLimpiar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnLimpiar.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpiar.ForeColor = System.Drawing.Color.Black;
            this.btnLimpiar.Image = global::frmReposteria.Properties.Resources.escoba_de_limpieza_para_suelos__1_;
            this.btnLimpiar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLimpiar.Location = new System.Drawing.Point(18, 340);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(76, 33);
            this.btnLimpiar.TabIndex = 139;
            this.btnLimpiar.Text = "Limpiar";
            this.btnLimpiar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLimpiar.UseVisualStyleBackColor = false;
            this.btnLimpiar.Click += new System.EventHandler(this.btnLimpiar_Click_2);
            // 
            // cmbUniPro
            // 
            this.cmbUniPro.Enabled = false;
            this.cmbUniPro.FormattingEnabled = true;
            this.cmbUniPro.Items.AddRange(new object[] {
            "1: Litro ",
            "2:Chico",
            "3: Mediano",
            "4:Grande",
            "5:Pieza"});
            this.cmbUniPro.Location = new System.Drawing.Point(16, 131);
            this.cmbUniPro.Name = "cmbUniPro";
            this.cmbUniPro.Size = new System.Drawing.Size(98, 21);
            this.cmbUniPro.TabIndex = 3;
            this.cmbUniPro.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbUniPro_KeyPress_2);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label7.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(13, 109);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(111, 16);
            this.label7.TabIndex = 147;
            this.label7.Text = "Unidad de Producto";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label6.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(13, 158);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 16);
            this.label6.TabIndex = 146;
            this.label6.Text = "Precio Venta";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label5.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(15, 295);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 16);
            this.label5.TabIndex = 145;
            this.label5.Text = "Status";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label4.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(13, 60);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 16);
            this.label4.TabIndex = 144;
            this.label4.Text = "Descripcion";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tabPage2.Controls.Add(this.txtPrecioCompraPro);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.txtPrecioVentaPro);
            this.tabPage2.Controls.Add(this.label13);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.cmbTipoProductoP);
            this.tabPage2.Controls.Add(this.btnHabilitarEm);
            this.tabPage2.Controls.Add(this.txtStatusP);
            this.tabPage2.Controls.Add(this.txtClaveP);
            this.tabPage2.Controls.Add(this.txtFotoPro);
            this.tabPage2.Controls.Add(this.txtDescripcionP);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.btnFotoPro);
            this.tabPage2.Controls.Add(this.ptbFotoPro);
            this.tabPage2.Controls.Add(this.btnBuscarP);
            this.tabPage2.Controls.Add(this.btnNuevoP);
            this.tabPage2.Controls.Add(this.dgvListaP);
            this.tabPage2.Controls.Add(this.btnSalirP);
            this.tabPage2.Controls.Add(this.btnCancelarP);
            this.tabPage2.Controls.Add(this.btnLimpiarP);
            this.tabPage2.Controls.Add(this.cmbUniProP);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(565, 483);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Habilitar";
            this.tabPage2.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // txtPrecioCompraPro
            // 
            this.txtPrecioCompraPro.Enabled = false;
            this.txtPrecioCompraPro.Location = new System.Drawing.Point(15, 224);
            this.txtPrecioCompraPro.MaxLength = 10;
            this.txtPrecioCompraPro.Name = "txtPrecioCompraPro";
            this.txtPrecioCompraPro.Size = new System.Drawing.Size(98, 20);
            this.txtPrecioCompraPro.TabIndex = 221;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label8.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(12, 204);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(84, 16);
            this.label8.TabIndex = 222;
            this.label8.Text = "Precio Compra";
            // 
            // txtPrecioVentaPro
            // 
            this.txtPrecioVentaPro.Enabled = false;
            this.txtPrecioVentaPro.Location = new System.Drawing.Point(13, 178);
            this.txtPrecioVentaPro.MaxLength = 10;
            this.txtPrecioVentaPro.Name = "txtPrecioVentaPro";
            this.txtPrecioVentaPro.Size = new System.Drawing.Size(98, 20);
            this.txtPrecioVentaPro.TabIndex = 219;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label13.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(10, 158);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(75, 16);
            this.label13.TabIndex = 220;
            this.label13.Text = "Precio Venta";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label3.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 250);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 16);
            this.label3.TabIndex = 218;
            this.label3.Text = "Tipo Producto";
            // 
            // cmbTipoProductoP
            // 
            this.cmbTipoProductoP.Enabled = false;
            this.cmbTipoProductoP.FormattingEnabled = true;
            this.cmbTipoProductoP.Items.AddRange(new object[] {
            "1: Litro ",
            "2:Chico",
            "3: Mediano",
            "4:Grande",
            "5:Pieza"});
            this.cmbTipoProductoP.Location = new System.Drawing.Point(13, 271);
            this.cmbTipoProductoP.Name = "cmbTipoProductoP";
            this.cmbTipoProductoP.Size = new System.Drawing.Size(98, 21);
            this.cmbTipoProductoP.TabIndex = 217;
            this.cmbTipoProductoP.SelectedIndexChanged += new System.EventHandler(this.cmbTipoProductoP_SelectedIndexChanged);
            // 
            // btnHabilitarEm
            // 
            this.btnHabilitarEm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnHabilitarEm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnHabilitarEm.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHabilitarEm.Image = global::frmReposteria.Properties.Resources.copia_de_seguridad;
            this.btnHabilitarEm.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHabilitarEm.Location = new System.Drawing.Point(146, 58);
            this.btnHabilitarEm.Name = "btnHabilitarEm";
            this.btnHabilitarEm.Size = new System.Drawing.Size(87, 37);
            this.btnHabilitarEm.TabIndex = 216;
            this.btnHabilitarEm.Text = "Habilitar";
            this.btnHabilitarEm.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnHabilitarEm.UseVisualStyleBackColor = false;
            this.btnHabilitarEm.Click += new System.EventHandler(this.btnHabilitarEm_Click);
            // 
            // txtStatusP
            // 
            this.txtStatusP.Enabled = false;
            this.txtStatusP.Location = new System.Drawing.Point(15, 317);
            this.txtStatusP.MaxLength = 10;
            this.txtStatusP.Name = "txtStatusP";
            this.txtStatusP.Size = new System.Drawing.Size(98, 20);
            this.txtStatusP.TabIndex = 157;
            // 
            // txtClaveP
            // 
            this.txtClaveP.Enabled = false;
            this.txtClaveP.Location = new System.Drawing.Point(13, 26);
            this.txtClaveP.MaxLength = 10;
            this.txtClaveP.Name = "txtClaveP";
            this.txtClaveP.Size = new System.Drawing.Size(98, 20);
            this.txtClaveP.TabIndex = 152;
            // 
            // txtFotoPro
            // 
            this.txtFotoPro.Enabled = false;
            this.txtFotoPro.Location = new System.Drawing.Point(452, 244);
            this.txtFotoPro.Name = "txtFotoPro";
            this.txtFotoPro.Size = new System.Drawing.Size(97, 20);
            this.txtFotoPro.TabIndex = 174;
            // 
            // txtDescripcionP
            // 
            this.txtDescripcionP.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtDescripcionP.Enabled = false;
            this.txtDescripcionP.Location = new System.Drawing.Point(13, 74);
            this.txtDescripcionP.MaxLength = 45;
            this.txtDescripcionP.Name = "txtDescripcionP";
            this.txtDescripcionP.Size = new System.Drawing.Size(98, 20);
            this.txtDescripcionP.TabIndex = 154;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(10, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 16);
            this.label1.TabIndex = 175;
            this.label1.Text = "Clave";
            // 
            // btnFotoPro
            // 
            this.btnFotoPro.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnFotoPro.Enabled = false;
            this.btnFotoPro.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnFotoPro.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFotoPro.Location = new System.Drawing.Point(452, 215);
            this.btnFotoPro.Name = "btnFotoPro";
            this.btnFotoPro.Size = new System.Drawing.Size(42, 23);
            this.btnFotoPro.TabIndex = 158;
            this.btnFotoPro.Text = "....";
            this.btnFotoPro.UseVisualStyleBackColor = false;
            // 
            // ptbFotoPro
            // 
            this.ptbFotoPro.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.ptbFotoPro.ErrorImage = null;
            this.ptbFotoPro.Image = global::frmReposteria.Properties.Resources.imagen5;
            this.ptbFotoPro.InitialImage = null;
            this.ptbFotoPro.Location = new System.Drawing.Point(452, 86);
            this.ptbFotoPro.Name = "ptbFotoPro";
            this.ptbFotoPro.Size = new System.Drawing.Size(100, 122);
            this.ptbFotoPro.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ptbFotoPro.TabIndex = 173;
            this.ptbFotoPro.TabStop = false;
            // 
            // btnBuscarP
            // 
            this.btnBuscarP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnBuscarP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBuscarP.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscarP.ForeColor = System.Drawing.Color.Black;
            this.btnBuscarP.Image = global::frmReposteria.Properties.Resources.buscar;
            this.btnBuscarP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBuscarP.Location = new System.Drawing.Point(160, 16);
            this.btnBuscarP.Name = "btnBuscarP";
            this.btnBuscarP.Size = new System.Drawing.Size(73, 37);
            this.btnBuscarP.TabIndex = 161;
            this.btnBuscarP.Text = "Buscar";
            this.btnBuscarP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBuscarP.UseVisualStyleBackColor = false;
            this.btnBuscarP.Click += new System.EventHandler(this.btnBuscarP_Click);
            // 
            // btnNuevoP
            // 
            this.btnNuevoP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnNuevoP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNuevoP.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNuevoP.ForeColor = System.Drawing.Color.Black;
            this.btnNuevoP.Image = global::frmReposteria.Properties.Resources.agregar_usuario;
            this.btnNuevoP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNuevoP.Location = new System.Drawing.Point(477, 14);
            this.btnNuevoP.Name = "btnNuevoP";
            this.btnNuevoP.Size = new System.Drawing.Size(75, 37);
            this.btnNuevoP.TabIndex = 159;
            this.btnNuevoP.Text = "Nuevo";
            this.btnNuevoP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNuevoP.UseVisualStyleBackColor = false;
            this.btnNuevoP.Click += new System.EventHandler(this.btnNuevoP_Click);
            // 
            // dgvListaP
            // 
            this.dgvListaP.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.dgvListaP.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvListaP.Location = new System.Drawing.Point(15, 390);
            this.dgvListaP.Name = "dgvListaP";
            this.dgvListaP.Size = new System.Drawing.Size(523, 80);
            this.dgvListaP.TabIndex = 172;
            // 
            // btnSalirP
            // 
            this.btnSalirP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnSalirP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSalirP.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalirP.ForeColor = System.Drawing.Color.Black;
            this.btnSalirP.Image = global::frmReposteria.Properties.Resources.salir_3;
            this.btnSalirP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSalirP.Location = new System.Drawing.Point(181, 351);
            this.btnSalirP.Name = "btnSalirP";
            this.btnSalirP.Size = new System.Drawing.Size(65, 33);
            this.btnSalirP.TabIndex = 166;
            this.btnSalirP.Text = "Salir";
            this.btnSalirP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSalirP.UseVisualStyleBackColor = false;
            this.btnSalirP.Click += new System.EventHandler(this.btnSalirP_Click);
            // 
            // btnCancelarP
            // 
            this.btnCancelarP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnCancelarP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCancelarP.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelarP.ForeColor = System.Drawing.Color.Black;
            this.btnCancelarP.Image = global::frmReposteria.Properties.Resources.prohibido__1_;
            this.btnCancelarP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCancelarP.Location = new System.Drawing.Point(99, 351);
            this.btnCancelarP.Name = "btnCancelarP";
            this.btnCancelarP.Size = new System.Drawing.Size(76, 33);
            this.btnCancelarP.TabIndex = 165;
            this.btnCancelarP.Text = "Cancelar";
            this.btnCancelarP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCancelarP.UseVisualStyleBackColor = false;
            this.btnCancelarP.Click += new System.EventHandler(this.btnCancelarP_Click);
            // 
            // btnLimpiarP
            // 
            this.btnLimpiarP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnLimpiarP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnLimpiarP.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpiarP.ForeColor = System.Drawing.Color.Black;
            this.btnLimpiarP.Image = global::frmReposteria.Properties.Resources.escoba_de_limpieza_para_suelos__1_;
            this.btnLimpiarP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLimpiarP.Location = new System.Drawing.Point(17, 351);
            this.btnLimpiarP.Name = "btnLimpiarP";
            this.btnLimpiarP.Size = new System.Drawing.Size(76, 33);
            this.btnLimpiarP.TabIndex = 163;
            this.btnLimpiarP.Text = "Limpiar";
            this.btnLimpiarP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLimpiarP.UseVisualStyleBackColor = false;
            this.btnLimpiarP.Click += new System.EventHandler(this.btnLimpiarP_Click);
            // 
            // cmbUniProP
            // 
            this.cmbUniProP.Enabled = false;
            this.cmbUniProP.FormattingEnabled = true;
            this.cmbUniProP.Items.AddRange(new object[] {
            "1: Litro ",
            "2:Chico",
            "3: Mediano",
            "4:Grande",
            "5:Pieza"});
            this.cmbUniProP.Location = new System.Drawing.Point(13, 125);
            this.cmbUniProP.Name = "cmbUniProP";
            this.cmbUniProP.Size = new System.Drawing.Size(98, 21);
            this.cmbUniProP.TabIndex = 155;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label2.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(10, 104);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(111, 16);
            this.label2.TabIndex = 171;
            this.label2.Text = "Unidad de Producto";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label9.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(12, 295);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(43, 16);
            this.label9.TabIndex = 169;
            this.label9.Text = "Status";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label10.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(10, 55);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(68, 16);
            this.label10.TabIndex = 168;
            this.label10.Text = "Descripcion";
            // 
            // frmProducto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(597, 533);
            this.Controls.Add(this.tabControl1);
            this.Name = "frmProducto";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Producto";
            this.Load += new System.EventHandler(this.frmProducto_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptbFotoP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLista)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptbFotoPro)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaP)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox txtStatus;
        private System.Windows.Forms.TextBox txtClave;
        private System.Windows.Forms.TextBox txtFotoP;
        private System.Windows.Forms.TextBox txtPrecioVenta;
        private System.Windows.Forms.TextBox txtDescripcion;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button btnFotoP;
        private System.Windows.Forms.PictureBox ptbFotoP;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.Button btnBuscar;
        private System.Windows.Forms.Button btnBorrar;
        private System.Windows.Forms.Button btnModificar;
        private System.Windows.Forms.Button btnNuevo;
        private System.Windows.Forms.DataGridView dgvLista;
        private System.Windows.Forms.Button btnCerrar;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Button btnLimpiar;
        private System.Windows.Forms.ComboBox cmbUniPro;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox txtStatusP;
        private System.Windows.Forms.TextBox txtClaveP;
        private System.Windows.Forms.TextBox txtFotoPro;
        private System.Windows.Forms.TextBox txtDescripcionP;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnFotoPro;
        private System.Windows.Forms.PictureBox ptbFotoPro;
        private System.Windows.Forms.Button btnBuscarP;
        private System.Windows.Forms.Button btnNuevoP;
        private System.Windows.Forms.DataGridView dgvListaP;
        private System.Windows.Forms.Button btnSalirP;
        private System.Windows.Forms.Button btnCancelarP;
        private System.Windows.Forms.Button btnLimpiarP;
        private System.Windows.Forms.ComboBox cmbUniProP;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btnHabilitarEm;
        private System.Windows.Forms.Label lblId;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox cmbTipoProducto;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmbTipoProductoP;
        private System.Windows.Forms.TextBox txtPrecioCompra;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtPrecioCompraPro;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtPrecioVentaPro;
        private System.Windows.Forms.Label label13;
    }
}