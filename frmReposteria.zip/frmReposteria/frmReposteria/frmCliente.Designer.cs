﻿namespace frmReposteria
{
    partial class frmCliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.txtClaveC = new System.Windows.Forms.TextBox();
            this.txtStatusC = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.txtFotoC = new System.Windows.Forms.TextBox();
            this.ptbFotoC = new System.Windows.Forms.PictureBox();
            this.btnFotoC = new System.Windows.Forms.Button();
            this.txtCurpC = new System.Windows.Forms.TextBox();
            this.btnBuscarC = new System.Windows.Forms.Button();
            this.btnCancelarC = new System.Windows.Forms.Button();
            this.btnLimpiarC = new System.Windows.Forms.Button();
            this.btnSalirC = new System.Windows.Forms.Button();
            this.btnBorrarC = new System.Windows.Forms.Button();
            this.btnModificarC = new System.Windows.Forms.Button();
            this.btnGuardarC = new System.Windows.Forms.Button();
            this.btnNuevoC = new System.Windows.Forms.Button();
            this.dbglistaC = new System.Windows.Forms.DataGridView();
            this.txtCodigoPostC = new System.Windows.Forms.TextBox();
            this.txtNumeroC = new System.Windows.Forms.TextBox();
            this.txtCalleC = new System.Windows.Forms.TextBox();
            this.txtColoniaC = new System.Windows.Forms.TextBox();
            this.txtApellidoPatC = new System.Windows.Forms.TextBox();
            this.txtApellidoMatC = new System.Windows.Forms.TextBox();
            this.txtTelefonoC = new System.Windows.Forms.TextBox();
            this.txtCorreoC = new System.Windows.Forms.TextBox();
            this.txtNombreC = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnHabilitarEm = new System.Windows.Forms.Button();
            this.txtClaveCli = new System.Windows.Forms.TextBox();
            this.txtStatusCli = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtFotoCli = new System.Windows.Forms.TextBox();
            this.ptbFotoCli = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.txtCurpCli = new System.Windows.Forms.TextBox();
            this.btnBuscarCli = new System.Windows.Forms.Button();
            this.btnCancelarCli = new System.Windows.Forms.Button();
            this.btnLimpiarCli = new System.Windows.Forms.Button();
            this.btnSalirCli = new System.Windows.Forms.Button();
            this.btnNuevoClie = new System.Windows.Forms.Button();
            this.dgvListaCli = new System.Windows.Forms.DataGridView();
            this.txtCodigoPostCli = new System.Windows.Forms.TextBox();
            this.txtNumeroCli = new System.Windows.Forms.TextBox();
            this.txtCalleCli = new System.Windows.Forms.TextBox();
            this.txtColoniaCli = new System.Windows.Forms.TextBox();
            this.txtApellidoPatCli = new System.Windows.Forms.TextBox();
            this.txtApellidoMatCli = new System.Windows.Forms.TextBox();
            this.txtTelefonoCli = new System.Windows.Forms.TextBox();
            this.txtCorreoCli = new System.Windows.Forms.TextBox();
            this.txtNombreCli = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptbFotoC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbglistaC)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptbFotoCli)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaCli)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(671, 485);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tabPage1.Controls.Add(this.txtClaveC);
            this.tabPage1.Controls.Add(this.txtStatusC);
            this.tabPage1.Controls.Add(this.label31);
            this.tabPage1.Controls.Add(this.txtFotoC);
            this.tabPage1.Controls.Add(this.ptbFotoC);
            this.tabPage1.Controls.Add(this.btnFotoC);
            this.tabPage1.Controls.Add(this.txtCurpC);
            this.tabPage1.Controls.Add(this.btnBuscarC);
            this.tabPage1.Controls.Add(this.btnCancelarC);
            this.tabPage1.Controls.Add(this.btnLimpiarC);
            this.tabPage1.Controls.Add(this.btnSalirC);
            this.tabPage1.Controls.Add(this.btnBorrarC);
            this.tabPage1.Controls.Add(this.btnModificarC);
            this.tabPage1.Controls.Add(this.btnGuardarC);
            this.tabPage1.Controls.Add(this.btnNuevoC);
            this.tabPage1.Controls.Add(this.dbglistaC);
            this.tabPage1.Controls.Add(this.txtCodigoPostC);
            this.tabPage1.Controls.Add(this.txtNumeroC);
            this.tabPage1.Controls.Add(this.txtCalleC);
            this.tabPage1.Controls.Add(this.txtColoniaC);
            this.tabPage1.Controls.Add(this.txtApellidoPatC);
            this.tabPage1.Controls.Add(this.txtApellidoMatC);
            this.tabPage1.Controls.Add(this.txtTelefonoC);
            this.tabPage1.Controls.Add(this.txtCorreoC);
            this.tabPage1.Controls.Add(this.txtNombreC);
            this.tabPage1.Controls.Add(this.label13);
            this.tabPage1.Controls.Add(this.label12);
            this.tabPage1.Controls.Add(this.label11);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.label14);
            this.tabPage1.Controls.Add(this.label15);
            this.tabPage1.Controls.Add(this.label16);
            this.tabPage1.Controls.Add(this.label17);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(663, 459);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Cliente";
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // txtClaveC
            // 
            this.txtClaveC.Enabled = false;
            this.txtClaveC.Location = new System.Drawing.Point(15, 34);
            this.txtClaveC.Name = "txtClaveC";
            this.txtClaveC.Size = new System.Drawing.Size(100, 20);
            this.txtClaveC.TabIndex = 139;
            this.txtClaveC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtClaveC_KeyPress_1);
            // 
            // txtStatusC
            // 
            this.txtStatusC.Enabled = false;
            this.txtStatusC.Location = new System.Drawing.Point(262, 272);
            this.txtStatusC.Name = "txtStatusC";
            this.txtStatusC.Size = new System.Drawing.Size(100, 20);
            this.txtStatusC.TabIndex = 176;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label31.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(12, 14);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(35, 16);
            this.label31.TabIndex = 175;
            this.label31.Text = "Clave";
            // 
            // txtFotoC
            // 
            this.txtFotoC.Enabled = false;
            this.txtFotoC.Location = new System.Drawing.Point(544, 379);
            this.txtFotoC.Name = "txtFotoC";
            this.txtFotoC.Size = new System.Drawing.Size(100, 20);
            this.txtFotoC.TabIndex = 174;
            // 
            // ptbFotoC
            // 
            this.ptbFotoC.Image = global::frmReposteria.Properties.Resources.imagen;
            this.ptbFotoC.Location = new System.Drawing.Point(544, 207);
            this.ptbFotoC.Name = "ptbFotoC";
            this.ptbFotoC.Size = new System.Drawing.Size(100, 135);
            this.ptbFotoC.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ptbFotoC.TabIndex = 173;
            this.ptbFotoC.TabStop = false;
            // 
            // btnFotoC
            // 
            this.btnFotoC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnFotoC.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnFotoC.Location = new System.Drawing.Point(544, 348);
            this.btnFotoC.Name = "btnFotoC";
            this.btnFotoC.Size = new System.Drawing.Size(32, 24);
            this.btnFotoC.TabIndex = 150;
            this.btnFotoC.Text = "...";
            this.btnFotoC.UseVisualStyleBackColor = false;
            this.btnFotoC.Click += new System.EventHandler(this.btnFotoC_Click_1);
            // 
            // txtCurpC
            // 
            this.txtCurpC.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtCurpC.Enabled = false;
            this.txtCurpC.Location = new System.Drawing.Point(15, 226);
            this.txtCurpC.MaxLength = 25;
            this.txtCurpC.Name = "txtCurpC";
            this.txtCurpC.Size = new System.Drawing.Size(100, 20);
            this.txtCurpC.TabIndex = 143;
            // 
            // btnBuscarC
            // 
            this.btnBuscarC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnBuscarC.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBuscarC.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscarC.Image = global::frmReposteria.Properties.Resources.buscar;
            this.btnBuscarC.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBuscarC.Location = new System.Drawing.Point(141, 19);
            this.btnBuscarC.Name = "btnBuscarC";
            this.btnBuscarC.Size = new System.Drawing.Size(75, 32);
            this.btnBuscarC.TabIndex = 154;
            this.btnBuscarC.Text = "Buscar";
            this.btnBuscarC.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBuscarC.UseVisualStyleBackColor = false;
            this.btnBuscarC.Click += new System.EventHandler(this.btnBuscarC_Click_1);
            // 
            // btnCancelarC
            // 
            this.btnCancelarC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnCancelarC.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCancelarC.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelarC.Image = global::frmReposteria.Properties.Resources.prohibido__1_;
            this.btnCancelarC.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCancelarC.Location = new System.Drawing.Point(96, 321);
            this.btnCancelarC.Name = "btnCancelarC";
            this.btnCancelarC.Size = new System.Drawing.Size(75, 33);
            this.btnCancelarC.TabIndex = 157;
            this.btnCancelarC.Text = "Cancelar";
            this.btnCancelarC.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCancelarC.UseVisualStyleBackColor = false;
            this.btnCancelarC.Click += new System.EventHandler(this.btnCancelarC_Click_1);
            // 
            // btnLimpiarC
            // 
            this.btnLimpiarC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnLimpiarC.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnLimpiarC.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpiarC.Image = global::frmReposteria.Properties.Resources.escoba_de_limpieza_para_suelos__1_;
            this.btnLimpiarC.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLimpiarC.Location = new System.Drawing.Point(15, 321);
            this.btnLimpiarC.Name = "btnLimpiarC";
            this.btnLimpiarC.Size = new System.Drawing.Size(75, 33);
            this.btnLimpiarC.TabIndex = 156;
            this.btnLimpiarC.Text = "Limpiar";
            this.btnLimpiarC.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLimpiarC.UseVisualStyleBackColor = false;
            this.btnLimpiarC.Click += new System.EventHandler(this.btnLimpiarC_Click_1);
            // 
            // btnSalirC
            // 
            this.btnSalirC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnSalirC.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSalirC.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalirC.Image = global::frmReposteria.Properties.Resources.salir_3;
            this.btnSalirC.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSalirC.Location = new System.Drawing.Point(177, 321);
            this.btnSalirC.Name = "btnSalirC";
            this.btnSalirC.Size = new System.Drawing.Size(66, 33);
            this.btnSalirC.TabIndex = 159;
            this.btnSalirC.Text = "Salir";
            this.btnSalirC.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSalirC.UseVisualStyleBackColor = false;
            this.btnSalirC.Click += new System.EventHandler(this.btnSalirC_Click_1);
            // 
            // btnBorrarC
            // 
            this.btnBorrarC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnBorrarC.Enabled = false;
            this.btnBorrarC.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBorrarC.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBorrarC.Image = global::frmReposteria.Properties.Resources.cubo_de_basura;
            this.btnBorrarC.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBorrarC.Location = new System.Drawing.Point(574, 153);
            this.btnBorrarC.Name = "btnBorrarC";
            this.btnBorrarC.Size = new System.Drawing.Size(70, 35);
            this.btnBorrarC.TabIndex = 158;
            this.btnBorrarC.Text = "Borrar";
            this.btnBorrarC.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBorrarC.UseVisualStyleBackColor = false;
            this.btnBorrarC.Click += new System.EventHandler(this.btnBorrarC_Click_1);
            // 
            // btnModificarC
            // 
            this.btnModificarC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnModificarC.Enabled = false;
            this.btnModificarC.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnModificarC.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnModificarC.Image = global::frmReposteria.Properties.Resources.herramientas_del_empleado_de_mantenimiento;
            this.btnModificarC.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnModificarC.Location = new System.Drawing.Point(553, 113);
            this.btnModificarC.Name = "btnModificarC";
            this.btnModificarC.Size = new System.Drawing.Size(91, 34);
            this.btnModificarC.TabIndex = 155;
            this.btnModificarC.Text = "Modificar";
            this.btnModificarC.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnModificarC.UseVisualStyleBackColor = false;
            this.btnModificarC.Click += new System.EventHandler(this.btnModificarC_Click_1);
            // 
            // btnGuardarC
            // 
            this.btnGuardarC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnGuardarC.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnGuardarC.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGuardarC.Image = global::frmReposteria.Properties.Resources.guardar2;
            this.btnGuardarC.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGuardarC.Location = new System.Drawing.Point(561, 70);
            this.btnGuardarC.Name = "btnGuardarC";
            this.btnGuardarC.Size = new System.Drawing.Size(83, 35);
            this.btnGuardarC.TabIndex = 153;
            this.btnGuardarC.Text = "Guardar";
            this.btnGuardarC.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnGuardarC.UseVisualStyleBackColor = false;
            this.btnGuardarC.Click += new System.EventHandler(this.btnGuardarC_Click_1);
            // 
            // btnNuevoC
            // 
            this.btnNuevoC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnNuevoC.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNuevoC.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNuevoC.Image = global::frmReposteria.Properties.Resources.agregar_usuario;
            this.btnNuevoC.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNuevoC.Location = new System.Drawing.Point(569, 27);
            this.btnNuevoC.Name = "btnNuevoC";
            this.btnNuevoC.Size = new System.Drawing.Size(75, 32);
            this.btnNuevoC.TabIndex = 152;
            this.btnNuevoC.Text = "Nuevo";
            this.btnNuevoC.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNuevoC.UseVisualStyleBackColor = false;
            this.btnNuevoC.Click += new System.EventHandler(this.btnNuevoC_Click_2);
            // 
            // dbglistaC
            // 
            this.dbglistaC.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.dbglistaC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dbglistaC.Location = new System.Drawing.Point(6, 360);
            this.dbglistaC.Name = "dbglistaC";
            this.dbglistaC.Size = new System.Drawing.Size(515, 93);
            this.dbglistaC.TabIndex = 172;
            // 
            // txtCodigoPostC
            // 
            this.txtCodigoPostC.Enabled = false;
            this.txtCodigoPostC.Location = new System.Drawing.Point(262, 226);
            this.txtCodigoPostC.MaxLength = 10;
            this.txtCodigoPostC.Name = "txtCodigoPostC";
            this.txtCodigoPostC.Size = new System.Drawing.Size(100, 20);
            this.txtCodigoPostC.TabIndex = 149;
            this.txtCodigoPostC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCodigoPostC_KeyPress_1);
            // 
            // txtNumeroC
            // 
            this.txtNumeroC.Enabled = false;
            this.txtNumeroC.Location = new System.Drawing.Point(262, 179);
            this.txtNumeroC.MaxLength = 25;
            this.txtNumeroC.Name = "txtNumeroC";
            this.txtNumeroC.Size = new System.Drawing.Size(100, 20);
            this.txtNumeroC.TabIndex = 148;
            this.txtNumeroC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumeroC_KeyPress_1);
            // 
            // txtCalleC
            // 
            this.txtCalleC.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtCalleC.Enabled = false;
            this.txtCalleC.Location = new System.Drawing.Point(262, 134);
            this.txtCalleC.MaxLength = 45;
            this.txtCalleC.Name = "txtCalleC";
            this.txtCalleC.Size = new System.Drawing.Size(100, 20);
            this.txtCalleC.TabIndex = 147;
            // 
            // txtColoniaC
            // 
            this.txtColoniaC.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtColoniaC.Enabled = false;
            this.txtColoniaC.Location = new System.Drawing.Point(262, 85);
            this.txtColoniaC.MaxLength = 45;
            this.txtColoniaC.Name = "txtColoniaC";
            this.txtColoniaC.Size = new System.Drawing.Size(100, 20);
            this.txtColoniaC.TabIndex = 146;
            // 
            // txtApellidoPatC
            // 
            this.txtApellidoPatC.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtApellidoPatC.Enabled = false;
            this.txtApellidoPatC.Location = new System.Drawing.Point(15, 179);
            this.txtApellidoPatC.MaxLength = 45;
            this.txtApellidoPatC.Name = "txtApellidoPatC";
            this.txtApellidoPatC.Size = new System.Drawing.Size(100, 20);
            this.txtApellidoPatC.TabIndex = 142;
            // 
            // txtApellidoMatC
            // 
            this.txtApellidoMatC.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtApellidoMatC.Enabled = false;
            this.txtApellidoMatC.Location = new System.Drawing.Point(15, 131);
            this.txtApellidoMatC.MaxLength = 45;
            this.txtApellidoMatC.Name = "txtApellidoMatC";
            this.txtApellidoMatC.Size = new System.Drawing.Size(100, 20);
            this.txtApellidoMatC.TabIndex = 141;
            // 
            // txtTelefonoC
            // 
            this.txtTelefonoC.Enabled = false;
            this.txtTelefonoC.Location = new System.Drawing.Point(262, 41);
            this.txtTelefonoC.MaxLength = 25;
            this.txtTelefonoC.Name = "txtTelefonoC";
            this.txtTelefonoC.Size = new System.Drawing.Size(100, 20);
            this.txtTelefonoC.TabIndex = 145;
            this.txtTelefonoC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTelefonoC_KeyPress_1);
            // 
            // txtCorreoC
            // 
            this.txtCorreoC.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtCorreoC.Enabled = false;
            this.txtCorreoC.Location = new System.Drawing.Point(15, 272);
            this.txtCorreoC.MaxLength = 25;
            this.txtCorreoC.Name = "txtCorreoC";
            this.txtCorreoC.Size = new System.Drawing.Size(100, 20);
            this.txtCorreoC.TabIndex = 144;
            this.txtCorreoC.TextChanged += new System.EventHandler(this.txtCorreoC_TextChanged);
            this.txtCorreoC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCorreoC_KeyPress);
            // 
            // txtNombreC
            // 
            this.txtNombreC.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtNombreC.Enabled = false;
            this.txtNombreC.Location = new System.Drawing.Point(15, 80);
            this.txtNombreC.MaxLength = 45;
            this.txtNombreC.Name = "txtNombreC";
            this.txtNombreC.Size = new System.Drawing.Size(100, 20);
            this.txtNombreC.TabIndex = 140;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label13.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(263, 251);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(40, 16);
            this.label13.TabIndex = 171;
            this.label13.Text = "status";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label12.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(259, 205);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(78, 16);
            this.label12.TabIndex = 170;
            this.label12.Text = "Codigo Postal";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label11.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(259, 160);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(49, 16);
            this.label11.TabIndex = 169;
            this.label11.Text = "Numero";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label10.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(259, 114);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(33, 16);
            this.label10.TabIndex = 168;
            this.label10.Text = "Calle";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label9.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(259, 66);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(45, 16);
            this.label9.TabIndex = 167;
            this.label9.Text = "Colonia";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label8.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(12, 60);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(50, 16);
            this.label8.TabIndex = 166;
            this.label8.Text = "Nombre";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 335);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 165;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label6.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(12, 159);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(94, 16);
            this.label6.TabIndex = 164;
            this.label6.Text = "Apellido Paterno";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label14.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(12, 109);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(99, 16);
            this.label14.TabIndex = 163;
            this.label14.Text = "Apellido Materno";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label15.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(259, 20);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(55, 16);
            this.label15.TabIndex = 162;
            this.label15.Text = "Telefono";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label16.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(12, 252);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(43, 16);
            this.label16.TabIndex = 161;
            this.label16.Text = "Correo";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label17.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(12, 207);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(32, 16);
            this.label17.TabIndex = 160;
            this.label17.Text = "Curp";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(26, 336);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 13);
            this.label7.TabIndex = 151;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tabPage2.Controls.Add(this.btnHabilitarEm);
            this.tabPage2.Controls.Add(this.txtClaveCli);
            this.tabPage2.Controls.Add(this.txtStatusCli);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.txtFotoCli);
            this.tabPage2.Controls.Add(this.ptbFotoCli);
            this.tabPage2.Controls.Add(this.button1);
            this.tabPage2.Controls.Add(this.txtCurpCli);
            this.tabPage2.Controls.Add(this.btnBuscarCli);
            this.tabPage2.Controls.Add(this.btnCancelarCli);
            this.tabPage2.Controls.Add(this.btnLimpiarCli);
            this.tabPage2.Controls.Add(this.btnSalirCli);
            this.tabPage2.Controls.Add(this.btnNuevoClie);
            this.tabPage2.Controls.Add(this.dgvListaCli);
            this.tabPage2.Controls.Add(this.txtCodigoPostCli);
            this.tabPage2.Controls.Add(this.txtNumeroCli);
            this.tabPage2.Controls.Add(this.txtCalleCli);
            this.tabPage2.Controls.Add(this.txtColoniaCli);
            this.tabPage2.Controls.Add(this.txtApellidoPatCli);
            this.tabPage2.Controls.Add(this.txtApellidoMatCli);
            this.tabPage2.Controls.Add(this.txtTelefonoCli);
            this.tabPage2.Controls.Add(this.txtCorreoCli);
            this.tabPage2.Controls.Add(this.txtNombreCli);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.label18);
            this.tabPage2.Controls.Add(this.label19);
            this.tabPage2.Controls.Add(this.label20);
            this.tabPage2.Controls.Add(this.label21);
            this.tabPage2.Controls.Add(this.label22);
            this.tabPage2.Controls.Add(this.label23);
            this.tabPage2.Controls.Add(this.label24);
            this.tabPage2.Controls.Add(this.label25);
            this.tabPage2.Controls.Add(this.label26);
            this.tabPage2.Controls.Add(this.label27);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(663, 459);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Habilitar";
            this.tabPage2.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // btnHabilitarEm
            // 
            this.btnHabilitarEm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnHabilitarEm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnHabilitarEm.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHabilitarEm.Image = global::frmReposteria.Properties.Resources.copia_de_seguridad;
            this.btnHabilitarEm.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHabilitarEm.Location = new System.Drawing.Point(144, 62);
            this.btnHabilitarEm.Name = "btnHabilitarEm";
            this.btnHabilitarEm.Size = new System.Drawing.Size(87, 37);
            this.btnHabilitarEm.TabIndex = 215;
            this.btnHabilitarEm.Text = "Habilitar";
            this.btnHabilitarEm.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnHabilitarEm.UseVisualStyleBackColor = false;
            this.btnHabilitarEm.Click += new System.EventHandler(this.btnHabilitarEm_Click);
            // 
            // txtClaveCli
            // 
            this.txtClaveCli.Enabled = false;
            this.txtClaveCli.Location = new System.Drawing.Point(18, 36);
            this.txtClaveCli.Name = "txtClaveCli";
            this.txtClaveCli.Size = new System.Drawing.Size(100, 20);
            this.txtClaveCli.TabIndex = 177;
            // 
            // txtStatusCli
            // 
            this.txtStatusCli.Enabled = false;
            this.txtStatusCli.Location = new System.Drawing.Point(18, 83);
            this.txtStatusCli.Name = "txtStatusCli";
            this.txtStatusCli.Size = new System.Drawing.Size(100, 20);
            this.txtStatusCli.TabIndex = 214;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label2.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(15, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 16);
            this.label2.TabIndex = 213;
            this.label2.Text = "Clave";
            // 
            // txtFotoCli
            // 
            this.txtFotoCli.Enabled = false;
            this.txtFotoCli.Location = new System.Drawing.Point(547, 256);
            this.txtFotoCli.Name = "txtFotoCli";
            this.txtFotoCli.Size = new System.Drawing.Size(100, 20);
            this.txtFotoCli.TabIndex = 212;
            // 
            // ptbFotoCli
            // 
            this.ptbFotoCli.Image = global::frmReposteria.Properties.Resources.imagen;
            this.ptbFotoCli.Location = new System.Drawing.Point(547, 84);
            this.ptbFotoCli.Name = "ptbFotoCli";
            this.ptbFotoCli.Size = new System.Drawing.Size(100, 135);
            this.ptbFotoCli.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ptbFotoCli.TabIndex = 211;
            this.ptbFotoCli.TabStop = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Location = new System.Drawing.Point(547, 225);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(32, 24);
            this.button1.TabIndex = 188;
            this.button1.Text = "...";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // txtCurpCli
            // 
            this.txtCurpCli.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtCurpCli.Enabled = false;
            this.txtCurpCli.Location = new System.Drawing.Point(18, 275);
            this.txtCurpCli.MaxLength = 25;
            this.txtCurpCli.Name = "txtCurpCli";
            this.txtCurpCli.Size = new System.Drawing.Size(100, 20);
            this.txtCurpCli.TabIndex = 181;
            // 
            // btnBuscarCli
            // 
            this.btnBuscarCli.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnBuscarCli.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBuscarCli.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscarCli.Image = global::frmReposteria.Properties.Resources.buscar;
            this.btnBuscarCli.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBuscarCli.Location = new System.Drawing.Point(144, 21);
            this.btnBuscarCli.Name = "btnBuscarCli";
            this.btnBuscarCli.Size = new System.Drawing.Size(75, 32);
            this.btnBuscarCli.TabIndex = 192;
            this.btnBuscarCli.Text = "Buscar";
            this.btnBuscarCli.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBuscarCli.UseVisualStyleBackColor = false;
            this.btnBuscarCli.Click += new System.EventHandler(this.btnBuscarCli_Click);
            // 
            // btnCancelarCli
            // 
            this.btnCancelarCli.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnCancelarCli.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCancelarCli.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelarCli.Image = global::frmReposteria.Properties.Resources.prohibido__1_;
            this.btnCancelarCli.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCancelarCli.Location = new System.Drawing.Point(99, 307);
            this.btnCancelarCli.Name = "btnCancelarCli";
            this.btnCancelarCli.Size = new System.Drawing.Size(75, 33);
            this.btnCancelarCli.TabIndex = 195;
            this.btnCancelarCli.Text = "Cancelar";
            this.btnCancelarCli.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCancelarCli.UseVisualStyleBackColor = false;
            this.btnCancelarCli.Click += new System.EventHandler(this.btnCancelarCli_Click);
            // 
            // btnLimpiarCli
            // 
            this.btnLimpiarCli.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnLimpiarCli.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnLimpiarCli.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpiarCli.Image = global::frmReposteria.Properties.Resources.escoba_de_limpieza_para_suelos__1_;
            this.btnLimpiarCli.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLimpiarCli.Location = new System.Drawing.Point(18, 307);
            this.btnLimpiarCli.Name = "btnLimpiarCli";
            this.btnLimpiarCli.Size = new System.Drawing.Size(75, 33);
            this.btnLimpiarCli.TabIndex = 194;
            this.btnLimpiarCli.Text = "Limpiar";
            this.btnLimpiarCli.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLimpiarCli.UseVisualStyleBackColor = false;
            this.btnLimpiarCli.Click += new System.EventHandler(this.btnLimpiarCli_Click);
            // 
            // btnSalirCli
            // 
            this.btnSalirCli.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnSalirCli.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSalirCli.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalirCli.Image = global::frmReposteria.Properties.Resources.salir_3;
            this.btnSalirCli.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSalirCli.Location = new System.Drawing.Point(180, 307);
            this.btnSalirCli.Name = "btnSalirCli";
            this.btnSalirCli.Size = new System.Drawing.Size(66, 33);
            this.btnSalirCli.TabIndex = 197;
            this.btnSalirCli.Text = "Salir";
            this.btnSalirCli.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSalirCli.UseVisualStyleBackColor = false;
            this.btnSalirCli.Click += new System.EventHandler(this.btnSalirCli_Click);
            // 
            // btnNuevoClie
            // 
            this.btnNuevoClie.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnNuevoClie.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNuevoClie.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNuevoClie.Image = global::frmReposteria.Properties.Resources.agregar_usuario;
            this.btnNuevoClie.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNuevoClie.Location = new System.Drawing.Point(572, 29);
            this.btnNuevoClie.Name = "btnNuevoClie";
            this.btnNuevoClie.Size = new System.Drawing.Size(75, 32);
            this.btnNuevoClie.TabIndex = 190;
            this.btnNuevoClie.Text = "Nuevo";
            this.btnNuevoClie.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNuevoClie.UseVisualStyleBackColor = false;
            this.btnNuevoClie.Click += new System.EventHandler(this.btnNuevoClie_Click);
            // 
            // dgvListaCli
            // 
            this.dgvListaCli.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.dgvListaCli.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvListaCli.Location = new System.Drawing.Point(15, 346);
            this.dgvListaCli.Name = "dgvListaCli";
            this.dgvListaCli.Size = new System.Drawing.Size(616, 93);
            this.dgvListaCli.TabIndex = 210;
            // 
            // txtCodigoPostCli
            // 
            this.txtCodigoPostCli.Enabled = false;
            this.txtCodigoPostCli.Location = new System.Drawing.Point(274, 269);
            this.txtCodigoPostCli.MaxLength = 10;
            this.txtCodigoPostCli.Name = "txtCodigoPostCli";
            this.txtCodigoPostCli.Size = new System.Drawing.Size(100, 20);
            this.txtCodigoPostCli.TabIndex = 187;
            // 
            // txtNumeroCli
            // 
            this.txtNumeroCli.Enabled = false;
            this.txtNumeroCli.Location = new System.Drawing.Point(274, 222);
            this.txtNumeroCli.MaxLength = 25;
            this.txtNumeroCli.Name = "txtNumeroCli";
            this.txtNumeroCli.Size = new System.Drawing.Size(100, 20);
            this.txtNumeroCli.TabIndex = 186;
            // 
            // txtCalleCli
            // 
            this.txtCalleCli.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtCalleCli.Enabled = false;
            this.txtCalleCli.Location = new System.Drawing.Point(274, 177);
            this.txtCalleCli.MaxLength = 45;
            this.txtCalleCli.Name = "txtCalleCli";
            this.txtCalleCli.Size = new System.Drawing.Size(100, 20);
            this.txtCalleCli.TabIndex = 185;
            // 
            // txtColoniaCli
            // 
            this.txtColoniaCli.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtColoniaCli.Enabled = false;
            this.txtColoniaCli.Location = new System.Drawing.Point(274, 128);
            this.txtColoniaCli.MaxLength = 45;
            this.txtColoniaCli.Name = "txtColoniaCli";
            this.txtColoniaCli.Size = new System.Drawing.Size(100, 20);
            this.txtColoniaCli.TabIndex = 184;
            // 
            // txtApellidoPatCli
            // 
            this.txtApellidoPatCli.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtApellidoPatCli.Enabled = false;
            this.txtApellidoPatCli.Location = new System.Drawing.Point(18, 228);
            this.txtApellidoPatCli.MaxLength = 45;
            this.txtApellidoPatCli.Name = "txtApellidoPatCli";
            this.txtApellidoPatCli.Size = new System.Drawing.Size(100, 20);
            this.txtApellidoPatCli.TabIndex = 180;
            // 
            // txtApellidoMatCli
            // 
            this.txtApellidoMatCli.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtApellidoMatCli.Enabled = false;
            this.txtApellidoMatCli.Location = new System.Drawing.Point(18, 180);
            this.txtApellidoMatCli.MaxLength = 45;
            this.txtApellidoMatCli.Name = "txtApellidoMatCli";
            this.txtApellidoMatCli.Size = new System.Drawing.Size(100, 20);
            this.txtApellidoMatCli.TabIndex = 179;
            // 
            // txtTelefonoCli
            // 
            this.txtTelefonoCli.Enabled = false;
            this.txtTelefonoCli.Location = new System.Drawing.Point(274, 84);
            this.txtTelefonoCli.MaxLength = 25;
            this.txtTelefonoCli.Name = "txtTelefonoCli";
            this.txtTelefonoCli.Size = new System.Drawing.Size(100, 20);
            this.txtTelefonoCli.TabIndex = 183;
            // 
            // txtCorreoCli
            // 
            this.txtCorreoCli.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtCorreoCli.Enabled = false;
            this.txtCorreoCli.Location = new System.Drawing.Point(274, 33);
            this.txtCorreoCli.MaxLength = 25;
            this.txtCorreoCli.Name = "txtCorreoCli";
            this.txtCorreoCli.Size = new System.Drawing.Size(100, 20);
            this.txtCorreoCli.TabIndex = 182;
            // 
            // txtNombreCli
            // 
            this.txtNombreCli.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtNombreCli.Enabled = false;
            this.txtNombreCli.Location = new System.Drawing.Point(18, 129);
            this.txtNombreCli.MaxLength = 45;
            this.txtNombreCli.Name = "txtNombreCli";
            this.txtNombreCli.Size = new System.Drawing.Size(100, 20);
            this.txtNombreCli.TabIndex = 178;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label3.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(19, 62);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 16);
            this.label3.TabIndex = 209;
            this.label3.Text = "status";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label4.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(271, 248);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(78, 16);
            this.label4.TabIndex = 208;
            this.label4.Text = "Codigo Postal";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label5.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(271, 203);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 16);
            this.label5.TabIndex = 207;
            this.label5.Text = "Numero";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label18.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(271, 157);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(33, 16);
            this.label18.TabIndex = 206;
            this.label18.Text = "Calle";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label19.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(271, 109);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(45, 16);
            this.label19.TabIndex = 205;
            this.label19.Text = "Colonia";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label20.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(15, 109);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(50, 16);
            this.label20.TabIndex = 204;
            this.label20.Text = "Nombre";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(24, 321);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(0, 13);
            this.label21.TabIndex = 203;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label22.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(15, 208);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(94, 16);
            this.label22.TabIndex = 202;
            this.label22.Text = "Apellido Paterno";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label23.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(15, 158);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(99, 16);
            this.label23.TabIndex = 201;
            this.label23.Text = "Apellido Materno";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label24.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(271, 63);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(55, 16);
            this.label24.TabIndex = 200;
            this.label24.Text = "Telefono";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label25.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(271, 13);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(43, 16);
            this.label25.TabIndex = 199;
            this.label25.Text = "Correo";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label26.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(15, 256);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(32, 16);
            this.label26.TabIndex = 198;
            this.label26.Text = "Curp";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(29, 322);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(0, 13);
            this.label27.TabIndex = 189;
            // 
            // frmCliente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(694, 510);
            this.Controls.Add(this.tabControl1);
            this.Name = "frmCliente";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmCliente";
            this.Load += new System.EventHandler(this.frmCliente_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptbFotoC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbglistaC)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptbFotoCli)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaCli)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox txtClaveC;
        private System.Windows.Forms.TextBox txtStatusC;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox txtFotoC;
        private System.Windows.Forms.PictureBox ptbFotoC;
        private System.Windows.Forms.Button btnFotoC;
        private System.Windows.Forms.TextBox txtCurpC;
        private System.Windows.Forms.Button btnBuscarC;
        private System.Windows.Forms.Button btnCancelarC;
        private System.Windows.Forms.Button btnLimpiarC;
        private System.Windows.Forms.Button btnSalirC;
        private System.Windows.Forms.Button btnBorrarC;
        private System.Windows.Forms.Button btnModificarC;
        private System.Windows.Forms.Button btnGuardarC;
        private System.Windows.Forms.Button btnNuevoC;
        private System.Windows.Forms.DataGridView dbglistaC;
        private System.Windows.Forms.TextBox txtCodigoPostC;
        private System.Windows.Forms.TextBox txtNumeroC;
        private System.Windows.Forms.TextBox txtCalleC;
        private System.Windows.Forms.TextBox txtColoniaC;
        private System.Windows.Forms.TextBox txtApellidoPatC;
        private System.Windows.Forms.TextBox txtApellidoMatC;
        private System.Windows.Forms.TextBox txtTelefonoC;
        private System.Windows.Forms.TextBox txtCorreoC;
        private System.Windows.Forms.TextBox txtNombreC;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox txtClaveCli;
        private System.Windows.Forms.TextBox txtStatusCli;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtFotoCli;
        private System.Windows.Forms.PictureBox ptbFotoCli;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtCurpCli;
        private System.Windows.Forms.Button btnBuscarCli;
        private System.Windows.Forms.Button btnCancelarCli;
        private System.Windows.Forms.Button btnLimpiarCli;
        private System.Windows.Forms.Button btnSalirCli;
        private System.Windows.Forms.Button btnNuevoClie;
        private System.Windows.Forms.DataGridView dgvListaCli;
        private System.Windows.Forms.TextBox txtCodigoPostCli;
        private System.Windows.Forms.TextBox txtNumeroCli;
        private System.Windows.Forms.TextBox txtCalleCli;
        private System.Windows.Forms.TextBox txtColoniaCli;
        private System.Windows.Forms.TextBox txtApellidoPatCli;
        private System.Windows.Forms.TextBox txtApellidoMatCli;
        private System.Windows.Forms.TextBox txtTelefonoCli;
        private System.Windows.Forms.TextBox txtCorreoCli;
        private System.Windows.Forms.TextBox txtNombreCli;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button btnHabilitarEm;
    }
}