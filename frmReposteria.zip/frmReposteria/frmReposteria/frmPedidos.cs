﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace frmReposteria
{
    public partial class frmPedidos : Form
    {
        public frmPedidos()
        {
            InitializeComponent();
        }
        private ArrayList lista = new ArrayList();
        private Pedidos pedi;


        private Boolean siExiste(int idPedidos)
        {
            Boolean existe = false;
            foreach (Pedidos co in lista)
            {
                if (co.IdPedidos == int.Parse(txtClaveP.Text))
                {
                    existe = true;
                }
            }


            return existe;
        }

        private void frmPedidos_Load(object sender, EventArgs e)
        {
            DBPedidos miBase = new DBPedidos();
            //Limpiar el DtaGriView
            dgvListaP.DataSource = null;
            DataTable datos = miBase.ConsultarTodos();
            //Poner Los Datos de Consulta en el DataGriView 
            dgvListaP.DataSource = datos;

            DBPedidos miBasee = new DBPedidos();
            //Limpiar el DtaGriView
            dgvListaH.DataSource = null;
            DataTable datoss = miBasee.ConsultarTodosDeshabilitar();
            //Poner Los Datos de Consulta en el DataGriView 

            dgvListaH.DataSource = datoss;
        }

        private void btnNuevoP_Click(object sender, EventArgs e)
        {
           

        }

        private void btnModificarP_Click(object sender, EventArgs e)
        {
           
        }

        private void btnBorrarP_Click(object sender, EventArgs e)
        {
        }

        private void btnSalirP_Click(object sender, EventArgs e)
        {
        }

        private void btnCancelarP_Click(object sender, EventArgs e)
        {
           
        }

        private void btnLimpiarP_Click(object sender, EventArgs e)
        {
          
        }

        private void btnGuardarP_Click(object sender, EventArgs e)
        {
           
        }

        private void btnBuscarP_Click(object sender, EventArgs e)
        {
           
        }

        private void btnFotoP_Click(object sender, EventArgs e)
        {
           
        }

        private void txtFotoP_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtIdPedidosP_KeyPress(object sender, KeyPressEventArgs e)
        {
           
        }

        private void txtAnticipoP_KeyPress(object sender, KeyPressEventArgs e)
        {
           
        }

        private void cmbStatusP_KeyPress(object sender, KeyPressEventArgs e)
        {
           
        }

        private void btnBuscarP_Click_1(object sender, EventArgs e)
        {
            DBPedidos miBase = new DBPedidos();

            if (txtClaveP.Text != "")
            {
                DataTable datos = miBase.Consultar(int.Parse(txtClaveP.Text));
                if (datos.Rows.Count > 0)
                {

                    txtDescripcionP.Text = datos.Rows[0]["descripcion"].ToString();
                    dtpFechaP.Text = datos.Rows[0]["fechaPedido"].ToString();
                    txtAnticipoP.Text = datos.Rows[0]["anticipo"].ToString();
                    txtStatusp.Text = datos.Rows[0]["status"].ToString();
                    txtFotoP.Text = datos.Rows[0]["foto"].ToString();

                    ptbFotoP.Image = Image.FromFile(txtFotoP.Text);

                    txtClaveP.Enabled = false;
                    txtDescripcionP.Enabled = true;
                  
                    dtpFechaP.Enabled = true;
                    txtAnticipoP.Enabled = true;
                    btnBorrarP.Enabled = true;
                    btnModificarP.Enabled = true;

                }
                else
                {
                    MessageBox.Show("No hay registro con esa Clave", "Pedido ♥");
                }

            }
        }

        private void btnNuevoP_Click_1(object sender, EventArgs e)
        {
            btnGuardarP.Enabled = true;
            btnBorrarP.Enabled = true;


            txtClaveP.Enabled = true;
            txtDescripcionP.Enabled = true;
            dtpFechaP.Enabled = true;
            txtAnticipoP.Enabled = true;
           

            btnFotoP.Enabled = true;
        }

        private void btnFotoP_Click_1(object sender, EventArgs e)
        {
            OpenFileDialog foto = new OpenFileDialog();
            foto.InitialDirectory = "C:\\";
            foto.ShowDialog();
            txtFotoP.Text = foto.FileName;
            ptbFotoP.ImageLocation = foto.FileName;
        }

        private void btnGuardarP_Click_1(object sender, EventArgs e)
        {
            Boolean exito = false;


            if (txtClaveP.Text.Equals("")) { MessageBox.Show("Faltó Capturar la Clave del Pedido!!", "Pedido ♥"); exito = true; }

            if (txtDescripcionP.Text.Equals("")) { MessageBox.Show("Faltó Capturar La Descripción!!", "Pedido ♥"); exito = true; }
            if (dtpFechaP.Text.Equals("")) { MessageBox.Show("Faltó Capturar la Fecha del Pedidos!!", "Pedido ♥"); exito = true; }
            if (txtAnticipoP.Text.Equals("")) { MessageBox.Show("Faltó Capturar el Anticipo!!", "Pedido ♥"); exito = true; }
           
            if (txtFotoP.Text.Equals("")) { MessageBox.Show("Faltó Capturar La Foto!!", "Pedido ♥"); exito = true; }

            if (exito == false)
            {
                DBPedidos miBase = new DBPedidos();
                if (txtClaveH.Text == txtClaveH.Text)
                {
                    DataTable data = miBase.Consultar(int.Parse(txtClaveP.Text));
                    if (data.Rows.Count > 0)
                    {
                        MessageBox.Show("Ya Existe la Clave", "Pedido ♥");
                    }
                    else
                    {
                        Pedidos es = new Pedidos();
                        es.Clave = int.Parse(txtClaveP.Text);
                        es.Descripcion = txtDescripcionP.Text;

                        es.Foto = txtFotoP.Text;
                        es.Anticipo = float.Parse(txtAnticipoP.Text);
                      
                        ptbFotoP.Image = Image.FromFile(txtFotoP.Text);

                        es.FechaPedido = dtpFechaP.Value.Year + "-" + dtpFechaP.Value.Month + "-" + dtpFechaP.Value.Day;

                        miBase.agregarUsandoParametros(es);
                        MessageBox.Show("Se Agregó con Éxito", "Pedido ♥");
                        //limppia el dato griview dgv 
                        dgvListaP.DataSource = null;

                        DataTable datos = miBase.ConsultarTodos();
                        //Pone todos los datos de connsulta en el dgv
                        dgvListaP.DataSource = datos;
                        txtClaveP.Text = "";
                        txtDescripcionP.Text = "";
                        dtpFechaP.Text = "";
                        txtAnticipoP.Text = "";
                        txtStatusp.Text = "";

                        txtFotoP.Text = "";
                        ptbFotoP.Image = frmReposteria.Properties.Resources.imagen_4;

                    }

                }
                else
                {
                    MessageBox.Show("Faltó Capturar la Clave", "Producto ♥");
                    txtClaveH.Focus();
                }

            }
        }

        private void btnLimpiarP_Click_1(object sender, EventArgs e)
        {
            txtClaveP.Text = "";
            txtDescripcionP.Text = "";
            txtAnticipoP.Text = "";
            txtStatusp.Text = "";
            txtFotoP.Text = "";
            dtpFechaP.Text = "";
            txtFotoP.Text = "";
            ptbFotoP.Image = frmReposteria.Properties.Resources.imagen_4;

            txtClaveP.Enabled = true;
            txtDescripcionP.Enabled = false;
            txtAnticipoP.Enabled = false;
            txtStatusp.Enabled = false;
            txtFotoP.Enabled = false;
            btnBorrarP.Enabled = false;
            btnModificarP.Enabled = false;
        }

        private void btnModificarP_Click_1(object sender, EventArgs e)
        {
            DBPedidos mibase = new DBPedidos();

            Pedidos doc = new Pedidos();

            txtClaveH.Enabled = false;


            doc.Clave = int.Parse(txtClaveP.Text);
            doc.Descripcion = txtDescripcionP.Text;
            doc.FechaPedido = dtpFechaP.Text;
            doc.Anticipo = float.Parse(txtAnticipoP.Text);
         
            doc.Foto = txtFotoP.Text;

            doc.FechaPedido = dtpFechaP.Value.Year + "-" + dtpFechaP.Value.Month + "-" + dtpFechaP.Value.Day;


            mibase.Actualizar(doc);
            dgvListaP.DataSource = null;
            DataTable datos = mibase.ConsultarTodos();
            dgvListaP.DataSource = datos;


            MessageBox.Show("Se ralizó la Modificación con éxito", "Pedido ♥");
        }

        private void btnCancelarP_Click_1(object sender, EventArgs e)
        {
            txtClaveP.Text = "";
            txtStatusp.Text = "";
            txtDescripcionP.Text = "";
            txtAnticipoP.Text = "";
            dtpFechaP.Text = "";
            txtFotoP.Text = "";
            ptbFotoP.Image = frmReposteria.Properties.Resources.imagen_4;

            txtClaveH.Enabled = false;
            txtDescripcionP.Enabled = false;
            txtStatusp.Enabled = false;
            txtAnticipoP.Enabled = false;
            txtFotoP.Enabled = false;
            btnBorrarP.Enabled = false;
            btnModificarP.Enabled = false;
        }

        private void btnSalirP_Click_1(object sender, EventArgs e)
        {

            DialogResult tipo;
            tipo = MessageBox.Show("¿Deseas Salir?", "Pedidos ♥",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question,
                MessageBoxDefaultButton.Button2);
            if (tipo == DialogResult.Yes) this.Close();
        }

        private void btnBorrarP_Click_1(object sender, EventArgs e)
        {
            DialogResult res = MessageBox.Show("¿Deseas borrar el registro?", " Pedido ♥",
       MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);

            if (res == DialogResult.Yes)
            {
                DBPedidos mibase = new DBPedidos();

                Pedidos docc = new Pedidos();

                docc.Clave = int.Parse(txtClaveP.Text);
                docc.Descripcion = txtDescripcionP.Text;
                docc.Anticipo = float.Parse(txtAnticipoP.Text);

                mibase.Deshabilitar(docc);

                txtClaveP.Text = "";
                txtDescripcionP.Text = "";
                txtStatusp.Text = "";
                txtAnticipoP.Text = "";
                dtpFechaP.Text = "";
                txtFotoP.Text = "";



                txtFotoP.Enabled = false;
                txtDescripcionP.Enabled = false;

                ptbFotoP.Image = frmReposteria.Properties.Resources.imagen_4;
                DBPedidos miBase = new DBPedidos();
                //Limpiar el DtaGriView
                dgvListaP.DataSource = null;
                DataTable datos = miBase.ConsultarTodos();
                //Poner Los Datos de Consulta en el DataGriView 
                dgvListaP.DataSource = datos;

                DBPedidos miBasee = new DBPedidos();
                //Limpiar el DtaGriView
                dgvListaH.DataSource = null;
                DataTable datoss = miBasee.ConsultarTodosDeshabilitar();
                //Poner Los Datos de Consulta en el DataGriView 

                dgvListaH.DataSource = datoss;
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            DBPedidos miBase = new DBPedidos();



            if (txtClaveH.Text != "")
            {
                DataTable datos = miBase.ConsultarH(int.Parse(txtClaveH.Text));
                if (datos.Rows.Count > 0)
                {

                    txtdescrH.Text = datos.Rows[0]["descripcion"].ToString();
                    txtAntiH.Text = datos.Rows[0]["anticipo"].ToString();

                    dtpFechaH.Text = datos.Rows[0]["FechaPedido"].ToString();
                    txtStatusH.Text = datos.Rows[0]["Status"].ToString();



                    txtFotoH.Text = datos.Rows[0]["foto"].ToString();
                    ptbFotoH.Image = Image.FromFile(txtFotoH.Text);



                  
                    txtdescrH.Enabled = false;
                    txtStatusH.Enabled = false;
                    dtpFechaH.Enabled = false;
                    txtAntiH.Enabled = false;



                }

                else
                {
                    MessageBox.Show("No hay registro con esa Clave", "Pedido ♥");
                }

            }
            else
            {
                MessageBox.Show("Faltó capturar la Clave", "Pedido ♥");
                txtClaveH.Focus();
            }
        }

        private void btnHabilitarTGG_Click(object sender, EventArgs e)
        {
            DBPedidos mibasee = new DBPedidos();

            Pedidos dooc = new Pedidos();

            dooc.Clave = int.Parse(txtClaveH.Text);
            dooc.Descripcion = txtdescrH.Text;
            dooc.Anticipo = float.Parse(txtAntiH.Text);
            dooc.Foto = txtFotoH.Text;
            dooc.FechaPedido = dtpFechaH.Text;

            mibasee.Habilitar(dooc);



            txtClaveH.Text = "";
            txtStatusH.Text = "";
            txtdescrH.Text = "";
            txtAntiH.Text = "";
            dtpFechaH.Value = DateTime.Now;
            txtFotoH.Text = "";
            ptbFotoH.Image = frmReposteria.Properties.Resources.imagen_4;
            txtClaveH.Enabled = false;
            txtdescrH.Enabled = false;
            txtStatusH.Enabled = false;
            dtpFechaH.Enabled = false;
            txtAntiH.Enabled = false;
            btnHabilitarTGG.Enabled = false;
            DBPedidos miBase = new DBPedidos();
            //Limpiar el DtaGriView
            dgvListaP.DataSource = null;
            DataTable datos = miBase.ConsultarTodos();
            //Poner Los Datos de Consulta en el DataGriView 
            dgvListaP.DataSource = datos;

            DBPedidos miBasee = new DBPedidos();
            //Limpiar el DtaGriView
            dgvListaH.DataSource = null;
            DataTable datoss = miBasee.ConsultarTodosDeshabilitar();
            //Poner Los Datos de Consulta en el DataGriView 

            dgvListaH.DataSource = datoss;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            txtClaveH.Text = "";
            txtdescrH.Text = "";
            txtAntiH.Text = "";
            txtStatusH.Text = "";

            dtpFechaH.Text = "";
            txtFotoH.Text = "";
            ptbFotoH.Image = frmReposteria.Properties.Resources.imagen_4;

            txtClaveH.Enabled = true;
            txtdescrH.Enabled = false;
            txtAntiH.Enabled = false;
            txtStatusH.Enabled = false;
            txtFotoH.Enabled = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            txtClaveH.Text = "";
            txtdescrH.Text = "";
            txtAntiH.Text = "";
            txtStatusH.Text = "";

            dtpFechaH.Text = "";
            txtFotoH.Text = "";
            ptbFotoH.Image = frmReposteria.Properties.Resources.imagen_4;

            txtClaveH.Enabled = true;
            txtdescrH.Enabled = false;
            txtAntiH.Enabled = false;
            txtStatusH.Enabled = false;
            txtFotoH.Enabled = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult tipo;
            tipo = MessageBox.Show("¿Deseas Salir?", "Pedidos ♥",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question,
                MessageBoxDefaultButton.Button2);
            if (tipo == DialogResult.Yes) this.Close();
        }

        private void txtClaveP_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void txtAnticipoP_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
           

            txtClaveH.Enabled = true;
          
        }
    }
}

