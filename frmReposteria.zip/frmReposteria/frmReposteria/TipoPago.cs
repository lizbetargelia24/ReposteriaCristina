﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace frmReposteria
{
    class TipoPago 
    {

            private int idTipoPago;
            private string descripcion;
            private int status;
            private int clave;

            public TipoPago()
            {
            clave = this.generaTipoPago2();
            idTipoPago = this.generaTipoPago();
                this.descripcion = "";
            this.status = 0;
          
            }

            public TipoPago( int idTipoPago, string descripcion, int status, int clave) 
            {
                this.idTipoPago = idTipoPago;
            this.descripcion = descripcion;
            this.status = status;
            this.clave = clave;
            }
        public int Clave
        {
            set { this.clave = value; }
            get { return this.clave; }
        }
        public int IdTipoPago
            {
                set {this.idTipoPago = value;}
                get { return this.idTipoPago; }
             }
            
            public string Descripcion
            {
                set { this.descripcion = value; }
                get { return this.descripcion; }
            }
        public int Status
        {
            set { this.status = value; }
            get { return this.status; }
        }
        public int generaTipoPago()
        {
            //genera valores aleatorios enteros positivos no mayores a 32000
            Random x = new Random();
            return x.Next(32000);
        }
        public int generaTipoPago2()
        {
            //genera valores aleatorios enteros positivos no mayores a 32000
            Random x = new Random();
            return x.Next(25000);
        }
    }
}
