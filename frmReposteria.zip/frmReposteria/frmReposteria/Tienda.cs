﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace frmReposteria
{
    class Tienda
    {

        private int idTipoPago;
        private string nombre;
        private int status;
        private int clave;

        public Tienda()
        {
            this.idTipoPago = 0;
            this.clave = 0;
            this.nombre= "";
            this.status = 0;

        }

        public Tienda(int idTipoPago, string nombre, int status, int clave)
        {
            this.idTipoPago = idTipoPago;
            this.nombre = nombre;
            this.status = status;
            this.clave = clave;
        }
        public int Clave
        {
            set { this.clave = value; }
            get { return this.clave; }
        }
        public int IdTipoPago
        {
            set { this.idTipoPago = value; }
            get { return this.idTipoPago; }
        }

        public string Nombre
        {
            set { this.nombre = value; }
            get { return this.nombre; }
        }
        public int Status
        {
            set { this.status = value; }
            get { return this.status; }
        }
    }
}
