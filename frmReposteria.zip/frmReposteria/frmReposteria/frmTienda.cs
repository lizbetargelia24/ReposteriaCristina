﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmReposteria
{
    public partial class frmTienda : Form
    {
        public frmTienda()
        {
            InitializeComponent();
        }

        private void frmTienda_Load(object sender, EventArgs e)
        {
            DBTienda miBase = new DBTienda();
            //Limpiar el DtaGriView
            dgvListaT.DataSource = null;
            DataTable datos = miBase.ConsultarTodos4();
            //Poner Los Datos de Consulta en el DataGriView 

            dgvListaT.DataSource = datos;

            DBTienda miBasee = new DBTienda();
            //Limpiar el DtaGriView
            dgvListaTG.DataSource = null;
            DataTable datoss = miBasee.ConsultarTodosDeshabilitar();
            //Poner Los Datos de Consulta en el DataGriView 

            dgvListaTG.DataSource = datoss;
        }

        private void btnNuevoT_Click(object sender, EventArgs e)
        {
            btnGuardarT.Enabled = true;







            txtClaveT.Enabled = true;

            txtNombreT.Enabled = true;
        }

        private void btnGuardarT_Click(object sender, EventArgs e)
        {
            Boolean exito = false;
            if (txtClaveT.Text.Equals("")) { MessageBox.Show("Falto Capturar la Clave", "Tienda ♥"); exito = true; }

            if (txtNombreT.Text.Equals("")) { MessageBox.Show("Falto capturar el nombre", "Tienda ♥"); exito = true; }


            if (exito == false)
            {
                DBTienda miBase = new DBTienda();
                if (txtClaveT.Text == txtClaveT.Text)
                {
                    DataTable data = miBase.Consultar(int.Parse(txtClaveT.Text));
                    if (data.Rows.Count > 0)
                    {
                        MessageBox.Show("Ya existe la clave", "Tienda ♥");
                    }
                    else
                    {


                        Tienda es = new Tienda();

                        es.Clave = int.Parse(txtClaveT.Text);
                        es.Nombre = txtNombreT.Text;
                        miBase.agregarUsandoParametros(es);
                        MessageBox.Show("Se guardó con exito", "Tienda ♥");

                        dgvListaT.DataSource = null;

                        DataTable datos2 = miBase.ConsultarTodos4();

                        dgvListaT.DataSource = datos2;
                        txtClaveT.Text = "";

                        txtNombreT.Text = "";
                        cmbStatusT.Text = "";
                    }
                }
                else
                {
                    MessageBox.Show("Faltó capturar la clave", "Tienda ♥");
                    txtClaveT.Focus();
                }
            }
        }

        private void btnModificarT_Click(object sender, EventArgs e)
        {
            DBTienda mibase = new DBTienda();

            Tienda doc = new Tienda();

            cmbStatusT.Enabled = false;

            doc.Clave = int.Parse(txtClaveT.Text);
            doc.Nombre = txtNombreT.Text;
            mibase.Actualizar(doc);
            dgvListaT.DataSource = null;
            DataTable datos2 = mibase.ConsultarTodos4();
            dgvListaT.DataSource = datos2;


            MessageBox.Show("Se Realizó La Actualización", "Tienda ♥");
        }

        private void btnBorrarT_Click(object sender, EventArgs e)
        {

            DialogResult res = MessageBox.Show("¿Deseas borrar el registro?", "Tienda ♥",
MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);

            if (res == DialogResult.Yes)
            {
                DBTienda mibase = new DBTienda();

                Tienda docc = new Tienda();

                docc.Clave = int.Parse(txtClaveT.Text);
                docc.Nombre = txtNombreT.Text;

                mibase.Deshabilitar(docc);

                txtClaveT.Text = "";

                txtNombreT.Text = "";
                cmbStatusT.Text = "";

                txtClaveT.Enabled = true;
                btnGuardarT.Enabled = true;

                DBTienda miBase = new DBTienda();
                //Limpiar el DtaGriView
                dgvListaT.DataSource = null;
                DataTable datos = miBase.ConsultarTodos4();
                //Poner Los Datos de Consulta en el DataGriView 

                dgvListaT.DataSource = datos;

                DBTienda miBasee = new DBTienda();
                //Limpiar el DtaGriView
                dgvListaTG.DataSource = null;
                DataTable datoss = miBasee.ConsultarTodosDeshabilitar();
                //Poner Los Datos de Consulta en el DataGriView 

                dgvListaTG.DataSource = datoss;
            }
        }

        private void btnBuscarT_Click(object sender, EventArgs e)
        {
            DBTienda miBase = new DBTienda();

            if (txtClaveT.Text != "")
            {
                DataTable datos = miBase.Consultar(int.Parse(txtClaveT.Text));
                if (datos.Rows.Count > 0)
                {
                    txtNombreT.Text = datos.Rows[0]["Nombre"].ToString();
                    cmbStatusT.Text = datos.Rows[0]["Status"].ToString();
                    txtClaveT.Enabled = false;
                    txtNombreT.Enabled = true;
                    btnBorrarT.Enabled = true;
                    btnGuardarT.Enabled = true;
                    btnModificarT.Enabled = true;
                }
                else
                {
                    MessageBox.Show("No hay registro con esa Clave", "Tienda ♥");
                }

            }

            else
            {
                MessageBox.Show("Faltó capturar la clave", "Tienda ♥");
                txtClaveT.Focus();
            }
        }

        private void btnLimpiarT_Click(object sender, EventArgs e)
        {
            txtClaveT.Text = "";

            txtNombreT.Text = "";
            cmbStatusT.Text = "";
            txtNombreT.Enabled = false;
            btnGuardarT.Enabled = false;
            btnModificarT.Enabled = false;
            btnBorrarT.Enabled = false;
            txtClaveT.Enabled = true;
            cmbStatusT.Enabled = false;
            btnBuscarT.Enabled = true;
        }

        private void btnCancelarT_Click(object sender, EventArgs e)
        {
            txtClaveT.Text = "";

            txtNombreT.Text = "";
            cmbStatusT.Text = "";

            txtClaveT.Enabled = false;
            cmbStatusT.Enabled = false;

            txtNombreT.Enabled = false;
            btnModificarT.Enabled = false;
            btnBorrarT.Enabled = false;
            btnGuardarT.Enabled = false;
        }

        private void btnSalirT_Click(object sender, EventArgs e)
        {
            DialogResult tipo;
            tipo = MessageBox.Show("¿Deseas Salir?", "Tienda ♥",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question,
                MessageBoxDefaultButton.Button2);
            if (tipo == DialogResult.Yes) this.Close();
        }

        private void btnBuscarTG_Click(object sender, EventArgs e)
        {
            DBTienda miBase = new DBTienda();

            if (txtClaveTGG.Text != "")
            {
                DataTable datos = miBase.ConsultarH(int.Parse(txtClaveTGG.Text));
                if (datos.Rows.Count > 0)
                {
                    txtNombreTGG.Text = datos.Rows[0]["Nombre"].ToString();
                    txtStatusTGG.Text = datos.Rows[0]["Status"].ToString();
                    txtClaveTGG.Enabled = true;


                }
                else
                {
                    MessageBox.Show("No hay registro con esa clave", "Tienda ♥");
                }

            }
        }

        private void btnHabilitarTG_Click(object sender, EventArgs e)
        {
            DBTienda mibase = new DBTienda();

            Tienda docc = new Tienda();

            docc.Clave = int.Parse(txtClaveTGG.Text);
            docc.Nombre = txtNombreTGG.Text;

            mibase.Habilitar(docc);

            txtClaveTGG.Text = "";

            txtNombreTGG.Text = "";
            txtStatusTGG.Text = "";

    

            DBTienda miBase = new DBTienda();
            //Limpiar el DtaGriView
            dgvListaT.DataSource = null;
            DataTable datos = miBase.ConsultarTodos4();
            //Poner Los Datos de Consulta en el DataGriView 

            dgvListaT.DataSource = datos;

            DBTienda miBasee = new DBTienda();
            //Limpiar el DtaGriView
            dgvListaTG.DataSource = null;
            DataTable datoss = miBasee.ConsultarTodosDeshabilitar();
            //Poner Los Datos de Consulta en el DataGriView 

            dgvListaTG.DataSource = datoss;
        }

        private void btnSalirTG_Click(object sender, EventArgs e)
        {
            DialogResult tipo;
            tipo = MessageBox.Show("¿Deseas Salir?", "Tienda ♥",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question,
                MessageBoxDefaultButton.Button2);
            if (tipo == DialogResult.Yes) this.Close();
        }

        private void btnCancelarTG_Click(object sender, EventArgs e)
        {
            txtClaveTGG.Text = "";

            txtNombreTGG.Text = "";
            txtStatusTGG.Text = "";
            txtNombreTGG.Enabled = false;


            txtStatusTGG.Enabled = false;
            btnBuscarTG.Enabled = true;
        }

        private void btnLimpiarTG_Click(object sender, EventArgs e)
        {
            txtClaveTGG.Text = "";

            txtNombreTGG.Text = "";
            txtStatusTGG.Text = "";
            txtNombreTGG.Enabled = false;
          
         
            txtStatusTGG.Enabled = false;
            btnBuscarTG.Enabled = true;
        }

        private void btnNuevoTG_Click(object sender, EventArgs e)
        {
            txtClaveTGG.Enabled = true;
        }

        private void txtClaveT_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }
    }
}
