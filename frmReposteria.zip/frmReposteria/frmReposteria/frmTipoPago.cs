﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace frmReposteria
{
    public partial class frmTipoPago : Form
    {
        public frmTipoPago()
        {
            InitializeComponent();

        }
       

        private void btnNuevoPa_Click(object sender, EventArgs e)
        {

          
        }

        private void btnLimpiarPa_Click(object sender, EventArgs e)
        {
          
        }

        private void btnCancelarPa_Click(object sender, EventArgs e)
        {
            
        }

        private void btnSalirPa_Click(object sender, EventArgs e)
        {
          
        }

        private void btnGuardarPa_Click(object sender, EventArgs e)
        {
            
        }
        private void btnModificarPa_Click(object sender, EventArgs e)
        {
           
        }

        private void btnBorrarPa_Click(object sender, EventArgs e)
        {

           
        }

        private void btnBuscarPa_Click(object sender, EventArgs e)
        {
           

        }

        private void txtIdTipoPagoPa_KeyPress(object sender, KeyPressEventArgs e)
        {
            
        }

        private void cmbDescripcionPa_KeyPress(object sender, KeyPressEventArgs e)
        {
            
        }

        private void cmbStatusTG_KeyPress(object sender, KeyPressEventArgs e)
        {
            
        }

        private void txtClaveTG_KeyPress(object sender, KeyPressEventArgs e)
        {
            
        }

        private void frmTipoPago_Load(object sender, EventArgs e)
        {
            DBTipoPago miBase = new DBTipoPago();
            //Limpiar el DtaGriView
            dgvListaPa.DataSource = null;
            DataTable datos = miBase.ConsultarTodos4();
            //Poner Los Datos de Consulta en el DataGriView 

            dgvListaPa.DataSource = datos;

            DBTipoPago miBasee = new DBTipoPago();
            //Limpiar el DtaGriView
            dgvListaTGG.DataSource = null;
            DataTable datoss = miBasee.ConsultarTodosDeshabilitar();
            //Poner Los Datos de Consulta en el DataGriView 

            dgvListaTGG.DataSource = datoss;

        }

        private void btnNuevoPa_Click_1(object sender, EventArgs e)
        {
            btnGuardarPa.Enabled = true;







            txtClaveTG.Enabled = true;

            txtDescripcionPa.Enabled = true;

        }

        private void btnGuardarPa_Click_1(object sender, EventArgs e)
        {
            Boolean exito = false;
            if (txtClaveTG.Text.Equals("")) { MessageBox.Show("Falto Capturar la Clave", "Tipo Pago ♥"); exito = true; }

            if (txtDescripcionPa.Text.Equals("")) { MessageBox.Show("Falto capturar la Descripción", "Tipo Pago ♥"); exito = true; }


            if (exito == false)
            {
                DBTipoPago miBase = new DBTipoPago();
                if (txtClaveTG.Text == txtClaveTG.Text)
                {
                    DataTable data = miBase.Consultar(int.Parse(txtClaveTG.Text));
                    if (data.Rows.Count > 0)
                    {
                        MessageBox.Show("Ya existe la clave", "Tipo Pago ♥");
                    }
                    else
                    {


                        TipoPago es = new TipoPago();

                        es.Clave = int.Parse(txtClaveTG.Text);
                        es.Descripcion = txtDescripcionPa.Text;
                        miBase.agregarUsandoParametros(es);
                        MessageBox.Show("Se guardó con exito", "Tipo Pago ♥");

                        dgvListaPa.DataSource = null;

                        DataTable datos2 = miBase.ConsultarTodos4();

                        dgvListaPa.DataSource = datos2;
                        txtClaveTG.Text = "";

                        txtDescripcionPa.Text = "";
                        cmbStatusTG.Text = "";
                    }
                }
                else
                {
                    MessageBox.Show("Faltó capturar la clave", "Tipo Pago ♥");
                    txtClaveTG.Focus();
                }
            }

        }

        private void btnModificarPa_Click_1(object sender, EventArgs e)
        {
            DBTipoPago mibase = new DBTipoPago();

            TipoPago doc = new TipoPago();

            cmbStatusTG.Enabled = false;

            doc.Clave = int.Parse(txtClaveTG.Text);
            doc.Descripcion = txtDescripcionPa.Text;
            mibase.Actualizar(doc);
            dgvListaPa.DataSource = null;
            DataTable datos2 = mibase.ConsultarTodos4();
            dgvListaPa.DataSource = datos2;


            MessageBox.Show("Se Realizó La Actualización", "Tipo Pago ♥");

        }

        private void btnBorrarPa_Click_1(object sender, EventArgs e)
        {

            DialogResult res = MessageBox.Show("¿Deseas borrar el registro?", "Tipo Pago ♥",
MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);

            if (res == DialogResult.Yes)
            {
                DBTipoPago mibase = new DBTipoPago();

                TipoPago docc = new TipoPago();

                docc.Clave = int.Parse(txtClaveTG.Text);
                docc.Descripcion = txtDescripcionPa.Text;

                mibase.Deshabilitar(docc);

                txtClaveTG.Text = "";

                txtDescripcionPa.Text = "";
                cmbStatusTG.Text = "";

                txtClaveTG.Enabled = true;
                btnGuardarPa.Enabled = true;

                DBTipoPago miBase = new DBTipoPago();
                //Limpiar el DtaGriView
                dgvListaPa.DataSource = null;
                DataTable datos = miBase.ConsultarTodos4();
                //Poner Los Datos de Consulta en el DataGriView 

                dgvListaPa.DataSource = datos;

                DBTipoPago miBasee = new DBTipoPago();
                //Limpiar el DtaGriView
                dgvListaTGG.DataSource = null;
                DataTable datoss = miBasee.ConsultarTodosDeshabilitar();
                //Poner Los Datos de Consulta en el DataGriView 

                dgvListaTGG.DataSource = datoss;
            }

        }

        private void btnBuscarPa_Click_1(object sender, EventArgs e)
        {
            DBTipoPago miBase = new DBTipoPago();

            if (txtClaveTG.Text != "")
            {
                DataTable datos = miBase.Consultar(int.Parse(txtClaveTG.Text));
                if (datos.Rows.Count > 0)
                {
                    txtDescripcionPa.Text = datos.Rows[0]["Descripcion"].ToString();
                    cmbStatusTG.Text = datos.Rows[0]["Status"].ToString();
                    txtClaveTG.Enabled = false;
                    txtDescripcionPa.Enabled = true;
                    btnBorrarPa.Enabled = true;
                    btnGuardarPa.Enabled = true;
                    btnModificarPa.Enabled = true;
                }
                else
                {
                    MessageBox.Show("No hay registro con esa Clave", "Tipo Pago ♥");
                }

            }

            else
            {
                MessageBox.Show("Faltó capturar la clave", "Tipo Pago ♥");
                txtClaveTG.Focus();
            }

        }

        private void btnLimpiarPa_Click_1(object sender, EventArgs e)
        {
            txtClaveTG.Text = "";

            txtDescripcionPa.Text = "";
            cmbStatusTG.Text = "";
            txtDescripcionPa.Enabled = false;
            btnGuardarPa.Enabled = false;
            btnModificarPa.Enabled = false;
            btnBorrarPa.Enabled = false;
            txtClaveTG.Enabled = true;
            cmbStatusTG.Enabled = false;
            btnBuscarPa.Enabled = true;

        }

        private void btnCancelarPa_Click_1(object sender, EventArgs e)
        {
            txtClaveTG.Text = "";

            txtDescripcionPa.Text = "";
            cmbStatusTG.Text = "";

            txtClaveTG.Enabled = false;
            cmbStatusTG.Enabled = false;

            txtDescripcionPa.Enabled = false;
            btnModificarPa.Enabled = false;
            btnBorrarPa.Enabled = false;
            btnGuardarPa.Enabled = false;

        }

        private void btnSalirPa_Click_1(object sender, EventArgs e)
        {

            DialogResult tipo;
            tipo = MessageBox.Show("¿Deseas Salir?", "Tipo Pago ♥",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question,
                MessageBoxDefaultButton.Button2);
            if (tipo == DialogResult.Yes) this.Close();

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {
           

        }

        private void txtClaveTG_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }

        }

        private void btnBuscarTGG_Click(object sender, EventArgs e)
        {
            DBTipoPago miBase = new DBTipoPago();

            if (txtClaveTGG.Text != "")
            {
                DataTable datos = miBase.ConsultarH(int.Parse(txtClaveTGG.Text));
                if (datos.Rows.Count > 0)
                {
                    txtDescripcionTGG.Text = datos.Rows[0]["Descripcion"].ToString();
                    txtStatusTGG.Text = datos.Rows[0]["Status"].ToString();
                    txtClaveTGG.Enabled = true;
                   
                  
                }
                else
                {
                    MessageBox.Show("No hay registro con ese Clave", "Tipo Pago ♥");
                }

            }

            else
            {
                MessageBox.Show("Faltó capturar el Codigo", "Tipo Pago ♥");
                txtClaveTGG.Focus();
            }
        }

        private void btnNuevoTGG_Click(object sender, EventArgs e)
        {
            txtClaveTGG.Enabled = true;
        }

        private void btnHabilitarTGG_Click(object sender, EventArgs e)
        {
            DBTipoPago mibase = new DBTipoPago();

            TipoPago docc = new TipoPago();

            docc.Clave = int.Parse(txtClaveTGG.Text);
            docc.Descripcion = txtDescripcionTGG.Text;

            mibase.Habilitar(docc);

            txtClaveTGG.Text = "";

            txtDescripcionTGG.Text = "";
            txtStatusTGG.Text = "";

            txtClaveTG.Enabled = true;

            DBTipoPago miBase = new DBTipoPago();
            //Limpiar el DtaGriView
            dgvListaPa.DataSource = null;
            DataTable datos = miBase.ConsultarTodos4();
            //Poner Los Datos de Consulta en el DataGriView 

            dgvListaPa.DataSource = datos;

            DBTipoPago miBasee = new DBTipoPago();
            //Limpiar el DtaGriView
            dgvListaTGG.DataSource = null;
            DataTable datoss = miBasee.ConsultarTodosDeshabilitar();
            //Poner Los Datos de Consulta en el DataGriView 

            dgvListaTGG.DataSource = datoss;

        }

        private void btnLimpiarTGG_Click(object sender, EventArgs e)
        {
            txtClaveTGG.Text = "";

            txtDescripcionTGG.Text = "";
            txtStatusTGG.Text = "";
            txtDescripcionTGG.Enabled = false;
          
            txtClaveTGG.Enabled = true;
            txtStatusTGG.Enabled = false;
            btnBuscarTGG.Enabled = true;
        }

        private void btnCancelarTGG_Click(object sender, EventArgs e)
        {
            txtClaveTGG.Text = "";

            txtDescripcionTGG.Text = "";
            txtStatusTGG.Text = "";
            txtDescripcionTGG.Enabled = false;

            txtClaveTGG.Enabled = false;
            txtStatusTGG.Enabled = false;
            btnBuscarTGG.Enabled = true;
        }

        private void btnSalirTGG_Click(object sender, EventArgs e)
        {
            DialogResult tipo;
            tipo = MessageBox.Show("¿Deseas Salir?", "Tipo Pago ♥",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question,
                MessageBoxDefaultButton.Button2);
            if (tipo == DialogResult.Yes) this.Close();
        }
    }
}
