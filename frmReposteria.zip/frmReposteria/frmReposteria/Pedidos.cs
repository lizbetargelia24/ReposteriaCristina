﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace frmReposteria
{
    class Pedidos
    {
        private int idPedidos;
        private int clave;
        private string descripcion;
        private string fechaPedido;
        private int statusP;
        private float anticipo;
        private string foto;

        public Pedidos()
        {
            this.idPedidos = 0;
            this.clave = 0;
    
            this.descripcion = "";
            this.fechaPedido = "";
            this.statusP = 0;
            this.anticipo = 0.0f;
            this.foto = "";
        }
        public Pedidos( int idPedidos,int clave, string descripcion, string fechaPedido, int statusP, float anticipo, string foto) 

        {
            this.idPedidos = idPedidos;
            this.clave = clave;
            this.descripcion = descripcion;
            this.fechaPedido = fechaPedido;
            this.statusP = statusP;
            this.anticipo = anticipo;
            this.foto = foto;
        }
        public Pedidos(Pedidos x)
        {
            this.idPedidos = x.idPedidos;
            this.clave = x.clave;
            this.descripcion = x.descripcion;
            this.fechaPedido = x.fechaPedido;
            this.statusP = x.statusP;
            this.anticipo = x.anticipo;
            this.foto = x.foto;
        }
        public int IdPedidos
        {
            set { this.idPedidos = value; }
            get { return this.idPedidos; }
        }
        public int Clave
        {
            set { this.clave = value; }
            get { return this.clave; }
        }
        public string Descripcion
        {
            set { this.descripcion = value; }
            get { return this.descripcion; }
        }
        public string FechaPedido
        {
            set { this.fechaPedido = value; }
            get { return this.fechaPedido; }
        }
        public int StatusP
        {
            set { this.statusP = value; }
            get { return this.statusP; }
        }
        public float Anticipo
        {
            set { this.anticipo = value; }
            get { return this.anticipo; }
        }
        public int generaIdPedidos()
        {
            //genera valores aleatorios enteros positivos no mayores a 32000
            Random x = new Random();
            return x.Next(32000);
        }
        public string Foto
        {
            set { this.foto = value; }
            get { return this.foto; }
        }
    }
}
