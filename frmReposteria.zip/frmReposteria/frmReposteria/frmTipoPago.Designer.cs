﻿namespace frmReposteria
{
    partial class frmTipoPago
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label4 = new System.Windows.Forms.Label();
            this.txtClaveTG = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtDescripcionPa = new System.Windows.Forms.TextBox();
            this.btnSalirPa = new System.Windows.Forms.Button();
            this.btnCancelarPa = new System.Windows.Forms.Button();
            this.btnLimpiarPa = new System.Windows.Forms.Button();
            this.btnBorrarPa = new System.Windows.Forms.Button();
            this.btnModificarPa = new System.Windows.Forms.Button();
            this.btnGuardarPa = new System.Windows.Forms.Button();
            this.btnNuevoPa = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.dgvListaPa = new System.Windows.Forms.DataGridView();
            this.cmbStatusTG = new System.Windows.Forms.TextBox();
            this.btnBuscarPa = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnHabilitarTGG = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtClaveTGG = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtDescripcionTGG = new System.Windows.Forms.TextBox();
            this.btnSalirTGG = new System.Windows.Forms.Button();
            this.btnCancelarTGG = new System.Windows.Forms.Button();
            this.btnLimpiarTGG = new System.Windows.Forms.Button();
            this.btnNuevoTGG = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.dgvListaTGG = new System.Windows.Forms.DataGridView();
            this.txtStatusTGG = new System.Windows.Forms.TextBox();
            this.btnBuscarTGG = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaPa)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaTGG)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(451, 397);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.txtClaveTG);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.txtDescripcionPa);
            this.tabPage1.Controls.Add(this.btnSalirPa);
            this.tabPage1.Controls.Add(this.btnCancelarPa);
            this.tabPage1.Controls.Add(this.btnLimpiarPa);
            this.tabPage1.Controls.Add(this.btnBorrarPa);
            this.tabPage1.Controls.Add(this.btnModificarPa);
            this.tabPage1.Controls.Add(this.btnGuardarPa);
            this.tabPage1.Controls.Add(this.btnNuevoPa);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.dgvListaPa);
            this.tabPage1.Controls.Add(this.cmbStatusTG);
            this.tabPage1.Controls.Add(this.btnBuscarPa);
            this.tabPage1.Location = new System.Drawing.Point(4, 24);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(443, 369);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "TipoPago";
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label4.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(15, 122);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(43, 16);
            this.label4.TabIndex = 39;
            this.label4.Text = "Status";
            // 
            // txtClaveTG
            // 
            this.txtClaveTG.Enabled = false;
            this.txtClaveTG.Location = new System.Drawing.Point(18, 33);
            this.txtClaveTG.MaxLength = 8;
            this.txtClaveTG.Name = "txtClaveTG";
            this.txtClaveTG.Size = new System.Drawing.Size(116, 23);
            this.txtClaveTG.TabIndex = 1;
            this.txtClaveTG.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtClaveTG_KeyPress_1);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label3.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(14, 11);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 16);
            this.label3.TabIndex = 38;
            this.label3.Text = "Clave";
            // 
            // txtDescripcionPa
            // 
            this.txtDescripcionPa.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtDescripcionPa.Enabled = false;
            this.txtDescripcionPa.Location = new System.Drawing.Point(18, 84);
            this.txtDescripcionPa.MaxLength = 25;
            this.txtDescripcionPa.Name = "txtDescripcionPa";
            this.txtDescripcionPa.Size = new System.Drawing.Size(116, 23);
            this.txtDescripcionPa.TabIndex = 2;
            // 
            // btnSalirPa
            // 
            this.btnSalirPa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnSalirPa.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSalirPa.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalirPa.Image = global::frmReposteria.Properties.Resources.salir_3;
            this.btnSalirPa.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSalirPa.Location = new System.Drawing.Point(209, 203);
            this.btnSalirPa.Name = "btnSalirPa";
            this.btnSalirPa.Size = new System.Drawing.Size(70, 37);
            this.btnSalirPa.TabIndex = 35;
            this.btnSalirPa.Text = "Salir";
            this.btnSalirPa.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSalirPa.UseVisualStyleBackColor = false;
            this.btnSalirPa.Click += new System.EventHandler(this.btnSalirPa_Click_1);
            // 
            // btnCancelarPa
            // 
            this.btnCancelarPa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnCancelarPa.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCancelarPa.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelarPa.Image = global::frmReposteria.Properties.Resources.prohibido__1_;
            this.btnCancelarPa.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCancelarPa.Location = new System.Drawing.Point(111, 203);
            this.btnCancelarPa.Name = "btnCancelarPa";
            this.btnCancelarPa.Size = new System.Drawing.Size(91, 37);
            this.btnCancelarPa.TabIndex = 34;
            this.btnCancelarPa.Text = "Cancelar";
            this.btnCancelarPa.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCancelarPa.UseVisualStyleBackColor = false;
            this.btnCancelarPa.Click += new System.EventHandler(this.btnCancelarPa_Click_1);
            // 
            // btnLimpiarPa
            // 
            this.btnLimpiarPa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnLimpiarPa.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnLimpiarPa.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpiarPa.Image = global::frmReposteria.Properties.Resources.escoba_de_limpieza_para_suelos__1_;
            this.btnLimpiarPa.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLimpiarPa.Location = new System.Drawing.Point(16, 203);
            this.btnLimpiarPa.Name = "btnLimpiarPa";
            this.btnLimpiarPa.Size = new System.Drawing.Size(87, 37);
            this.btnLimpiarPa.TabIndex = 32;
            this.btnLimpiarPa.Text = "Limpiar";
            this.btnLimpiarPa.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLimpiarPa.UseVisualStyleBackColor = false;
            this.btnLimpiarPa.Click += new System.EventHandler(this.btnLimpiarPa_Click_1);
            // 
            // btnBorrarPa
            // 
            this.btnBorrarPa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnBorrarPa.Enabled = false;
            this.btnBorrarPa.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBorrarPa.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBorrarPa.Image = global::frmReposteria.Properties.Resources.cubo_de_basura;
            this.btnBorrarPa.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBorrarPa.Location = new System.Drawing.Point(343, 156);
            this.btnBorrarPa.Name = "btnBorrarPa";
            this.btnBorrarPa.Size = new System.Drawing.Size(80, 36);
            this.btnBorrarPa.TabIndex = 33;
            this.btnBorrarPa.Text = "Borrar";
            this.btnBorrarPa.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBorrarPa.UseVisualStyleBackColor = false;
            this.btnBorrarPa.Click += new System.EventHandler(this.btnBorrarPa_Click_1);
            // 
            // btnModificarPa
            // 
            this.btnModificarPa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnModificarPa.Enabled = false;
            this.btnModificarPa.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnModificarPa.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnModificarPa.Image = global::frmReposteria.Properties.Resources.herramientas_del_empleado_de_mantenimiento;
            this.btnModificarPa.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnModificarPa.Location = new System.Drawing.Point(321, 112);
            this.btnModificarPa.Name = "btnModificarPa";
            this.btnModificarPa.Size = new System.Drawing.Size(103, 37);
            this.btnModificarPa.TabIndex = 31;
            this.btnModificarPa.Text = "Modificar";
            this.btnModificarPa.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnModificarPa.UseVisualStyleBackColor = false;
            this.btnModificarPa.Click += new System.EventHandler(this.btnModificarPa_Click_1);
            // 
            // btnGuardarPa
            // 
            this.btnGuardarPa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnGuardarPa.Enabled = false;
            this.btnGuardarPa.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnGuardarPa.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGuardarPa.Image = global::frmReposteria.Properties.Resources.guardar2;
            this.btnGuardarPa.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGuardarPa.Location = new System.Drawing.Point(325, 63);
            this.btnGuardarPa.Name = "btnGuardarPa";
            this.btnGuardarPa.Size = new System.Drawing.Size(99, 43);
            this.btnGuardarPa.TabIndex = 29;
            this.btnGuardarPa.Text = "Guardar";
            this.btnGuardarPa.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnGuardarPa.UseVisualStyleBackColor = false;
            this.btnGuardarPa.Click += new System.EventHandler(this.btnGuardarPa_Click_1);
            // 
            // btnNuevoPa
            // 
            this.btnNuevoPa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnNuevoPa.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNuevoPa.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNuevoPa.Image = global::frmReposteria.Properties.Resources.agregar_usuario;
            this.btnNuevoPa.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNuevoPa.Location = new System.Drawing.Point(343, 22);
            this.btnNuevoPa.Name = "btnNuevoPa";
            this.btnNuevoPa.Size = new System.Drawing.Size(80, 33);
            this.btnNuevoPa.TabIndex = 6;
            this.btnNuevoPa.Text = "Nuevo";
            this.btnNuevoPa.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNuevoPa.UseVisualStyleBackColor = false;
            this.btnNuevoPa.Click += new System.EventHandler(this.btnNuevoPa_Click_1);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label2.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(14, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 16);
            this.label2.TabIndex = 37;
            this.label2.Text = "Descripcion";
            // 
            // dgvListaPa
            // 
            this.dgvListaPa.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.dgvListaPa.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvListaPa.Location = new System.Drawing.Point(18, 250);
            this.dgvListaPa.Name = "dgvListaPa";
            this.dgvListaPa.Size = new System.Drawing.Size(358, 96);
            this.dgvListaPa.TabIndex = 36;
            // 
            // cmbStatusTG
            // 
            this.cmbStatusTG.Enabled = false;
            this.cmbStatusTG.Location = new System.Drawing.Point(16, 147);
            this.cmbStatusTG.MaxLength = 10;
            this.cmbStatusTG.Name = "cmbStatusTG";
            this.cmbStatusTG.Size = new System.Drawing.Size(116, 23);
            this.cmbStatusTG.TabIndex = 28;
            // 
            // btnBuscarPa
            // 
            this.btnBuscarPa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnBuscarPa.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBuscarPa.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscarPa.Image = global::frmReposteria.Properties.Resources.buscar;
            this.btnBuscarPa.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBuscarPa.Location = new System.Drawing.Point(168, 10);
            this.btnBuscarPa.Name = "btnBuscarPa";
            this.btnBuscarPa.Size = new System.Drawing.Size(80, 37);
            this.btnBuscarPa.TabIndex = 30;
            this.btnBuscarPa.Text = "Buscar";
            this.btnBuscarPa.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBuscarPa.UseVisualStyleBackColor = false;
            this.btnBuscarPa.Click += new System.EventHandler(this.btnBuscarPa_Click_1);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tabPage2.Controls.Add(this.btnHabilitarTGG);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.txtClaveTGG);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.txtDescripcionTGG);
            this.tabPage2.Controls.Add(this.btnSalirTGG);
            this.tabPage2.Controls.Add(this.btnCancelarTGG);
            this.tabPage2.Controls.Add(this.btnLimpiarTGG);
            this.tabPage2.Controls.Add(this.btnNuevoTGG);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.dgvListaTGG);
            this.tabPage2.Controls.Add(this.txtStatusTGG);
            this.tabPage2.Controls.Add(this.btnBuscarTGG);
            this.tabPage2.Location = new System.Drawing.Point(4, 24);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(443, 369);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Habilitar";
            // 
            // btnHabilitarTGG
            // 
            this.btnHabilitarTGG.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnHabilitarTGG.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnHabilitarTGG.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHabilitarTGG.Image = global::frmReposteria.Properties.Resources.copia_de_seguridad;
            this.btnHabilitarTGG.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHabilitarTGG.Location = new System.Drawing.Point(169, 61);
            this.btnHabilitarTGG.Name = "btnHabilitarTGG";
            this.btnHabilitarTGG.Size = new System.Drawing.Size(87, 37);
            this.btnHabilitarTGG.TabIndex = 216;
            this.btnHabilitarTGG.Text = "Habilitar";
            this.btnHabilitarTGG.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnHabilitarTGG.UseVisualStyleBackColor = false;
            this.btnHabilitarTGG.Click += new System.EventHandler(this.btnHabilitarTGG_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(16, 128);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 16);
            this.label1.TabIndex = 54;
            this.label1.Text = "Status";
            // 
            // txtClaveTGG
            // 
            this.txtClaveTGG.Enabled = false;
            this.txtClaveTGG.Location = new System.Drawing.Point(19, 39);
            this.txtClaveTGG.MaxLength = 10;
            this.txtClaveTGG.Name = "txtClaveTGG";
            this.txtClaveTGG.Size = new System.Drawing.Size(116, 23);
            this.txtClaveTGG.TabIndex = 40;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label5.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(15, 17);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 16);
            this.label5.TabIndex = 53;
            this.label5.Text = "Clave";
            // 
            // txtDescripcionTGG
            // 
            this.txtDescripcionTGG.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtDescripcionTGG.Enabled = false;
            this.txtDescripcionTGG.Location = new System.Drawing.Point(19, 90);
            this.txtDescripcionTGG.MaxLength = 25;
            this.txtDescripcionTGG.Name = "txtDescripcionTGG";
            this.txtDescripcionTGG.Size = new System.Drawing.Size(116, 23);
            this.txtDescripcionTGG.TabIndex = 42;
            // 
            // btnSalirTGG
            // 
            this.btnSalirTGG.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnSalirTGG.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSalirTGG.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalirTGG.Image = global::frmReposteria.Properties.Resources.salir_3;
            this.btnSalirTGG.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSalirTGG.Location = new System.Drawing.Point(210, 209);
            this.btnSalirTGG.Name = "btnSalirTGG";
            this.btnSalirTGG.Size = new System.Drawing.Size(70, 37);
            this.btnSalirTGG.TabIndex = 50;
            this.btnSalirTGG.Text = "Salir";
            this.btnSalirTGG.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSalirTGG.UseVisualStyleBackColor = false;
            this.btnSalirTGG.Click += new System.EventHandler(this.btnSalirTGG_Click);
            // 
            // btnCancelarTGG
            // 
            this.btnCancelarTGG.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnCancelarTGG.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCancelarTGG.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelarTGG.Image = global::frmReposteria.Properties.Resources.prohibido__1_;
            this.btnCancelarTGG.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCancelarTGG.Location = new System.Drawing.Point(112, 209);
            this.btnCancelarTGG.Name = "btnCancelarTGG";
            this.btnCancelarTGG.Size = new System.Drawing.Size(91, 37);
            this.btnCancelarTGG.TabIndex = 49;
            this.btnCancelarTGG.Text = "Cancelar";
            this.btnCancelarTGG.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCancelarTGG.UseVisualStyleBackColor = false;
            this.btnCancelarTGG.Click += new System.EventHandler(this.btnCancelarTGG_Click);
            // 
            // btnLimpiarTGG
            // 
            this.btnLimpiarTGG.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnLimpiarTGG.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnLimpiarTGG.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpiarTGG.Image = global::frmReposteria.Properties.Resources.escoba_de_limpieza_para_suelos__1_;
            this.btnLimpiarTGG.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLimpiarTGG.Location = new System.Drawing.Point(17, 209);
            this.btnLimpiarTGG.Name = "btnLimpiarTGG";
            this.btnLimpiarTGG.Size = new System.Drawing.Size(87, 37);
            this.btnLimpiarTGG.TabIndex = 47;
            this.btnLimpiarTGG.Text = "Limpiar";
            this.btnLimpiarTGG.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLimpiarTGG.UseVisualStyleBackColor = false;
            this.btnLimpiarTGG.Click += new System.EventHandler(this.btnLimpiarTGG_Click);
            // 
            // btnNuevoTGG
            // 
            this.btnNuevoTGG.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnNuevoTGG.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNuevoTGG.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNuevoTGG.Image = global::frmReposteria.Properties.Resources.agregar_usuario;
            this.btnNuevoTGG.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNuevoTGG.Location = new System.Drawing.Point(372, 20);
            this.btnNuevoTGG.Name = "btnNuevoTGG";
            this.btnNuevoTGG.Size = new System.Drawing.Size(80, 33);
            this.btnNuevoTGG.TabIndex = 41;
            this.btnNuevoTGG.Text = "Nuevo";
            this.btnNuevoTGG.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNuevoTGG.UseVisualStyleBackColor = false;
            this.btnNuevoTGG.Click += new System.EventHandler(this.btnNuevoTGG_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label6.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(15, 71);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 16);
            this.label6.TabIndex = 52;
            this.label6.Text = "Descripcion";
            // 
            // dgvListaTGG
            // 
            this.dgvListaTGG.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.dgvListaTGG.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvListaTGG.Location = new System.Drawing.Point(19, 256);
            this.dgvListaTGG.Name = "dgvListaTGG";
            this.dgvListaTGG.Size = new System.Drawing.Size(363, 96);
            this.dgvListaTGG.TabIndex = 51;
            // 
            // txtStatusTGG
            // 
            this.txtStatusTGG.Enabled = false;
            this.txtStatusTGG.Location = new System.Drawing.Point(17, 153);
            this.txtStatusTGG.MaxLength = 10;
            this.txtStatusTGG.Name = "txtStatusTGG";
            this.txtStatusTGG.Size = new System.Drawing.Size(116, 23);
            this.txtStatusTGG.TabIndex = 43;
            // 
            // btnBuscarTGG
            // 
            this.btnBuscarTGG.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnBuscarTGG.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBuscarTGG.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscarTGG.Image = global::frmReposteria.Properties.Resources.buscar;
            this.btnBuscarTGG.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBuscarTGG.Location = new System.Drawing.Point(176, 17);
            this.btnBuscarTGG.Name = "btnBuscarTGG";
            this.btnBuscarTGG.Size = new System.Drawing.Size(80, 37);
            this.btnBuscarTGG.TabIndex = 45;
            this.btnBuscarTGG.Text = "Buscar";
            this.btnBuscarTGG.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBuscarTGG.UseVisualStyleBackColor = false;
            this.btnBuscarTGG.Click += new System.EventHandler(this.btnBuscarTGG_Click);
            // 
            // frmTipoPago
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(484, 421);
            this.Controls.Add(this.tabControl1);
            this.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmTipoPago";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TipoPago";
            this.Load += new System.EventHandler(this.frmTipoPago_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaPa)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaTGG)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtClaveTG;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtDescripcionPa;
        private System.Windows.Forms.Button btnSalirPa;
        private System.Windows.Forms.Button btnCancelarPa;
        private System.Windows.Forms.Button btnLimpiarPa;
        private System.Windows.Forms.Button btnBorrarPa;
        private System.Windows.Forms.Button btnModificarPa;
        private System.Windows.Forms.Button btnGuardarPa;
        private System.Windows.Forms.Button btnNuevoPa;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dgvListaPa;
        private System.Windows.Forms.TextBox cmbStatusTG;
        private System.Windows.Forms.Button btnBuscarPa;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtClaveTGG;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtDescripcionTGG;
        private System.Windows.Forms.Button btnSalirTGG;
        private System.Windows.Forms.Button btnCancelarTGG;
        private System.Windows.Forms.Button btnLimpiarTGG;
        private System.Windows.Forms.Button btnNuevoTGG;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView dgvListaTGG;
        private System.Windows.Forms.TextBox txtStatusTGG;
        private System.Windows.Forms.Button btnBuscarTGG;
        private System.Windows.Forms.Button btnHabilitarTGG;
    }
}