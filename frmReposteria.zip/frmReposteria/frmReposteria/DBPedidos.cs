﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;
namespace frmReposteria
{
    class DBPedidos
    {
        private MySqlConnection conexion;
        private string strConexion;
        private MySqlCommand sqlComando;
        private string strConsulta;
        private MySqlDataAdapter adaptador;

        public DBPedidos()
        {
            //Constructor
            conexion = new MySqlConnection();
            strConexion = "Server=localHost;User=root;DataBase=bdreposteria;port=3306;Password=";

            conexion.ConnectionString = strConexion;

            sqlComando = new MySqlCommand();
            adaptador = new MySqlDataAdapter();
        }
        public Boolean abrir()
        {
            Boolean exito = false;

            if (conexion.State == System.Data.ConnectionState.Closed)
            {

                conexion.Open();
                exito = true;

            }



            return exito;
        }
        public Boolean Cerrar()
        {
            Boolean exito = false;

            if (conexion.State == System.Data.ConnectionState.Closed)
            {

                exito = false;
            }
            else
            {
                conexion.Close();
                exito = true;
            }
            return exito;
        }
        //AGREGAR USANDO PARAMETRO
        public void agregarUsandoParametros(Pedidos obj)
        {
            string sqlConsulta = "insert into tpedidos (idPedido,clave,descripcion,fechaPedido,anticipo,foto,status)values(null, ?pclave,?pdescripcion,?pfechaPedido,?panticipo,?pfoto,0)";
            sqlComando.Parameters.Clear();

            sqlComando.Parameters.Add("?pclave", MySql.Data.MySqlClient.MySqlDbType.Int32).Value = obj.Clave;
            sqlComando.Parameters.Add("?pdescripcion", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Descripcion;
            sqlComando.Parameters.Add("?pfechaPedido", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.FechaPedido;
            sqlComando.Parameters.Add("?panticipo", MySql.Data.MySqlClient.MySqlDbType.Float).Value = obj.Anticipo;
            sqlComando.Parameters.Add("?pfoto", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Foto;
            sqlComando.Parameters.Add("?pstatus", MySql.Data.MySqlClient.MySqlDbType.Int32).Value = obj.StatusP;



            this.abrir();
            sqlComando.Connection = conexion;
            sqlComando.CommandText = sqlConsulta;

            sqlComando.ExecuteNonQuery();
            this.Cerrar();

        }
        //ACTUALIZAR
        public void Actualizar(Pedidos obj)
        {
            string sqlConsulta = "Update tpedidos set  descripcion=?pdescripcion, fechaPedido=?pfechaPedido, anticipo=?panticipo, foto=?pfoto where clave= ?pclave and status=0";
            sqlComando.Parameters.Clear();

            sqlComando.Parameters.Add("?pclave", MySql.Data.MySqlClient.MySqlDbType.Int32).Value = obj.Clave;
            sqlComando.Parameters.Add("?pdescripcion", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Descripcion;
            sqlComando.Parameters.Add("?pfechaPedido", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.FechaPedido;
            sqlComando.Parameters.Add("?panticipo", MySql.Data.MySqlClient.MySqlDbType.Float).Value = obj.Anticipo;
            sqlComando.Parameters.Add("?pfoto", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Foto;
            sqlComando.Parameters.Add("?pstatus", MySql.Data.MySqlClient.MySqlDbType.Int32).Value = obj.StatusP;


            this.abrir();
            sqlComando.Connection = conexion;
            sqlComando.CommandText = sqlConsulta;

            sqlComando.ExecuteNonQuery();
            this.Cerrar();
        }
        //DESHABILITAR 
        public void Deshabilitar(Pedidos obj)
        {
            string sqlConsulta = "update tpedidos set status=1 where clave= ?pclave and status=0";
            sqlComando.Parameters.Clear();

            sqlComando.Parameters.Add("?pclave", MySql.Data.MySqlClient.MySqlDbType.Int32).Value = obj.Clave;

            this.abrir();
            sqlComando.Connection = conexion;
            sqlComando.CommandText = sqlConsulta;

            sqlComando.ExecuteNonQuery();
            this.Cerrar();
        }
        public void Habilitar(Pedidos obj)
        {
            string sqlConsulta = "update tpedidos set status=0 where clave = ?pclave and status = 1";
            sqlComando.Parameters.Clear();

            sqlComando.Parameters.Add("?pclave", MySql.Data.MySqlClient.MySqlDbType.Int32).Value = obj.Clave;

            this.abrir();
            sqlComando.Connection = conexion;
            sqlComando.CommandText = sqlConsulta;

            sqlComando.ExecuteNonQuery();
            this.Cerrar();
        }
        //Consultar
        public DataTable Consultar(int Clave)
        {
            DataTable datos = new DataTable();
            strConsulta = "select *from tpedidos where Status=  0 and clave =" + Clave;

            this.abrir();
            sqlComando.CommandText = strConsulta;
            sqlComando.Connection = conexion;
            adaptador.SelectCommand = sqlComando;
            adaptador.Fill(datos);

            this.Cerrar();

            return datos;
        }
        //METODO CONSULTAR TODOS
        public DataTable ConsultarTodos()
        {
            DataTable datos = new DataTable();
            strConsulta = "select *from tpedidos where status = 0 order by clave asc";
            abrir();
            sqlComando.CommandText = strConsulta;
            sqlComando.Connection = conexion;

            adaptador.SelectCommand = sqlComando;
            adaptador.Fill(datos);
            Cerrar();
            return datos;
        }
        public DataTable ConsultarTodosDeshabilitar()
        {
            DataTable datos = new DataTable();
            strConsulta = "select *from tpedidos where status = 1 order by clave asc";
            abrir();
            sqlComando.CommandText = strConsulta;
            sqlComando.Connection = conexion;

            adaptador.SelectCommand = sqlComando;
            adaptador.Fill(datos);
            Cerrar();
            return datos;
        }
        public void Habilitar(Producto obj)
        {
            string sqlConsulta = "update tpedidos set status=0 where clave = ?pclave and status = 1";
            sqlComando.Parameters.Clear();

            sqlComando.Parameters.Add("?pclave", MySql.Data.MySqlClient.MySqlDbType.Int32).Value = obj.Clave;

            this.abrir();
            sqlComando.Connection = conexion;
            sqlComando.CommandText = sqlConsulta;

            sqlComando.ExecuteNonQuery();
            this.Cerrar();
        }
        public DataTable ConsultarH(int Clave)
        {
            DataTable datos = new DataTable();
            strConsulta = "select * from tpedidos where status = 1 and clave =" + Clave;

            this.abrir();
            sqlComando.CommandText = strConsulta;
            sqlComando.Connection = conexion;
            adaptador.SelectCommand = sqlComando;
            adaptador.Fill(datos);

            this.Cerrar();

            return datos;
        }
        public DataTable ConsultarTodos2()
        {
            DataTable datos = new DataTable();
            strConsulta = "select *from tpedidos where status = 0 order by clave asc";
            abrir();
            sqlComando.CommandText = strConsulta;
            sqlComando.Connection = conexion;

            adaptador.SelectCommand = sqlComando;
            adaptador.Fill(datos);
            Cerrar();
            return datos;
        }
    }
}

