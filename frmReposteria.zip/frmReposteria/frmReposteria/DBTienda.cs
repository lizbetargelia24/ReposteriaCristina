﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;

namespace frmReposteria
{
    class DBTienda
    {
        private MySqlConnection conexion;
        private string strConexion;
        private MySqlCommand sqlComando;
        private string strConsulta;
        private MySqlDataAdapter adaptador;

        public DBTienda()
        {
            //Constructor
            conexion = new MySqlConnection();
            strConexion = "Server=localHost;User=root;DataBase=bdreposteria;port=3306;Password=";

            conexion.ConnectionString = strConexion;

            sqlComando = new MySqlCommand();
            adaptador = new MySqlDataAdapter();

        }
        public Boolean abrir()
        {
            Boolean exito = false;

            if (conexion.State == System.Data.ConnectionState.Closed)
            {

                conexion.Open();
                exito = true;

            }



            return exito;
        }
        public Boolean Cerrar()
        {
            Boolean exito = false;

            if (conexion.State == System.Data.ConnectionState.Closed)
            {

                exito = false;
            }
            else
            {
                conexion.Close();
                exito = true;
            }
            return exito;
        }
        // public Boolean Cerrar()
        // {
        //    Boolean exito = false;
        //    if (conexion.State == ConnectionState.Closed)
        //    {
        //    conexion.Close();
        //   exito = true;
        // }
        // return exito;
        // }


        //Agregar sin parametros
        public void agregarSinParsametros(Tienda obj)
        {
            string sqlConsulta = "insert into ttienda(idtienda,clave,nombre,status) values (null," + obj.Clave + "," + obj.Nombre + ",0)";
            this.abrir();
            sqlComando.Connection = conexion;
            sqlComando.CommandText = sqlConsulta;

            sqlComando.ExecuteNonQuery();
            this.Cerrar();
        }
        //Agregar usando parametros
        public void agregarUsandoParametros(Tienda obj)
        {
            string sqlConsulta = "insert into ttienda (idtienda,clave,nombre,status)values(null, ?pclave, ?pnombre,0)";
            sqlComando.Parameters.Clear();

            sqlComando.Parameters.Add("?pclave", MySql.Data.MySqlClient.MySqlDbType.Int32).Value = obj.Clave;
            sqlComando.Parameters.Add("?pnombre", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Nombre;
            this.abrir();
            sqlComando.Connection = conexion;
            sqlComando.CommandText = sqlConsulta;

            sqlComando.ExecuteNonQuery();
            this.Cerrar();

        }
        //Actualizar
        public void Actualizar(Tienda obj)
        {
            string sqlConsulta = "Update ttienda set nombre = ?pnombre where clave= ?pclave and status=0";
            sqlComando.Parameters.Clear();

            sqlComando.Parameters.Add("?pclave", MySql.Data.MySqlClient.MySqlDbType.UInt32).Value = obj.Clave;

            sqlComando.Parameters.Add("?pnombre", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Nombre;
            this.abrir();
            sqlComando.Connection = conexion;
            sqlComando.CommandText = sqlConsulta;

            sqlComando.ExecuteNonQuery();
            this.Cerrar();
        }
        //Deshabilitar
        public void Deshabilitar(Tienda obj)
        {
            string sqlConsulta = "update ttienda set status=1 where clave= ?pclave and status=0";
            sqlComando.Parameters.Clear();

            sqlComando.Parameters.Add("?pclave", MySql.Data.MySqlClient.MySqlDbType.Int32).Value = obj.Clave;

            this.abrir();
            sqlComando.Connection = conexion;
            sqlComando.CommandText = sqlConsulta;

            sqlComando.ExecuteNonQuery();
            this.Cerrar();
        }
        //Consultar
        public DataTable Consultar(int Clave)
        {
            DataTable datos = new DataTable();
            strConsulta = "select *from ttienda where status = 0 and clave =" + Clave;

            this.abrir();
            sqlComando.CommandText = strConsulta;
            sqlComando.Connection = conexion;
            adaptador.SelectCommand = sqlComando;
            adaptador.Fill(datos);

            this.Cerrar();

            return datos;
        }
        //Metodo consultar todos
        public DataTable ConsultarTodos4()
        {
            DataTable datos = new DataTable();
            strConsulta = "select *from ttienda where status = 0 order by clave asc";
            abrir();
            sqlComando.CommandText = strConsulta;
            sqlComando.Connection = conexion;

            adaptador.SelectCommand = sqlComando;
            adaptador.Fill(datos);
            this.Cerrar();
            return datos;
        }
        public DataTable ConsultarTodosDeshabilitar()
        {
            DataTable datos = new DataTable();
            strConsulta = "select *from ttienda where status = 1 order by clave asc";
            abrir();
            sqlComando.CommandText = strConsulta;
            sqlComando.Connection = conexion;

            adaptador.SelectCommand = sqlComando;
            adaptador.Fill(datos);
            Cerrar();
            return datos;
        }
        public void Habilitar(Tienda obj)
        {
            string sqlConsulta = "update ttienda set status=0 where clave = ?pclave and status = 1";
            sqlComando.Parameters.Clear();

            sqlComando.Parameters.Add("?pclave", MySql.Data.MySqlClient.MySqlDbType.Int32).Value = obj.Clave;

            this.abrir();
            sqlComando.Connection = conexion;
            sqlComando.CommandText = sqlConsulta;

            sqlComando.ExecuteNonQuery();
            this.Cerrar();
        }
        public DataTable ConsultarH(int Clave)
        {
            DataTable datos = new DataTable();
            strConsulta = "select * from ttienda where status = 1 and clave =" + Clave;

            this.abrir();
            sqlComando.CommandText = strConsulta;
            sqlComando.Connection = conexion;
            adaptador.SelectCommand = sqlComando;
            adaptador.Fill(datos);

            this.Cerrar();

            return datos;
        }
     
        public DataTable ConsultarTodos5()
        {
            DataTable datos = new DataTable();
            strConsulta = "select *from ttienda where status = 0 order by clave asc";
            abrir();
            sqlComando.CommandText = strConsulta;
            sqlComando.Connection = conexion;

            adaptador.SelectCommand = sqlComando;
            adaptador.Fill(datos);
            Cerrar();
            return datos;
        }
    }
}
