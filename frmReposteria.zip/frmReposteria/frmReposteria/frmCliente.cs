﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace frmReposteria
{
    public partial class frmCliente : Form
    {
        public frmCliente()
        {
            InitializeComponent();
        }

        private void btnNuevoC_Click(object sender, EventArgs e)
        {

        }

        private void btnNuevoC_Click_1(object sender, EventArgs e)
        {
          
        }

        private void btnGuardarC_Click(object sender, EventArgs e)
        {
           
            
        }

        private void btnModificarC_Click(object sender, EventArgs e)
        {

           





           
        }

        private void btnBorrarC_Click(object sender, EventArgs e)
        {
           
        }

        private void btnFotoC_Click(object sender, EventArgs e)
        {
          
        }

        private void btnBuscarC_Click(object sender, EventArgs e)
        {
           
          
        }

        private void btnLimpiarC_Click(object sender, EventArgs e)
        {
           
        }

        private void btnCancelarC_Click(object sender, EventArgs e)
        {
          
        }

        private void btnSalirC_Click(object sender, EventArgs e)
        {
          
        }

        private void frmCliente_Load(object sender, EventArgs e)
        {
            DBClientes miBase = new DBClientes();
            //Limpiar el DtaGriView
            dbglistaC.DataSource = null;
            DataTable datos = miBase.ConsultarTodos();
            //Poner Los Datos de Consulta en el DataGriView 
            dbglistaC.DataSource = datos;

            DBClientes miBasee = new DBClientes();
            //Limpiar el DtaGriView
            dgvListaCli.DataSource = null;
            DataTable datoss = miBasee.ConsultarTodosDeshabilitar();
            //Poner Los Datos de Consulta en el DataGriView 

            dgvListaCli.DataSource = datoss;
        }

        private void txtClaveC_KeyPress(object sender, KeyPressEventArgs e)
        {
          
        }

        private void txtTelefonoC_KeyPress(object sender, KeyPressEventArgs e)
        {
           
        }

        private void txtNumeroC_KeyPress(object sender, KeyPressEventArgs e)
        {
            
        }

        private void txtCodigoPostC_KeyPress(object sender, KeyPressEventArgs e)
        {
           
        }

        private void btnNuevoC_Click_2(object sender, EventArgs e)
        {
            txtClaveC.Enabled = true;

            txtNombreC.Enabled = true;
            txtCurpC.Enabled = true;
            txtCorreoC.Enabled = true;
            txtTelefonoC.Enabled = true;
            txtApellidoMatC.Enabled = true;
            txtApellidoPatC.Enabled = true;
            txtColoniaC.Enabled = true;
            txtCalleC.Enabled = true;
            txtNumeroC.Enabled = true;
            txtCodigoPostC.Enabled = true;

            btnBuscarC.Enabled = true;
            btnModificarC.Enabled = true;
            btnBorrarC.Enabled = true;

        }

        private void btnGuardarC_Click_1(object sender, EventArgs e)
        {
            Boolean exito = false;
            if (txtClaveC.Text.Equals("")) { MessageBox.Show("Faltó capturar la Clave ", "Clientes ♥"); exito = true; }

            if (txtNombreC.Text.Equals("")) { MessageBox.Show("Faltó capturar el Nombre", "Clientes ♥"); exito = true; }
            if (txtCurpC.Text.Equals("")) { MessageBox.Show("Faltó capturar el Curp", "Clientes ♥"); exito = true; }
            if (txtCorreoC.Text.Equals("")) { MessageBox.Show("Faltó capturar el Correo", "Clientes ♥"); exito = true; }
            if (txtTelefonoC.Text.Equals("")) { MessageBox.Show("Faltó capturar el Telefono", "Clientes ♥"); exito = true; }
            if (txtApellidoMatC.Text.Equals("")) { MessageBox.Show("Faltó capturar el Apellido Materno", "Clientes ♥"); exito = true; }
            if (txtApellidoPatC.Text.Equals("")) { MessageBox.Show("Faltó capturar el Apellido Paterno", "Clientes ♥"); exito = true; }
            if (txtColoniaC.Text.Equals("")) { MessageBox.Show("Faltó capturar la Colonia", "Clientes ♥"); exito = true; }
            if (txtCalleC.Text.Equals("")) { MessageBox.Show("Faltó capturar la Calle", "Clientes ♥"); exito = true; }
            if (txtNumeroC.Text.Equals("")) { MessageBox.Show("Faltó capturar el Número", "Clientes ♥"); exito = true; }
            if (txtCodigoPostC.Text.Equals("")) { MessageBox.Show("Faltó capturar el Código Postal", "Clientes ♥"); exito = true; }

            if (txtFotoC.Text.Equals("")) { MessageBox.Show("Faltó capturar la Foto", "Clientes ♥"); exito = true; }

            if (exito == false)
            {
                DBClientes miBase = new DBClientes();
                if (txtClaveC.Text == txtClaveC.Text)
                {
                    DataTable data = miBase.Consultar(int.Parse(txtClaveC.Text));
                    if (data.Rows.Count > 0)
                    {
                        MessageBox.Show("Ya existe la clave", "Clientes ♥");
                    }
                    else
                    {
                        Clientes es = new Clientes();

                        es.Clave = int.Parse(txtClaveC.Text);
                        es.Nombre = txtNombreC.Text;

                        es.Curp = txtCurpC.Text;
                        es.Correo = txtCorreoC.Text;
                        es.Telefono = txtTelefonoC.Text;
                        es.ApellidoMaterno = txtApellidoMatC.Text;
                        es.ApellidoPaterno = txtApellidoPatC.Text;
                        es.Colonia = txtColoniaC.Text;
                        es.Calle = txtCalleC.Text;
                        es.Numero = int.Parse(txtNumeroC.Text);
                        es.Cp = int.Parse(txtCodigoPostC.Text);



                        es.Foto = txtFotoC.Text;
                        ptbFotoC.Image = Image.FromFile(txtFotoC.Text);


                        miBase.agregarUsandoParametros(es);
                        MessageBox.Show("Se guardó con exito", "Clientes ♥");

                        dbglistaC.DataSource = null;

                        DataTable datos2 = miBase.ConsultarTodos();

                        dbglistaC.DataSource = datos2;
                        txtNombreC.Text = "";
                        txtCurpC.Text = "";
                        txtCorreoC.Text = "";
                        txtTelefonoC.Text = "";
                        txtApellidoMatC.Text = "";
                        txtApellidoPatC.Text = "";
                        txtColoniaC.Text = "";
                        txtCalleC.Text = "";
                        txtNumeroC.Text = "";
                        txtCodigoPostC.Text = "";

                        txtStatusC.Text = "";
                        txtFotoC.Text = "";
                        txtClaveC.Text = "";
                        ptbFotoC.Image = frmReposteria.Properties.Resources.imagen;
                    }


                }
                else
                {
                    MessageBox.Show("Falto capturar la clave", "Clientes ♥");
                    txtClaveC.Focus();
                }

            }
            }

        private void btnModificarC_Click_1(object sender, EventArgs e)
        {
            DBClientes mibase = new DBClientes();

            Clientes doc = new Clientes();

            txtStatusC.Enabled = false;
            doc.Foto = txtFotoC.Text;
            ptbFotoC.Image = Image.FromFile(txtFotoC.Text);
            doc.Clave = int.Parse(txtClaveC.Text);
            doc.Nombre = txtNombreC.Text;
            doc.Curp = txtCurpC.Text;
            doc.Correo = txtCorreoC.Text;
            doc.Telefono = txtTelefonoC.Text;
            doc.ApellidoMaterno = txtApellidoMatC.Text;
            doc.ApellidoPaterno = txtApellidoPatC.Text;
            doc.Colonia = txtColoniaC.Text;
            doc.Calle = txtCalleC.Text;
            doc.Numero = int.Parse(txtNumeroC.Text);
            doc.Cp = int.Parse(txtCodigoPostC.Text);


            mibase.Actualizar(doc);
            dbglistaC.DataSource = null;
            DataTable datos = mibase.ConsultarTodos();
            dbglistaC.DataSource = datos;





            MessageBox.Show("Se ralizó la modificación con éxito", "Clientes ♥");

        }

        private void btnBorrarC_Click_1(object sender, EventArgs e)
        {
            DBClientes mibase = new DBClientes();
            Clientes docc = new Clientes();



            docc.Clave = int.Parse(txtClaveC.Text);
            docc.Nombre = txtNombreC.Text;
            docc.Curp = txtCurpC.Text;
            docc.Correo = txtCorreoC.Text;
            docc.Telefono = txtTelefonoC.Text;
            docc.ApellidoMaterno = txtApellidoMatC.Text;
            docc.ApellidoPaterno = txtApellidoPatC.Text;
            docc.Colonia = txtColoniaC.Text;
            docc.Calle = txtCalleC.Text;

            mibase.Deshabilitar(docc);


            txtClaveC.Text = "";
            txtNombreC.Text = "";
            txtCurpC.Text = "";
            txtCorreoC.Text = "";
            txtTelefonoC.Text = "";
            txtApellidoMatC.Text = "";
            txtApellidoPatC.Text = "";
            txtColoniaC.Text = "";
            txtCalleC.Text = "";
            txtNumeroC.Text = "";
            txtCodigoPostC.Text = "";
            txtStatusC.Text = "";
            txtFotoC.Text = "";
            ptbFotoC.Image = frmReposteria.Properties.Resources.imagen;

            DBClientes miBase = new DBClientes();
            //Limpiar el DtaGriView
            dbglistaC.DataSource = null;
            DataTable datos = miBase.ConsultarTodos();
            //Poner Los Datos de Consulta en el DataGriView 
            dbglistaC.DataSource = datos;

            DBClientes miBasee = new DBClientes();
            //Limpiar el DtaGriView
            dgvListaCli.DataSource = null;
            DataTable datoss = miBasee.ConsultarTodosDeshabilitar();
            //Poner Los Datos de Consulta en el DataGriView 

            dgvListaCli.DataSource = datoss;

        }

        private void btnFotoC_Click_1(object sender, EventArgs e)
        {
            OpenFileDialog foto = new OpenFileDialog();
            foto.InitialDirectory = "C:\\";
            foto.ShowDialog();
            txtFotoC.Text = foto.FileName;
            ptbFotoC.ImageLocation = foto.FileName;

        }

        private void btnBuscarC_Click_1(object sender, EventArgs e)
        {
            DBClientes miBase = new DBClientes();

            if (txtClaveC.Text != "")
            {
                DataTable datos = miBase.Consultar(int.Parse(txtClaveC.Text));
                if (datos.Rows.Count > 0)
                {
                    txtNombreC.Text = datos.Rows[0]["Nombre"].ToString();
                    txtCurpC.Text = datos.Rows[0]["Curp"].ToString();
                    txtCorreoC.Text = datos.Rows[0]["Correo"].ToString();
                    txtTelefonoC.Text = datos.Rows[0]["Telefono"].ToString();
                    txtApellidoMatC.Text = datos.Rows[0]["aMaterno"].ToString();
                    txtApellidoPatC.Text = datos.Rows[0]["aPaterno"].ToString();
                    txtColoniaC.Text = datos.Rows[0]["Colonia"].ToString();
                    txtCalleC.Text = datos.Rows[0]["Calle"].ToString();
                    txtNumeroC.Text = datos.Rows[0]["numeroCasa"].ToString();
                    txtCodigoPostC.Text = datos.Rows[0]["codigoPostal"].ToString();
                    txtStatusC.Text = datos.Rows[0]["status"].ToString();
                    txtFotoC.Text = datos.Rows[0]["Foto"].ToString();

                    ptbFotoC.Image = Image.FromFile(txtFotoC.Text);
                    txtClaveC.Enabled = false;
                    txtNombreC.Enabled = true;
                    txtCurpC.Enabled = true;
                    txtCorreoC.Enabled = true;
                    txtTelefonoC.Enabled = true;
                    txtApellidoMatC.Enabled = true;
                    txtApellidoPatC.Enabled = true;
                    txtColoniaC.Enabled = true;
                    txtCalleC.Enabled = true;
                    txtNumeroC.Enabled = true;

                    txtCodigoPostC.Enabled = true;
                    txtStatusC.Enabled = false;



                    btnBorrarC.Enabled = true;
                    btnModificarC.Enabled = true;



                }
                else
                {
                    MessageBox.Show("No hay registro con esa Clave", "Clientes ♥");
                }

            }

            else
            {
                MessageBox.Show("Faltó capturar la Clave", "Clientes ♥");
                txtClaveC.Focus();
            }

        }

        private void btnLimpiarC_Click_1(object sender, EventArgs e)
        {
            txtNombreC.Text = "";
            txtCurpC.Text = "";
            txtCorreoC.Text = "";
            txtTelefonoC.Text = "";
            txtApellidoMatC.Text = "";
            txtApellidoPatC.Text = "";
            txtColoniaC.Text = "";
            txtCalleC.Text = "";
            txtNumeroC.Text = "";
            txtCodigoPostC.Text = "";

            txtStatusC.Text = "";
            txtFotoC.Text = "";
            txtClaveC.Text = "";
            ptbFotoC.Image = frmReposteria.Properties.Resources.imagen;

            txtNombreC.Enabled = false;
            txtCurpC.Enabled = false;
            txtCorreoC.Enabled = false;
            txtTelefonoC.Enabled = false;
            txtApellidoMatC.Enabled = false;
            txtApellidoPatC.Enabled = false;
            txtColoniaC.Enabled = false;
            txtCalleC.Enabled = false;
            txtNumeroC.Enabled = false;
            txtClaveC.Enabled = true;
            txtCodigoPostC.Enabled = false;
            txtStatusC.Enabled = false;
            btnBorrarC.Enabled = false;
            btnModificarC.Enabled = false;

        }

        private void btnCancelarC_Click_1(object sender, EventArgs e)
        {
            txtNombreC.Text = "";
            txtCurpC.Text = "";
            txtCorreoC.Text = "";
            txtTelefonoC.Text = "";
            txtApellidoMatC.Text = "";
            txtApellidoPatC.Text = "";
            txtColoniaC.Text = "";
            txtCalleC.Text = "";
            txtNumeroC.Text = "";
            txtCodigoPostC.Text = "";

            txtStatusC.Text = "";
            ptbFotoC.Image = frmReposteria.Properties.Resources.imagen;
            txtFotoC.Text = "";
            btnModificarC.Enabled = false;
            btnBorrarC.Enabled = false;
            btnGuardarC.Enabled = false;

            txtClaveC.Enabled = false;
            txtNombreC.Enabled = false;
            txtCurpC.Enabled = false;
            txtCorreoC.Enabled = false;
            txtTelefonoC.Enabled = false;
            txtApellidoMatC.Enabled = false;
            txtApellidoPatC.Enabled = false;
            txtColoniaC.Enabled = false;
            txtCalleC.Enabled = false;
            txtNumeroC.Enabled = false;
            txtCodigoPostC.Enabled = false;
            txtStatusC.Enabled = false;

        }

        private void btnSalirC_Click_1(object sender, EventArgs e)
        {
            DialogResult clie;
            clie = MessageBox.Show("¿Deseas salir?", "Clientes ♥", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
            if (clie == DialogResult.Yes) this.Close();

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {
           

        }

        private void txtClaveC_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }

        }

        private void txtTelefonoC_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }

        }

        private void txtNumeroC_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }

        }

        private void txtCodigoPostC_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }

        }

        private void btnBuscarCli_Click(object sender, EventArgs e)
        {
            DBClientes miBase = new DBClientes();

            if (txtClaveCli.Text != "")
            {
                DataTable datos = miBase.ConsultarH(int.Parse(txtClaveCli.Text));
                if (datos.Rows.Count > 0)
                {
                    txtNombreCli.Text = datos.Rows[0]["Nombre"].ToString();
                    txtCurpCli.Text = datos.Rows[0]["Curp"].ToString();
                    txtCorreoCli.Text = datos.Rows[0]["Correo"].ToString();
                    txtTelefonoCli.Text = datos.Rows[0]["Telefono"].ToString();
                    txtApellidoMatCli.Text = datos.Rows[0]["aMaterno"].ToString();
                    txtApellidoPatCli.Text = datos.Rows[0]["aPaterno"].ToString();
                    txtColoniaCli.Text = datos.Rows[0]["Colonia"].ToString();
                    txtCalleCli.Text = datos.Rows[0]["Calle"].ToString();
                    txtNumeroCli.Text = datos.Rows[0]["numeroCasa"].ToString();
                    txtCodigoPostCli.Text = datos.Rows[0]["codigoPostal"].ToString();
                    txtStatusCli.Text = datos.Rows[0]["status"].ToString();
                    txtFotoCli.Text = datos.Rows[0]["Foto"].ToString();

                    ptbFotoCli.Image = Image.FromFile(txtFotoCli.Text);
                    txtClaveCli.Enabled = false;
                   
                    txtStatusCli.Enabled = false;



                  


                }
                else
                {
                    MessageBox.Show("No hay registro con esa Clave", "Clientes ♥");
                }

            }

            else
            {
                MessageBox.Show("Faltó capturar la Clave", "Clientes ♥");
                txtClaveCli.Focus();
            }
        }

        private void btnLimpiarCli_Click(object sender, EventArgs e)
        {
            txtNombreCli.Text = "";
            txtCurpCli.Text = "";
            txtCorreoCli.Text = "";
            txtTelefonoCli.Text = "";
            txtApellidoMatCli.Text = "";
            txtApellidoPatCli.Text = "";
            txtColoniaCli.Text = "";
            txtCalleCli.Text = "";
            txtNumeroCli.Text = "";
            txtCodigoPostCli.Text = "";

            txtStatusCli.Text = "";
            txtFotoCli.Text = "";
            txtClaveCli.Text = "";
            ptbFotoCli.Image = frmReposteria.Properties.Resources.imagen;

            txtNombreCli.Enabled = false;
            txtCurpCli.Enabled = false;
            txtCorreoCli.Enabled = false;
            txtTelefonoCli.Enabled = false;
            txtApellidoMatCli.Enabled = false;
            txtApellidoPatCli.Enabled = false;
            txtColoniaCli.Enabled = false;
            txtCalleCli.Enabled = false;
            txtNumeroCli.Enabled = false;
            txtClaveCli.Enabled = true;
            txtCodigoPostCli.Enabled = false;
            txtStatusCli.Enabled = false;
           
        }

        private void btnCancelarCli_Click(object sender, EventArgs e)
        {
            txtNombreCli.Text = "";
            txtCurpCli.Text = "";
            txtCorreoCli.Text = "";
            txtTelefonoCli.Text = "";
            txtApellidoMatCli.Text = "";
            txtApellidoPatCli.Text = "";
            txtColoniaCli.Text = "";
            txtCalleCli.Text = "";
            txtNumeroCli.Text = "";
            txtCodigoPostCli.Text = "";

            txtStatusCli.Text = "";
            txtFotoCli.Text = "";
            txtClaveCli.Text = "";
            ptbFotoCli.Image = frmReposteria.Properties.Resources.imagen;
            txtClaveCli.Enabled = false;
            txtNombreCli.Enabled = false;
            txtCurpCli.Enabled = false;
            txtCorreoCli.Enabled = false;
            txtTelefonoCli.Enabled = false;
            txtApellidoMatCli.Enabled = false;
            txtApellidoPatCli.Enabled = false;
            txtColoniaCli.Enabled = false;
            txtCalleCli.Enabled = false;
            txtNumeroCli.Enabled = false;
            txtClaveCli.Enabled = true;
            txtCodigoPostCli.Enabled = false;
            txtStatusCli.Enabled = false;
           
        }

        private void btnSalirCli_Click(object sender, EventArgs e)
        {
            DialogResult clie;
            clie = MessageBox.Show("¿Deseas salir?", "Clientes ♥", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
            if (clie == DialogResult.Yes) this.Close();
        }

        private void btnHabilitarEm_Click(object sender, EventArgs e)
        {
            DBClientes mibase = new DBClientes();
            Clientes docc = new Clientes();



            docc.Clave = int.Parse(txtClaveCli.Text);
            docc.Nombre = txtNombreCli.Text;
            docc.Curp = txtCurpCli.Text;
            docc.Correo = txtCorreoCli.Text;
            docc.Telefono = txtTelefonoCli.Text;
            docc.ApellidoMaterno = txtApellidoMatCli.Text;
            docc.ApellidoPaterno = txtApellidoPatCli.Text;
            docc.Colonia = txtColoniaCli.Text;
            docc.Calle = txtCalleCli.Text;

            mibase.Habilitar(docc);


            txtNombreCli.Text = "";
            txtCurpCli.Text = "";
            txtCorreoCli.Text = "";
            txtTelefonoCli.Text = "";
            txtApellidoMatCli.Text = "";
            txtApellidoPatCli.Text = "";
            txtColoniaCli.Text = "";
            txtCalleCli.Text = "";
            txtNumeroCli.Text = "";
            txtCodigoPostCli.Text = "";
            txtStatusCli.Text = "";
            txtFotoCli.Text = "";
            txtClaveCli.Text = "";
            ptbFotoCli.Image = frmReposteria.Properties.Resources.imagen;

            DBClientes miBase = new DBClientes();
            //Limpiar el DtaGriView
            dbglistaC.DataSource = null;
            DataTable datos = miBase.ConsultarTodos();
            //Poner Los Datos de Consulta en el DataGriView 
            dbglistaC.DataSource = datos;

            DBClientes miBasee = new DBClientes();
            //Limpiar el DtaGriView
            dgvListaCli.DataSource = null;
            DataTable datoss = miBasee.ConsultarTodosDeshabilitar();
            //Poner Los Datos de Consulta en el DataGriView 

            dgvListaCli.DataSource = datoss;
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void btnNuevoClie_Click(object sender, EventArgs e)
        {
            txtClaveCli.Enabled = true;
        }

        private void txtCorreoC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 45) || (e.KeyChar >= 47 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 63) || (e.KeyChar >= 91 && e.KeyChar <= 94) || (e.KeyChar >= 96 && e.KeyChar <= 96) || (e.KeyChar >= 123 && e.KeyChar <= 255))
            {
                MessageBox.Show("Sólo acepta letras,números y los sombolos (@ _ .)", "Advertencia");
                e.Handled = true;
                return;
            }
        }

        private void txtCorreoC_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
