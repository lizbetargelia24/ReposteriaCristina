﻿namespace frmReposteria
{
    partial class frmTipoProducto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ñ = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.txtStatusTP = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtClaveTP = new System.Windows.Forms.TextBox();
            this.txtFotoTP = new System.Windows.Forms.TextBox();
            this.txtNombreTP = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnFotoTP = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.btnGuardarTP = new System.Windows.Forms.Button();
            this.btnBuscarTP = new System.Windows.Forms.Button();
            this.btnBorrarTP = new System.Windows.Forms.Button();
            this.btnModificarTP = new System.Windows.Forms.Button();
            this.btnNuevoTP = new System.Windows.Forms.Button();
            this.dgvListaTP = new System.Windows.Forms.DataGridView();
            this.btnnCerrarTP = new System.Windows.Forms.Button();
            this.btnCancelarTP = new System.Windows.Forms.Button();
            this.btnLimpiarTP = new System.Windows.Forms.Button();
            this.ptbFotoTP = new System.Windows.Forms.PictureBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnHabilitarTPO = new System.Windows.Forms.Button();
            this.txtStatusTPO = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtClaveTPO = new System.Windows.Forms.TextBox();
            this.txtFotoTPO = new System.Windows.Forms.TextBox();
            this.txtNombreTPO = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnFotoTPO = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnBuscarTPO = new System.Windows.Forms.Button();
            this.btnNuevoTPO = new System.Windows.Forms.Button();
            this.dgvListaTPO = new System.Windows.Forms.DataGridView();
            this.btnSalirTPO = new System.Windows.Forms.Button();
            this.btnCancelarTPO = new System.Windows.Forms.Button();
            this.btnLimpiarTPO = new System.Windows.Forms.Button();
            this.cmbTipoTPO = new System.Windows.Forms.ComboBox();
            this.ptbFotoTPO = new System.Windows.Forms.PictureBox();
            this.ñ.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaTP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptbFotoTP)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaTPO)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptbFotoTPO)).BeginInit();
            this.SuspendLayout();
            // 
            // ñ
            // 
            this.ñ.Controls.Add(this.tabPage1);
            this.ñ.Controls.Add(this.tabPage2);
            this.ñ.Location = new System.Drawing.Point(12, 12);
            this.ñ.Name = "ñ";
            this.ñ.SelectedIndex = 0;
            this.ñ.Size = new System.Drawing.Size(528, 427);
            this.ñ.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tabPage1.Controls.Add(this.txtStatusTP);
            this.tabPage1.Controls.Add(this.label18);
            this.tabPage1.Controls.Add(this.txtClaveTP);
            this.tabPage1.Controls.Add(this.txtFotoTP);
            this.tabPage1.Controls.Add(this.txtNombreTP);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.btnFotoTP);
            this.tabPage1.Controls.Add(this.label16);
            this.tabPage1.Controls.Add(this.btnGuardarTP);
            this.tabPage1.Controls.Add(this.btnBuscarTP);
            this.tabPage1.Controls.Add(this.btnBorrarTP);
            this.tabPage1.Controls.Add(this.btnModificarTP);
            this.tabPage1.Controls.Add(this.btnNuevoTP);
            this.tabPage1.Controls.Add(this.dgvListaTP);
            this.tabPage1.Controls.Add(this.btnnCerrarTP);
            this.tabPage1.Controls.Add(this.btnCancelarTP);
            this.tabPage1.Controls.Add(this.btnLimpiarTP);
            this.tabPage1.Controls.Add(this.ptbFotoTP);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(520, 401);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "TipoProdu";
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // txtStatusTP
            // 
            this.txtStatusTP.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtStatusTP.Enabled = false;
            this.txtStatusTP.Location = new System.Drawing.Point(12, 145);
            this.txtStatusTP.MaxLength = 45;
            this.txtStatusTP.Name = "txtStatusTP";
            this.txtStatusTP.Size = new System.Drawing.Size(110, 20);
            this.txtStatusTP.TabIndex = 140;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label18.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(9, 121);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(43, 16);
            this.label18.TabIndex = 156;
            this.label18.Text = "Status";
            // 
            // txtClaveTP
            // 
            this.txtClaveTP.Enabled = false;
            this.txtClaveTP.Location = new System.Drawing.Point(12, 36);
            this.txtClaveTP.MaxLength = 10;
            this.txtClaveTP.Name = "txtClaveTP";
            this.txtClaveTP.Size = new System.Drawing.Size(98, 20);
            this.txtClaveTP.TabIndex = 137;
            this.txtClaveTP.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtClaveTP_KeyPress);
            // 
            // txtFotoTP
            // 
            this.txtFotoTP.Enabled = false;
            this.txtFotoTP.Location = new System.Drawing.Point(408, 350);
            this.txtFotoTP.Name = "txtFotoTP";
            this.txtFotoTP.Size = new System.Drawing.Size(97, 20);
            this.txtFotoTP.TabIndex = 154;
            // 
            // txtNombreTP
            // 
            this.txtNombreTP.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtNombreTP.Enabled = false;
            this.txtNombreTP.Location = new System.Drawing.Point(12, 88);
            this.txtNombreTP.MaxLength = 45;
            this.txtNombreTP.Name = "txtNombreTP";
            this.txtNombreTP.Size = new System.Drawing.Size(110, 20);
            this.txtNombreTP.TabIndex = 139;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label2.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 16);
            this.label2.TabIndex = 155;
            this.label2.Text = "Clave";
            // 
            // btnFotoTP
            // 
            this.btnFotoTP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnFotoTP.Enabled = false;
            this.btnFotoTP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnFotoTP.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFotoTP.Location = new System.Drawing.Point(463, 321);
            this.btnFotoTP.Name = "btnFotoTP";
            this.btnFotoTP.Size = new System.Drawing.Size(42, 23);
            this.btnFotoTP.TabIndex = 142;
            this.btnFotoTP.Text = "...";
            this.btnFotoTP.UseVisualStyleBackColor = false;
            this.btnFotoTP.Click += new System.EventHandler(this.btnFotoTP_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label16.Cursor = System.Windows.Forms.Cursors.Cross;
            this.label16.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(8, 72);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(50, 16);
            this.label16.TabIndex = 152;
            this.label16.Text = "Nombre";
            // 
            // btnGuardarTP
            // 
            this.btnGuardarTP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnGuardarTP.Enabled = false;
            this.btnGuardarTP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnGuardarTP.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGuardarTP.ForeColor = System.Drawing.Color.Black;
            this.btnGuardarTP.Image = global::frmReposteria.Properties.Resources.guardar2;
            this.btnGuardarTP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGuardarTP.Location = new System.Drawing.Point(421, 58);
            this.btnGuardarTP.Name = "btnGuardarTP";
            this.btnGuardarTP.Size = new System.Drawing.Size(84, 36);
            this.btnGuardarTP.TabIndex = 143;
            this.btnGuardarTP.Text = "Guardar";
            this.btnGuardarTP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnGuardarTP.UseVisualStyleBackColor = false;
            this.btnGuardarTP.Click += new System.EventHandler(this.btnGuardarTP_Click);
            // 
            // btnBuscarTP
            // 
            this.btnBuscarTP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnBuscarTP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBuscarTP.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscarTP.ForeColor = System.Drawing.Color.Black;
            this.btnBuscarTP.Image = global::frmReposteria.Properties.Resources.buscar;
            this.btnBuscarTP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBuscarTP.Location = new System.Drawing.Point(128, 13);
            this.btnBuscarTP.Name = "btnBuscarTP";
            this.btnBuscarTP.Size = new System.Drawing.Size(73, 37);
            this.btnBuscarTP.TabIndex = 144;
            this.btnBuscarTP.Text = "Buscar";
            this.btnBuscarTP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBuscarTP.UseVisualStyleBackColor = false;
            this.btnBuscarTP.Click += new System.EventHandler(this.btnBuscarTP_Click);
            // 
            // btnBorrarTP
            // 
            this.btnBorrarTP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnBorrarTP.Enabled = false;
            this.btnBorrarTP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBorrarTP.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBorrarTP.ForeColor = System.Drawing.Color.Black;
            this.btnBorrarTP.Image = global::frmReposteria.Properties.Resources.cubo_de_basura;
            this.btnBorrarTP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBorrarTP.Location = new System.Drawing.Point(430, 141);
            this.btnBorrarTP.Name = "btnBorrarTP";
            this.btnBorrarTP.Size = new System.Drawing.Size(75, 40);
            this.btnBorrarTP.TabIndex = 147;
            this.btnBorrarTP.Text = "Borrar";
            this.btnBorrarTP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBorrarTP.UseVisualStyleBackColor = false;
            this.btnBorrarTP.Click += new System.EventHandler(this.btnBorrarTP_Click);
            // 
            // btnModificarTP
            // 
            this.btnModificarTP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnModificarTP.Enabled = false;
            this.btnModificarTP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnModificarTP.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnModificarTP.ForeColor = System.Drawing.Color.Black;
            this.btnModificarTP.Image = global::frmReposteria.Properties.Resources.herramientas_del_empleado_de_mantenimiento;
            this.btnModificarTP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnModificarTP.Location = new System.Drawing.Point(415, 99);
            this.btnModificarTP.Name = "btnModificarTP";
            this.btnModificarTP.Size = new System.Drawing.Size(90, 36);
            this.btnModificarTP.TabIndex = 145;
            this.btnModificarTP.Text = "Modificar";
            this.btnModificarTP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnModificarTP.UseVisualStyleBackColor = false;
            this.btnModificarTP.Click += new System.EventHandler(this.btnModificarTP_Click);
            // 
            // btnNuevoTP
            // 
            this.btnNuevoTP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnNuevoTP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNuevoTP.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNuevoTP.ForeColor = System.Drawing.Color.Black;
            this.btnNuevoTP.Image = global::frmReposteria.Properties.Resources.agregar_usuario;
            this.btnNuevoTP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNuevoTP.Location = new System.Drawing.Point(430, 14);
            this.btnNuevoTP.Name = "btnNuevoTP";
            this.btnNuevoTP.Size = new System.Drawing.Size(75, 38);
            this.btnNuevoTP.TabIndex = 141;
            this.btnNuevoTP.Text = "Nuevo";
            this.btnNuevoTP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNuevoTP.UseVisualStyleBackColor = false;
            this.btnNuevoTP.Click += new System.EventHandler(this.btnNuevoTP_Click);
            // 
            // dgvListaTP
            // 
            this.dgvListaTP.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.dgvListaTP.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvListaTP.Location = new System.Drawing.Point(11, 299);
            this.dgvListaTP.Name = "dgvListaTP";
            this.dgvListaTP.Size = new System.Drawing.Size(380, 96);
            this.dgvListaTP.TabIndex = 150;
            this.dgvListaTP.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvListaTP_CellContentClick);
            // 
            // btnnCerrarTP
            // 
            this.btnnCerrarTP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnnCerrarTP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnnCerrarTP.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnnCerrarTP.ForeColor = System.Drawing.Color.Black;
            this.btnnCerrarTP.Image = global::frmReposteria.Properties.Resources.salir_3;
            this.btnnCerrarTP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnnCerrarTP.Location = new System.Drawing.Point(177, 262);
            this.btnnCerrarTP.Name = "btnnCerrarTP";
            this.btnnCerrarTP.Size = new System.Drawing.Size(65, 31);
            this.btnnCerrarTP.TabIndex = 149;
            this.btnnCerrarTP.Text = "Salir";
            this.btnnCerrarTP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnnCerrarTP.UseVisualStyleBackColor = false;
            this.btnnCerrarTP.Click += new System.EventHandler(this.btnnCerrarTP_Click);
            // 
            // btnCancelarTP
            // 
            this.btnCancelarTP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnCancelarTP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCancelarTP.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelarTP.ForeColor = System.Drawing.Color.Black;
            this.btnCancelarTP.Image = global::frmReposteria.Properties.Resources.prohibido__1_;
            this.btnCancelarTP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCancelarTP.Location = new System.Drawing.Point(92, 262);
            this.btnCancelarTP.Name = "btnCancelarTP";
            this.btnCancelarTP.Size = new System.Drawing.Size(79, 31);
            this.btnCancelarTP.TabIndex = 148;
            this.btnCancelarTP.Text = "Cancelar";
            this.btnCancelarTP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCancelarTP.UseVisualStyleBackColor = false;
            this.btnCancelarTP.Click += new System.EventHandler(this.btnCancelarTP_Click);
            // 
            // btnLimpiarTP
            // 
            this.btnLimpiarTP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnLimpiarTP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnLimpiarTP.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpiarTP.ForeColor = System.Drawing.Color.Black;
            this.btnLimpiarTP.Image = global::frmReposteria.Properties.Resources.escoba_de_limpieza_para_suelos__1_;
            this.btnLimpiarTP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLimpiarTP.Location = new System.Drawing.Point(12, 262);
            this.btnLimpiarTP.Name = "btnLimpiarTP";
            this.btnLimpiarTP.Size = new System.Drawing.Size(74, 34);
            this.btnLimpiarTP.TabIndex = 146;
            this.btnLimpiarTP.Text = "Limpiar";
            this.btnLimpiarTP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLimpiarTP.UseVisualStyleBackColor = false;
            this.btnLimpiarTP.Click += new System.EventHandler(this.btnLimpiarTP_Click);
            // 
            // ptbFotoTP
            // 
            this.ptbFotoTP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.ptbFotoTP.Image = global::frmReposteria.Properties.Resources.imagen5;
            this.ptbFotoTP.Location = new System.Drawing.Point(405, 193);
            this.ptbFotoTP.Name = "ptbFotoTP";
            this.ptbFotoTP.Size = new System.Drawing.Size(100, 122);
            this.ptbFotoTP.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ptbFotoTP.TabIndex = 153;
            this.ptbFotoTP.TabStop = false;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tabPage2.Controls.Add(this.btnHabilitarTPO);
            this.tabPage2.Controls.Add(this.txtStatusTPO);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.txtClaveTPO);
            this.tabPage2.Controls.Add(this.txtFotoTPO);
            this.tabPage2.Controls.Add(this.txtNombreTPO);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.btnFotoTPO);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.btnBuscarTPO);
            this.tabPage2.Controls.Add(this.btnNuevoTPO);
            this.tabPage2.Controls.Add(this.dgvListaTPO);
            this.tabPage2.Controls.Add(this.btnSalirTPO);
            this.tabPage2.Controls.Add(this.btnCancelarTPO);
            this.tabPage2.Controls.Add(this.btnLimpiarTPO);
            this.tabPage2.Controls.Add(this.cmbTipoTPO);
            this.tabPage2.Controls.Add(this.ptbFotoTPO);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(520, 401);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Habilitar";
            this.tabPage2.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // btnHabilitarTPO
            // 
            this.btnHabilitarTPO.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnHabilitarTPO.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnHabilitarTPO.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHabilitarTPO.Image = global::frmReposteria.Properties.Resources.copia_de_seguridad;
            this.btnHabilitarTPO.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHabilitarTPO.Location = new System.Drawing.Point(129, 58);
            this.btnHabilitarTPO.Name = "btnHabilitarTPO";
            this.btnHabilitarTPO.Size = new System.Drawing.Size(87, 37);
            this.btnHabilitarTPO.TabIndex = 216;
            this.btnHabilitarTPO.Text = "Habilitar";
            this.btnHabilitarTPO.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnHabilitarTPO.UseVisualStyleBackColor = false;
            this.btnHabilitarTPO.Click += new System.EventHandler(this.btnHabilitarTPO_Click);
            // 
            // txtStatusTPO
            // 
            this.txtStatusTPO.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtStatusTPO.Enabled = false;
            this.txtStatusTPO.Location = new System.Drawing.Point(16, 200);
            this.txtStatusTPO.MaxLength = 45;
            this.txtStatusTPO.Name = "txtStatusTPO";
            this.txtStatusTPO.Size = new System.Drawing.Size(110, 20);
            this.txtStatusTPO.TabIndex = 160;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 176);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 16);
            this.label1.TabIndex = 176;
            this.label1.Text = "Status";
            // 
            // txtClaveTPO
            // 
            this.txtClaveTPO.Enabled = false;
            this.txtClaveTPO.Location = new System.Drawing.Point(14, 34);
            this.txtClaveTPO.MaxLength = 10;
            this.txtClaveTPO.Name = "txtClaveTPO";
            this.txtClaveTPO.Size = new System.Drawing.Size(98, 20);
            this.txtClaveTPO.TabIndex = 157;
            this.txtClaveTPO.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtClaveTPO_KeyPress);
            // 
            // txtFotoTPO
            // 
            this.txtFotoTPO.Enabled = false;
            this.txtFotoTPO.Location = new System.Drawing.Point(407, 228);
            this.txtFotoTPO.Name = "txtFotoTPO";
            this.txtFotoTPO.Size = new System.Drawing.Size(97, 20);
            this.txtFotoTPO.TabIndex = 174;
            // 
            // txtNombreTPO
            // 
            this.txtNombreTPO.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtNombreTPO.Enabled = false;
            this.txtNombreTPO.Location = new System.Drawing.Point(16, 143);
            this.txtNombreTPO.MaxLength = 45;
            this.txtNombreTPO.Name = "txtNombreTPO";
            this.txtNombreTPO.Size = new System.Drawing.Size(110, 20);
            this.txtNombreTPO.TabIndex = 159;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label3.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(14, 15);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 16);
            this.label3.TabIndex = 175;
            this.label3.Text = "Clave";
            // 
            // btnFotoTPO
            // 
            this.btnFotoTPO.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnFotoTPO.Enabled = false;
            this.btnFotoTPO.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnFotoTPO.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFotoTPO.Location = new System.Drawing.Point(407, 199);
            this.btnFotoTPO.Name = "btnFotoTPO";
            this.btnFotoTPO.Size = new System.Drawing.Size(42, 23);
            this.btnFotoTPO.TabIndex = 162;
            this.btnFotoTPO.Text = "...";
            this.btnFotoTPO.UseVisualStyleBackColor = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label4.Cursor = System.Windows.Forms.Cursors.Cross;
            this.label4.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(12, 127);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 16);
            this.label4.TabIndex = 172;
            this.label4.Text = "Descripcion";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label5.Cursor = System.Windows.Forms.Cursors.Cross;
            this.label5.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(11, 75);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(99, 16);
            this.label5.TabIndex = 171;
            this.label5.Text = "Tipo de Producto";
            // 
            // btnBuscarTPO
            // 
            this.btnBuscarTPO.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnBuscarTPO.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBuscarTPO.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscarTPO.ForeColor = System.Drawing.Color.Black;
            this.btnBuscarTPO.Image = global::frmReposteria.Properties.Resources.buscar;
            this.btnBuscarTPO.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBuscarTPO.Location = new System.Drawing.Point(143, 15);
            this.btnBuscarTPO.Name = "btnBuscarTPO";
            this.btnBuscarTPO.Size = new System.Drawing.Size(73, 37);
            this.btnBuscarTPO.TabIndex = 164;
            this.btnBuscarTPO.Text = "Buscar";
            this.btnBuscarTPO.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBuscarTPO.UseVisualStyleBackColor = false;
            this.btnBuscarTPO.Click += new System.EventHandler(this.btnBuscarTPO_Click);
            // 
            // btnNuevoTPO
            // 
            this.btnNuevoTPO.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnNuevoTPO.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNuevoTPO.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNuevoTPO.ForeColor = System.Drawing.Color.Black;
            this.btnNuevoTPO.Image = global::frmReposteria.Properties.Resources.agregar_usuario;
            this.btnNuevoTPO.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNuevoTPO.Location = new System.Drawing.Point(432, 16);
            this.btnNuevoTPO.Name = "btnNuevoTPO";
            this.btnNuevoTPO.Size = new System.Drawing.Size(75, 38);
            this.btnNuevoTPO.TabIndex = 161;
            this.btnNuevoTPO.Text = "Nuevo";
            this.btnNuevoTPO.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNuevoTPO.UseVisualStyleBackColor = false;
            this.btnNuevoTPO.Click += new System.EventHandler(this.btnNuevoTPO_Click);
            // 
            // dgvListaTPO
            // 
            this.dgvListaTPO.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.dgvListaTPO.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvListaTPO.Location = new System.Drawing.Point(14, 298);
            this.dgvListaTPO.Name = "dgvListaTPO";
            this.dgvListaTPO.Size = new System.Drawing.Size(380, 96);
            this.dgvListaTPO.TabIndex = 170;
            // 
            // btnSalirTPO
            // 
            this.btnSalirTPO.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnSalirTPO.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSalirTPO.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalirTPO.ForeColor = System.Drawing.Color.Black;
            this.btnSalirTPO.Image = global::frmReposteria.Properties.Resources.salir_3;
            this.btnSalirTPO.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSalirTPO.Location = new System.Drawing.Point(184, 242);
            this.btnSalirTPO.Name = "btnSalirTPO";
            this.btnSalirTPO.Size = new System.Drawing.Size(65, 31);
            this.btnSalirTPO.TabIndex = 169;
            this.btnSalirTPO.Text = "Salir";
            this.btnSalirTPO.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSalirTPO.UseVisualStyleBackColor = false;
            this.btnSalirTPO.Click += new System.EventHandler(this.btnSalirTPO_Click);
            // 
            // btnCancelarTPO
            // 
            this.btnCancelarTPO.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnCancelarTPO.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCancelarTPO.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelarTPO.ForeColor = System.Drawing.Color.Black;
            this.btnCancelarTPO.Image = global::frmReposteria.Properties.Resources.prohibido__1_;
            this.btnCancelarTPO.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCancelarTPO.Location = new System.Drawing.Point(99, 242);
            this.btnCancelarTPO.Name = "btnCancelarTPO";
            this.btnCancelarTPO.Size = new System.Drawing.Size(79, 31);
            this.btnCancelarTPO.TabIndex = 168;
            this.btnCancelarTPO.Text = "Cancelar";
            this.btnCancelarTPO.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCancelarTPO.UseVisualStyleBackColor = false;
            this.btnCancelarTPO.Click += new System.EventHandler(this.btnCancelarTPO_Click);
            // 
            // btnLimpiarTPO
            // 
            this.btnLimpiarTPO.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnLimpiarTPO.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnLimpiarTPO.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpiarTPO.ForeColor = System.Drawing.Color.Black;
            this.btnLimpiarTPO.Image = global::frmReposteria.Properties.Resources.escoba_de_limpieza_para_suelos__1_;
            this.btnLimpiarTPO.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLimpiarTPO.Location = new System.Drawing.Point(19, 242);
            this.btnLimpiarTPO.Name = "btnLimpiarTPO";
            this.btnLimpiarTPO.Size = new System.Drawing.Size(74, 34);
            this.btnLimpiarTPO.TabIndex = 166;
            this.btnLimpiarTPO.Text = "Limpiar";
            this.btnLimpiarTPO.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLimpiarTPO.UseVisualStyleBackColor = false;
            this.btnLimpiarTPO.Click += new System.EventHandler(this.btnLimpiarTPO_Click);
            // 
            // cmbTipoTPO
            // 
            this.cmbTipoTPO.Enabled = false;
            this.cmbTipoTPO.FormattingEnabled = true;
            this.cmbTipoTPO.Items.AddRange(new object[] {
            "1: Pastel",
            "2: Empanada",
            "3: Gelatina",
            "4:Pay",
            "5:Galletas"});
            this.cmbTipoTPO.Location = new System.Drawing.Point(14, 94);
            this.cmbTipoTPO.Name = "cmbTipoTPO";
            this.cmbTipoTPO.Size = new System.Drawing.Size(98, 21);
            this.cmbTipoTPO.TabIndex = 158;
            this.cmbTipoTPO.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbTipoTPO_KeyPress);
            // 
            // ptbFotoTPO
            // 
            this.ptbFotoTPO.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.ptbFotoTPO.Image = global::frmReposteria.Properties.Resources.imagen5;
            this.ptbFotoTPO.Location = new System.Drawing.Point(407, 70);
            this.ptbFotoTPO.Name = "ptbFotoTPO";
            this.ptbFotoTPO.Size = new System.Drawing.Size(100, 122);
            this.ptbFotoTPO.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ptbFotoTPO.TabIndex = 173;
            this.ptbFotoTPO.TabStop = false;
            // 
            // frmTipoProducto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(551, 448);
            this.Controls.Add(this.ñ);
            this.Name = "frmTipoProducto";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmTipoProducto";
            this.Load += new System.EventHandler(this.frmTipoProducto_Load);
            this.ñ.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaTP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptbFotoTP)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaTPO)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptbFotoTPO)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl ñ;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox txtStatusTP;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtClaveTP;
        private System.Windows.Forms.TextBox txtFotoTP;
        private System.Windows.Forms.TextBox txtNombreTP;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnFotoTP;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button btnGuardarTP;
        private System.Windows.Forms.Button btnBuscarTP;
        private System.Windows.Forms.Button btnBorrarTP;
        private System.Windows.Forms.Button btnModificarTP;
        private System.Windows.Forms.Button btnNuevoTP;
        private System.Windows.Forms.DataGridView dgvListaTP;
        private System.Windows.Forms.Button btnnCerrarTP;
        private System.Windows.Forms.Button btnCancelarTP;
        private System.Windows.Forms.Button btnLimpiarTP;
        private System.Windows.Forms.PictureBox ptbFotoTP;
        private System.Windows.Forms.TextBox txtStatusTPO;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtClaveTPO;
        private System.Windows.Forms.TextBox txtFotoTPO;
        private System.Windows.Forms.TextBox txtNombreTPO;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnFotoTPO;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnBuscarTPO;
        private System.Windows.Forms.Button btnNuevoTPO;
        private System.Windows.Forms.DataGridView dgvListaTPO;
        private System.Windows.Forms.Button btnSalirTPO;
        private System.Windows.Forms.Button btnCancelarTPO;
        private System.Windows.Forms.Button btnLimpiarTPO;
        private System.Windows.Forms.ComboBox cmbTipoTPO;
        private System.Windows.Forms.PictureBox ptbFotoTPO;
        private System.Windows.Forms.Button btnHabilitarTPO;
    }
}