﻿namespace frmReposteria
{
    partial class frmPedidos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.txtStatusp = new System.Windows.Forms.TextBox();
            this.txtFotoP = new System.Windows.Forms.TextBox();
            this.btnFotoP = new System.Windows.Forms.Button();
            this.dtpFechaP = new System.Windows.Forms.DateTimePicker();
            this.txtAnticipoP = new System.Windows.Forms.TextBox();
            this.txtDescripcionP = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dgvListaP = new System.Windows.Forms.DataGridView();
            this.txtClaveP = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.ptbFotoP = new System.Windows.Forms.PictureBox();
            this.btnBuscarP = new System.Windows.Forms.Button();
            this.btnSalirP = new System.Windows.Forms.Button();
            this.btnCancelarP = new System.Windows.Forms.Button();
            this.btnLimpiarP = new System.Windows.Forms.Button();
            this.btnBorrarP = new System.Windows.Forms.Button();
            this.btnModificarP = new System.Windows.Forms.Button();
            this.btnGuardarP = new System.Windows.Forms.Button();
            this.btnNuevoP = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.txtStatusH = new System.Windows.Forms.TextBox();
            this.btnHabilitarTGG = new System.Windows.Forms.Button();
            this.txtFotoH = new System.Windows.Forms.TextBox();
            this.btnFotoH = new System.Windows.Forms.Button();
            this.dtpFechaH = new System.Windows.Forms.DateTimePicker();
            this.txtAntiH = new System.Windows.Forms.TextBox();
            this.txtdescrH = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.dgvListaH = new System.Windows.Forms.DataGridView();
            this.txtClaveH = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.ptbFotoH = new System.Windows.Forms.PictureBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptbFotoP)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptbFotoH)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(480, 444);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tabPage1.Controls.Add(this.txtStatusp);
            this.tabPage1.Controls.Add(this.txtFotoP);
            this.tabPage1.Controls.Add(this.btnFotoP);
            this.tabPage1.Controls.Add(this.dtpFechaP);
            this.tabPage1.Controls.Add(this.txtAnticipoP);
            this.tabPage1.Controls.Add(this.txtDescripcionP);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.dgvListaP);
            this.tabPage1.Controls.Add(this.txtClaveP);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.ptbFotoP);
            this.tabPage1.Controls.Add(this.btnBuscarP);
            this.tabPage1.Controls.Add(this.btnSalirP);
            this.tabPage1.Controls.Add(this.btnCancelarP);
            this.tabPage1.Controls.Add(this.btnLimpiarP);
            this.tabPage1.Controls.Add(this.btnBorrarP);
            this.tabPage1.Controls.Add(this.btnModificarP);
            this.tabPage1.Controls.Add(this.btnGuardarP);
            this.tabPage1.Controls.Add(this.btnNuevoP);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(472, 418);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Pedidos";
            // 
            // txtStatusp
            // 
            this.txtStatusp.Enabled = false;
            this.txtStatusp.Location = new System.Drawing.Point(14, 246);
            this.txtStatusp.MaxLength = 10;
            this.txtStatusp.Name = "txtStatusp";
            this.txtStatusp.Size = new System.Drawing.Size(100, 20);
            this.txtStatusp.TabIndex = 229;
            // 
            // txtFotoP
            // 
            this.txtFotoP.Enabled = false;
            this.txtFotoP.Location = new System.Drawing.Point(361, 352);
            this.txtFotoP.MaxLength = 10;
            this.txtFotoP.Name = "txtFotoP";
            this.txtFotoP.Size = new System.Drawing.Size(100, 20);
            this.txtFotoP.TabIndex = 228;
            // 
            // btnFotoP
            // 
            this.btnFotoP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnFotoP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnFotoP.Location = new System.Drawing.Point(361, 322);
            this.btnFotoP.Name = "btnFotoP";
            this.btnFotoP.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnFotoP.Size = new System.Drawing.Size(32, 24);
            this.btnFotoP.TabIndex = 213;
            this.btnFotoP.Text = "....";
            this.btnFotoP.UseVisualStyleBackColor = false;
            this.btnFotoP.Click += new System.EventHandler(this.btnFotoP_Click_1);
            // 
            // dtpFechaP
            // 
            this.dtpFechaP.Enabled = false;
            this.dtpFechaP.Location = new System.Drawing.Point(12, 140);
            this.dtpFechaP.Name = "dtpFechaP";
            this.dtpFechaP.Size = new System.Drawing.Size(184, 20);
            this.dtpFechaP.TabIndex = 3;
            // 
            // txtAnticipoP
            // 
            this.txtAnticipoP.Enabled = false;
            this.txtAnticipoP.Location = new System.Drawing.Point(12, 196);
            this.txtAnticipoP.MaxLength = 10;
            this.txtAnticipoP.Name = "txtAnticipoP";
            this.txtAnticipoP.Size = new System.Drawing.Size(100, 20);
            this.txtAnticipoP.TabIndex = 4;
            this.txtAnticipoP.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAnticipoP_KeyPress_1);
            // 
            // txtDescripcionP
            // 
            this.txtDescripcionP.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtDescripcionP.Enabled = false;
            this.txtDescripcionP.Location = new System.Drawing.Point(12, 87);
            this.txtDescripcionP.MaxLength = 45;
            this.txtDescripcionP.Name = "txtDescripcionP";
            this.txtDescripcionP.Size = new System.Drawing.Size(100, 20);
            this.txtDescripcionP.TabIndex = 2;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label5.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(11, 177);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 16);
            this.label5.TabIndex = 226;
            this.label5.Text = "Anticipo";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label4.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(11, 227);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(43, 16);
            this.label4.TabIndex = 225;
            this.label4.Text = "Status";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label3.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(11, 121);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(101, 16);
            this.label3.TabIndex = 224;
            this.label3.Text = "Fecha De Pedidos";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label2.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(9, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 16);
            this.label2.TabIndex = 223;
            this.label2.Text = "Descripcion";
            // 
            // dgvListaP
            // 
            this.dgvListaP.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.dgvListaP.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvListaP.Location = new System.Drawing.Point(12, 321);
            this.dgvListaP.Name = "dgvListaP";
            this.dgvListaP.Size = new System.Drawing.Size(336, 83);
            this.dgvListaP.TabIndex = 222;
            // 
            // txtClaveP
            // 
            this.txtClaveP.Enabled = false;
            this.txtClaveP.Location = new System.Drawing.Point(12, 34);
            this.txtClaveP.MaxLength = 10;
            this.txtClaveP.Name = "txtClaveP";
            this.txtClaveP.Size = new System.Drawing.Size(100, 20);
            this.txtClaveP.TabIndex = 1;
            this.txtClaveP.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtClaveP_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(9, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 16);
            this.label1.TabIndex = 221;
            this.label1.Text = "Clave";
            // 
            // ptbFotoP
            // 
            this.ptbFotoP.Image = global::frmReposteria.Properties.Resources.imagen_4;
            this.ptbFotoP.Location = new System.Drawing.Point(361, 181);
            this.ptbFotoP.Name = "ptbFotoP";
            this.ptbFotoP.Size = new System.Drawing.Size(100, 135);
            this.ptbFotoP.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ptbFotoP.TabIndex = 227;
            this.ptbFotoP.TabStop = false;
            // 
            // btnBuscarP
            // 
            this.btnBuscarP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnBuscarP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBuscarP.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscarP.Image = global::frmReposteria.Properties.Resources.buscar;
            this.btnBuscarP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBuscarP.Location = new System.Drawing.Point(134, 11);
            this.btnBuscarP.Name = "btnBuscarP";
            this.btnBuscarP.Size = new System.Drawing.Size(75, 32);
            this.btnBuscarP.TabIndex = 215;
            this.btnBuscarP.Text = "Buscar";
            this.btnBuscarP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBuscarP.UseVisualStyleBackColor = false;
            this.btnBuscarP.Click += new System.EventHandler(this.btnBuscarP_Click_1);
            // 
            // btnSalirP
            // 
            this.btnSalirP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnSalirP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSalirP.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalirP.Image = global::frmReposteria.Properties.Resources.salir_3;
            this.btnSalirP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSalirP.Location = new System.Drawing.Point(177, 283);
            this.btnSalirP.Name = "btnSalirP";
            this.btnSalirP.Size = new System.Drawing.Size(60, 32);
            this.btnSalirP.TabIndex = 220;
            this.btnSalirP.Text = "Salir";
            this.btnSalirP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSalirP.UseVisualStyleBackColor = false;
            this.btnSalirP.Click += new System.EventHandler(this.btnSalirP_Click_1);
            // 
            // btnCancelarP
            // 
            this.btnCancelarP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnCancelarP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCancelarP.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelarP.Image = global::frmReposteria.Properties.Resources.prohibido__1_;
            this.btnCancelarP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCancelarP.Location = new System.Drawing.Point(93, 283);
            this.btnCancelarP.Name = "btnCancelarP";
            this.btnCancelarP.Size = new System.Drawing.Size(78, 32);
            this.btnCancelarP.TabIndex = 219;
            this.btnCancelarP.Text = "Cancelar";
            this.btnCancelarP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCancelarP.UseVisualStyleBackColor = false;
            this.btnCancelarP.Click += new System.EventHandler(this.btnCancelarP_Click_1);
            // 
            // btnLimpiarP
            // 
            this.btnLimpiarP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnLimpiarP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnLimpiarP.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpiarP.Image = global::frmReposteria.Properties.Resources.escoba_de_limpieza_para_suelos__1_;
            this.btnLimpiarP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLimpiarP.Location = new System.Drawing.Point(12, 283);
            this.btnLimpiarP.Name = "btnLimpiarP";
            this.btnLimpiarP.Size = new System.Drawing.Size(75, 32);
            this.btnLimpiarP.TabIndex = 217;
            this.btnLimpiarP.Text = "Limpiar";
            this.btnLimpiarP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLimpiarP.UseVisualStyleBackColor = false;
            this.btnLimpiarP.Click += new System.EventHandler(this.btnLimpiarP_Click_1);
            // 
            // btnBorrarP
            // 
            this.btnBorrarP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnBorrarP.Enabled = false;
            this.btnBorrarP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBorrarP.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBorrarP.Image = global::frmReposteria.Properties.Resources.cubo_de_basura;
            this.btnBorrarP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBorrarP.Location = new System.Drawing.Point(390, 127);
            this.btnBorrarP.Name = "btnBorrarP";
            this.btnBorrarP.Size = new System.Drawing.Size(69, 31);
            this.btnBorrarP.TabIndex = 218;
            this.btnBorrarP.Text = "Borrar";
            this.btnBorrarP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBorrarP.UseVisualStyleBackColor = false;
            this.btnBorrarP.Click += new System.EventHandler(this.btnBorrarP_Click_1);
            // 
            // btnModificarP
            // 
            this.btnModificarP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnModificarP.Enabled = false;
            this.btnModificarP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnModificarP.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnModificarP.Image = global::frmReposteria.Properties.Resources.herramientas_del_empleado_de_mantenimiento;
            this.btnModificarP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnModificarP.Location = new System.Drawing.Point(371, 89);
            this.btnModificarP.Name = "btnModificarP";
            this.btnModificarP.Size = new System.Drawing.Size(88, 32);
            this.btnModificarP.TabIndex = 216;
            this.btnModificarP.Text = "Modificar";
            this.btnModificarP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnModificarP.UseVisualStyleBackColor = false;
            this.btnModificarP.Click += new System.EventHandler(this.btnModificarP_Click_1);
            // 
            // btnGuardarP
            // 
            this.btnGuardarP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnGuardarP.Enabled = false;
            this.btnGuardarP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnGuardarP.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGuardarP.Image = global::frmReposteria.Properties.Resources.guardar2;
            this.btnGuardarP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGuardarP.Location = new System.Drawing.Point(374, 46);
            this.btnGuardarP.Name = "btnGuardarP";
            this.btnGuardarP.Size = new System.Drawing.Size(85, 37);
            this.btnGuardarP.TabIndex = 214;
            this.btnGuardarP.Text = "Guardar";
            this.btnGuardarP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnGuardarP.UseVisualStyleBackColor = false;
            this.btnGuardarP.Click += new System.EventHandler(this.btnGuardarP_Click_1);
            // 
            // btnNuevoP
            // 
            this.btnNuevoP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnNuevoP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNuevoP.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNuevoP.Image = global::frmReposteria.Properties.Resources.agregar_usuario;
            this.btnNuevoP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNuevoP.Location = new System.Drawing.Point(390, 11);
            this.btnNuevoP.Name = "btnNuevoP";
            this.btnNuevoP.Size = new System.Drawing.Size(69, 29);
            this.btnNuevoP.TabIndex = 212;
            this.btnNuevoP.Text = "Nuevo";
            this.btnNuevoP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNuevoP.UseVisualStyleBackColor = false;
            this.btnNuevoP.Click += new System.EventHandler(this.btnNuevoP_Click_1);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tabPage2.Controls.Add(this.txtStatusH);
            this.tabPage2.Controls.Add(this.btnHabilitarTGG);
            this.tabPage2.Controls.Add(this.txtFotoH);
            this.tabPage2.Controls.Add(this.btnFotoH);
            this.tabPage2.Controls.Add(this.dtpFechaH);
            this.tabPage2.Controls.Add(this.txtAntiH);
            this.tabPage2.Controls.Add(this.txtdescrH);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.dgvListaH);
            this.tabPage2.Controls.Add(this.txtClaveH);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.ptbFotoH);
            this.tabPage2.Controls.Add(this.button2);
            this.tabPage2.Controls.Add(this.button3);
            this.tabPage2.Controls.Add(this.button4);
            this.tabPage2.Controls.Add(this.button5);
            this.tabPage2.Controls.Add(this.button9);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(472, 418);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Habilitar";
            // 
            // txtStatusH
            // 
            this.txtStatusH.Enabled = false;
            this.txtStatusH.Location = new System.Drawing.Point(15, 248);
            this.txtStatusH.MaxLength = 10;
            this.txtStatusH.Name = "txtStatusH";
            this.txtStatusH.Size = new System.Drawing.Size(100, 20);
            this.txtStatusH.TabIndex = 252;
            // 
            // btnHabilitarTGG
            // 
            this.btnHabilitarTGG.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnHabilitarTGG.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnHabilitarTGG.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHabilitarTGG.Image = global::frmReposteria.Properties.Resources.copia_de_seguridad;
            this.btnHabilitarTGG.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHabilitarTGG.Location = new System.Drawing.Point(135, 51);
            this.btnHabilitarTGG.Name = "btnHabilitarTGG";
            this.btnHabilitarTGG.Size = new System.Drawing.Size(87, 37);
            this.btnHabilitarTGG.TabIndex = 251;
            this.btnHabilitarTGG.Text = "Habilitar";
            this.btnHabilitarTGG.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnHabilitarTGG.UseVisualStyleBackColor = false;
            this.btnHabilitarTGG.Click += new System.EventHandler(this.btnHabilitarTGG_Click);
            // 
            // txtFotoH
            // 
            this.txtFotoH.Enabled = false;
            this.txtFotoH.Location = new System.Drawing.Point(360, 254);
            this.txtFotoH.MaxLength = 10;
            this.txtFotoH.Name = "txtFotoH";
            this.txtFotoH.Size = new System.Drawing.Size(100, 20);
            this.txtFotoH.TabIndex = 250;
            // 
            // btnFotoH
            // 
            this.btnFotoH.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnFotoH.Enabled = false;
            this.btnFotoH.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnFotoH.Location = new System.Drawing.Point(360, 224);
            this.btnFotoH.Name = "btnFotoH";
            this.btnFotoH.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnFotoH.Size = new System.Drawing.Size(32, 24);
            this.btnFotoH.TabIndex = 235;
            this.btnFotoH.Text = "....";
            this.btnFotoH.UseVisualStyleBackColor = false;
            // 
            // dtpFechaH
            // 
            this.dtpFechaH.Enabled = false;
            this.dtpFechaH.Location = new System.Drawing.Point(13, 142);
            this.dtpFechaH.Name = "dtpFechaH";
            this.dtpFechaH.Size = new System.Drawing.Size(184, 20);
            this.dtpFechaH.TabIndex = 231;
            // 
            // txtAntiH
            // 
            this.txtAntiH.Enabled = false;
            this.txtAntiH.Location = new System.Drawing.Point(13, 198);
            this.txtAntiH.MaxLength = 10;
            this.txtAntiH.Name = "txtAntiH";
            this.txtAntiH.Size = new System.Drawing.Size(100, 20);
            this.txtAntiH.TabIndex = 233;
            // 
            // txtdescrH
            // 
            this.txtdescrH.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtdescrH.Enabled = false;
            this.txtdescrH.Location = new System.Drawing.Point(13, 89);
            this.txtdescrH.MaxLength = 45;
            this.txtdescrH.Name = "txtdescrH";
            this.txtdescrH.Size = new System.Drawing.Size(100, 20);
            this.txtdescrH.TabIndex = 230;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label6.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(12, 179);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(51, 16);
            this.label6.TabIndex = 248;
            this.label6.Text = "Anticipo";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label7.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(12, 229);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(43, 16);
            this.label7.TabIndex = 247;
            this.label7.Text = "Status";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label8.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(12, 123);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(101, 16);
            this.label8.TabIndex = 246;
            this.label8.Text = "Fecha De Pedidos";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label9.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(10, 70);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(68, 16);
            this.label9.TabIndex = 245;
            this.label9.Text = "Descripcion";
            // 
            // dgvListaH
            // 
            this.dgvListaH.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.dgvListaH.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvListaH.Location = new System.Drawing.Point(13, 323);
            this.dgvListaH.Name = "dgvListaH";
            this.dgvListaH.Size = new System.Drawing.Size(336, 83);
            this.dgvListaH.TabIndex = 244;
            // 
            // txtClaveH
            // 
            this.txtClaveH.Enabled = false;
            this.txtClaveH.Location = new System.Drawing.Point(13, 36);
            this.txtClaveH.MaxLength = 10;
            this.txtClaveH.Name = "txtClaveH";
            this.txtClaveH.Size = new System.Drawing.Size(100, 20);
            this.txtClaveH.TabIndex = 229;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label10.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(10, 13);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(35, 16);
            this.label10.TabIndex = 243;
            this.label10.Text = "Clave";
            // 
            // ptbFotoH
            // 
            this.ptbFotoH.Image = global::frmReposteria.Properties.Resources.imagen_4;
            this.ptbFotoH.Location = new System.Drawing.Point(360, 83);
            this.ptbFotoH.Name = "ptbFotoH";
            this.ptbFotoH.Size = new System.Drawing.Size(100, 135);
            this.ptbFotoH.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ptbFotoH.TabIndex = 249;
            this.ptbFotoH.TabStop = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button2.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Image = global::frmReposteria.Properties.Resources.buscar;
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.Location = new System.Drawing.Point(135, 13);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 32);
            this.button2.TabIndex = 237;
            this.button2.Text = "Buscar";
            this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button3.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Image = global::frmReposteria.Properties.Resources.salir_3;
            this.button3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.Location = new System.Drawing.Point(178, 285);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(60, 32);
            this.button3.TabIndex = 242;
            this.button3.Text = "Salir";
            this.button3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button4.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Image = global::frmReposteria.Properties.Resources.prohibido__1_;
            this.button4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button4.Location = new System.Drawing.Point(94, 285);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(78, 32);
            this.button4.TabIndex = 241;
            this.button4.Text = "Cancelar";
            this.button4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button5.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Image = global::frmReposteria.Properties.Resources.escoba_de_limpieza_para_suelos__1_;
            this.button5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button5.Location = new System.Drawing.Point(13, 285);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 32);
            this.button5.TabIndex = 239;
            this.button5.Text = "Limpiar";
            this.button5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button9.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.Image = global::frmReposteria.Properties.Resources.agregar_usuario;
            this.button9.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button9.Location = new System.Drawing.Point(391, 13);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(69, 29);
            this.button9.TabIndex = 234;
            this.button9.Text = "Nuevo";
            this.button9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // frmPedidos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(504, 468);
            this.Controls.Add(this.tabControl1);
            this.Name = "frmPedidos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmPedidos";
            this.Load += new System.EventHandler(this.frmPedidos_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptbFotoP)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptbFotoH)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox txtFotoP;
        private System.Windows.Forms.Button btnFotoP;
        private System.Windows.Forms.DateTimePicker dtpFechaP;
        private System.Windows.Forms.TextBox txtAnticipoP;
        private System.Windows.Forms.TextBox txtDescripcionP;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dgvListaP;
        private System.Windows.Forms.TextBox txtClaveP;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox ptbFotoP;
        private System.Windows.Forms.Button btnBuscarP;
        private System.Windows.Forms.Button btnSalirP;
        private System.Windows.Forms.Button btnCancelarP;
        private System.Windows.Forms.Button btnLimpiarP;
        private System.Windows.Forms.Button btnBorrarP;
        private System.Windows.Forms.Button btnModificarP;
        private System.Windows.Forms.Button btnGuardarP;
        private System.Windows.Forms.Button btnNuevoP;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox txtFotoH;
        private System.Windows.Forms.Button btnFotoH;
        private System.Windows.Forms.DateTimePicker dtpFechaH;
        private System.Windows.Forms.TextBox txtAntiH;
        private System.Windows.Forms.TextBox txtdescrH;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DataGridView dgvListaH;
        private System.Windows.Forms.TextBox txtClaveH;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.PictureBox ptbFotoH;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button btnHabilitarTGG;
        private System.Windows.Forms.TextBox txtStatusp;
        private System.Windows.Forms.TextBox txtStatusH;
    }
}