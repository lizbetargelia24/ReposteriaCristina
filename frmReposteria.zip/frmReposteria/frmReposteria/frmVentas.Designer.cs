﻿namespace frmReposteria
{
    partial class frmVentas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtCantidadV = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtUtilidadV = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtTotalCompraV = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtTotalVentaV = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtPrecioCompraV = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtPrecioVentaV = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cmbProductoV = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtCodigoV = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnRealizaCompraV = new System.Windows.Forms.Button();
            this.dgvListaV = new System.Windows.Forms.DataGridView();
            this.btnCancelarV = new System.Windows.Forms.Button();
            this.btnGuardarV = new System.Windows.Forms.Button();
            this.btnLimpiarV = new System.Windows.Forms.Button();
            this.btnBorrarV = new System.Windows.Forms.Button();
            this.btnSalirV = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cmbTipoPagoV = new System.Windows.Forms.ComboBox();
            this.cmbClienteV = new System.Windows.Forms.ComboBox();
            this.cmbEmpleadoV = new System.Windows.Forms.ComboBox();
            this.txtFolioVenta = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnNuevoV = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dtpFechaV = new System.Windows.Forms.DateTimePicker();
            this.btnBuscarV = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaV)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox2.Controls.Add(this.txtCantidadV);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.txtUtilidadV);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.txtTotalCompraV);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.txtTotalVentaV);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.txtPrecioCompraV);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.txtPrecioVentaV);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.cmbProductoV);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.txtCodigoV);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.btnRealizaCompraV);
            this.groupBox2.Controls.Add(this.dgvListaV);
            this.groupBox2.Controls.Add(this.btnCancelarV);
            this.groupBox2.Controls.Add(this.btnGuardarV);
            this.groupBox2.Controls.Add(this.btnLimpiarV);
            this.groupBox2.Controls.Add(this.btnBorrarV);
            this.groupBox2.Controls.Add(this.btnSalirV);
            this.groupBox2.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(13, 250);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(790, 318);
            this.groupBox2.TabIndex = 30;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Detalle Venta";
            // 
            // txtCantidadV
            // 
            this.txtCantidadV.Enabled = false;
            this.txtCantidadV.Location = new System.Drawing.Point(332, 114);
            this.txtCantidadV.MaxLength = 10;
            this.txtCantidadV.Name = "txtCantidadV";
            this.txtCantidadV.Size = new System.Drawing.Size(116, 23);
            this.txtCantidadV.TabIndex = 9;
            this.txtCantidadV.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCantidadV_KeyPress);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label13.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label13.Location = new System.Drawing.Point(242, 121);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(53, 16);
            this.label13.TabIndex = 44;
            this.label13.Text = "Cantidad";
            // 
            // txtUtilidadV
            // 
            this.txtUtilidadV.Enabled = false;
            this.txtUtilidadV.Location = new System.Drawing.Point(646, 76);
            this.txtUtilidadV.MaxLength = 10;
            this.txtUtilidadV.Name = "txtUtilidadV";
            this.txtUtilidadV.Size = new System.Drawing.Size(116, 23);
            this.txtUtilidadV.TabIndex = 41;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label12.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label12.Location = new System.Drawing.Point(556, 83);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(48, 16);
            this.label12.TabIndex = 42;
            this.label12.Text = "Utilidad";
            // 
            // txtTotalCompraV
            // 
            this.txtTotalCompraV.Enabled = false;
            this.txtTotalCompraV.Location = new System.Drawing.Point(646, 47);
            this.txtTotalCompraV.MaxLength = 10;
            this.txtTotalCompraV.Name = "txtTotalCompraV";
            this.txtTotalCompraV.Size = new System.Drawing.Size(116, 23);
            this.txtTotalCompraV.TabIndex = 39;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label10.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label10.Location = new System.Drawing.Point(556, 54);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(80, 16);
            this.label10.TabIndex = 40;
            this.label10.Text = "Total Compra";
            // 
            // txtTotalVentaV
            // 
            this.txtTotalVentaV.Enabled = false;
            this.txtTotalVentaV.Location = new System.Drawing.Point(646, 16);
            this.txtTotalVentaV.MaxLength = 10;
            this.txtTotalVentaV.Name = "txtTotalVentaV";
            this.txtTotalVentaV.Size = new System.Drawing.Size(116, 23);
            this.txtTotalVentaV.TabIndex = 37;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label11.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label11.Location = new System.Drawing.Point(556, 23);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(71, 16);
            this.label11.TabIndex = 38;
            this.label11.Text = "Total Venta";
            // 
            // txtPrecioCompraV
            // 
            this.txtPrecioCompraV.Enabled = false;
            this.txtPrecioCompraV.Location = new System.Drawing.Point(332, 85);
            this.txtPrecioCompraV.MaxLength = 10;
            this.txtPrecioCompraV.Name = "txtPrecioCompraV";
            this.txtPrecioCompraV.Size = new System.Drawing.Size(116, 23);
            this.txtPrecioCompraV.TabIndex = 8;
            this.txtPrecioCompraV.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPrecioCompraV_KeyPress);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label9.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label9.Location = new System.Drawing.Point(242, 92);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(84, 16);
            this.label9.TabIndex = 36;
            this.label9.Text = "Precio Compra";
            // 
            // txtPrecioVentaV
            // 
            this.txtPrecioVentaV.Enabled = false;
            this.txtPrecioVentaV.Location = new System.Drawing.Point(332, 54);
            this.txtPrecioVentaV.MaxLength = 10;
            this.txtPrecioVentaV.Name = "txtPrecioVentaV";
            this.txtPrecioVentaV.Size = new System.Drawing.Size(116, 23);
            this.txtPrecioVentaV.TabIndex = 7;
            this.txtPrecioVentaV.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPrecioVentaV_KeyPress);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label8.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label8.Location = new System.Drawing.Point(242, 61);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(75, 16);
            this.label8.TabIndex = 34;
            this.label8.Text = "Precio Venta";
            // 
            // cmbProductoV
            // 
            this.cmbProductoV.Enabled = false;
            this.cmbProductoV.FormattingEnabled = true;
            this.cmbProductoV.Location = new System.Drawing.Point(327, 20);
            this.cmbProductoV.Name = "cmbProductoV";
            this.cmbProductoV.Size = new System.Drawing.Size(121, 24);
            this.cmbProductoV.TabIndex = 6;
            this.cmbProductoV.SelectedIndexChanged += new System.EventHandler(this.cmbProductoV_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label7.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label7.Location = new System.Drawing.Point(242, 28);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(54, 16);
            this.label7.TabIndex = 31;
            this.label7.Text = "Producto";
            // 
            // txtCodigoV
            // 
            this.txtCodigoV.Enabled = false;
            this.txtCodigoV.Location = new System.Drawing.Point(11, 52);
            this.txtCodigoV.MaxLength = 10;
            this.txtCodigoV.Name = "txtCodigoV";
            this.txtCodigoV.Size = new System.Drawing.Size(116, 23);
            this.txtCodigoV.TabIndex = 29;
            this.txtCodigoV.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCodigoV_KeyPress);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label6.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label6.Location = new System.Drawing.Point(11, 31);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(42, 16);
            this.label6.TabIndex = 30;
            this.label6.Text = "Codigo";
            // 
            // btnRealizaCompraV
            // 
            this.btnRealizaCompraV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnRealizaCompraV.Enabled = false;
            this.btnRealizaCompraV.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRealizaCompraV.Font = new System.Drawing.Font("Comic Sans MS", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRealizaCompraV.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRealizaCompraV.Location = new System.Drawing.Point(614, 172);
            this.btnRealizaCompraV.Name = "btnRealizaCompraV";
            this.btnRealizaCompraV.Size = new System.Drawing.Size(120, 67);
            this.btnRealizaCompraV.TabIndex = 28;
            this.btnRealizaCompraV.Text = "Realizar la Venta";
            this.btnRealizaCompraV.UseVisualStyleBackColor = false;
            this.btnRealizaCompraV.Click += new System.EventHandler(this.btnRealizaCompraV_Click);
            // 
            // dgvListaV
            // 
            this.dgvListaV.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.dgvListaV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvListaV.Location = new System.Drawing.Point(11, 160);
            this.dgvListaV.Name = "dgvListaV";
            this.dgvListaV.Size = new System.Drawing.Size(540, 100);
            this.dgvListaV.TabIndex = 26;
            this.dgvListaV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvListaV_CellContentClick);
            // 
            // btnCancelarV
            // 
            this.btnCancelarV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnCancelarV.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCancelarV.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelarV.Image = global::frmReposteria.Properties.Resources.prohibido__1_;
            this.btnCancelarV.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCancelarV.Location = new System.Drawing.Point(104, 270);
            this.btnCancelarV.Name = "btnCancelarV";
            this.btnCancelarV.Size = new System.Drawing.Size(91, 39);
            this.btnCancelarV.TabIndex = 26;
            this.btnCancelarV.Text = "Cancelar";
            this.btnCancelarV.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCancelarV.UseVisualStyleBackColor = false;
            this.btnCancelarV.Click += new System.EventHandler(this.btnCancelarV_Click);
            // 
            // btnGuardarV
            // 
            this.btnGuardarV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnGuardarV.Enabled = false;
            this.btnGuardarV.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnGuardarV.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGuardarV.Image = global::frmReposteria.Properties.Resources.guardar2;
            this.btnGuardarV.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGuardarV.Location = new System.Drawing.Point(559, 160);
            this.btnGuardarV.Name = "btnGuardarV";
            this.btnGuardarV.Size = new System.Drawing.Size(34, 44);
            this.btnGuardarV.TabIndex = 19;
            this.btnGuardarV.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnGuardarV.UseVisualStyleBackColor = false;
            this.btnGuardarV.Click += new System.EventHandler(this.btnGuardarV_Click);
            // 
            // btnLimpiarV
            // 
            this.btnLimpiarV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnLimpiarV.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnLimpiarV.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpiarV.Image = global::frmReposteria.Properties.Resources.escoba_de_limpieza_para_suelos__1_;
            this.btnLimpiarV.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLimpiarV.Location = new System.Drawing.Point(10, 270);
            this.btnLimpiarV.Name = "btnLimpiarV";
            this.btnLimpiarV.Size = new System.Drawing.Size(87, 39);
            this.btnLimpiarV.TabIndex = 24;
            this.btnLimpiarV.Text = "Limpiar";
            this.btnLimpiarV.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLimpiarV.UseVisualStyleBackColor = false;
            this.btnLimpiarV.Click += new System.EventHandler(this.btnLimpiarV_Click);
            // 
            // btnBorrarV
            // 
            this.btnBorrarV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnBorrarV.Enabled = false;
            this.btnBorrarV.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBorrarV.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBorrarV.Image = global::frmReposteria.Properties.Resources.cubo_de_basura;
            this.btnBorrarV.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBorrarV.Location = new System.Drawing.Point(559, 208);
            this.btnBorrarV.Name = "btnBorrarV";
            this.btnBorrarV.Size = new System.Drawing.Size(34, 36);
            this.btnBorrarV.TabIndex = 25;
            this.btnBorrarV.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBorrarV.UseVisualStyleBackColor = false;
            this.btnBorrarV.Click += new System.EventHandler(this.btnBorrarV_Click);
            // 
            // btnSalirV
            // 
            this.btnSalirV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnSalirV.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSalirV.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalirV.Image = global::frmReposteria.Properties.Resources.salir_3;
            this.btnSalirV.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSalirV.Location = new System.Drawing.Point(202, 270);
            this.btnSalirV.Name = "btnSalirV";
            this.btnSalirV.Size = new System.Drawing.Size(70, 39);
            this.btnSalirV.TabIndex = 27;
            this.btnSalirV.Text = "Salir";
            this.btnSalirV.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSalirV.UseVisualStyleBackColor = false;
            this.btnSalirV.Click += new System.EventHandler(this.btnSalirV_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.cmbTipoPagoV);
            this.groupBox1.Controls.Add(this.cmbClienteV);
            this.groupBox1.Controls.Add(this.cmbEmpleadoV);
            this.groupBox1.Controls.Add(this.txtFolioVenta);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.btnNuevoV);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.dtpFechaV);
            this.groupBox1.Controls.Add(this.btnBuscarV);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(790, 217);
            this.groupBox1.TabIndex = 29;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Venta";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label5.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label5.Location = new System.Drawing.Point(239, 80);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 16);
            this.label5.TabIndex = 32;
            this.label5.Text = "Tipo de Pago";
            // 
            // cmbTipoPagoV
            // 
            this.cmbTipoPagoV.Enabled = false;
            this.cmbTipoPagoV.FormattingEnabled = true;
            this.cmbTipoPagoV.Location = new System.Drawing.Point(242, 104);
            this.cmbTipoPagoV.Name = "cmbTipoPagoV";
            this.cmbTipoPagoV.Size = new System.Drawing.Size(121, 24);
            this.cmbTipoPagoV.TabIndex = 5;
            // 
            // cmbClienteV
            // 
            this.cmbClienteV.Enabled = false;
            this.cmbClienteV.FormattingEnabled = true;
            this.cmbClienteV.Location = new System.Drawing.Point(19, 167);
            this.cmbClienteV.Name = "cmbClienteV";
            this.cmbClienteV.Size = new System.Drawing.Size(121, 24);
            this.cmbClienteV.TabIndex = 3;
            // 
            // cmbEmpleadoV
            // 
            this.cmbEmpleadoV.Enabled = false;
            this.cmbEmpleadoV.FormattingEnabled = true;
            this.cmbEmpleadoV.Location = new System.Drawing.Point(19, 109);
            this.cmbEmpleadoV.Name = "cmbEmpleadoV";
            this.cmbEmpleadoV.Size = new System.Drawing.Size(121, 24);
            this.cmbEmpleadoV.TabIndex = 2;
            this.cmbEmpleadoV.SelectedIndexChanged += new System.EventHandler(this.cmbEmpleadoV_SelectedIndexChanged);
            // 
            // txtFolioVenta
            // 
            this.txtFolioVenta.Enabled = false;
            this.txtFolioVenta.Location = new System.Drawing.Point(19, 53);
            this.txtFolioVenta.MaxLength = 10;
            this.txtFolioVenta.Name = "txtFolioVenta";
            this.txtFolioVenta.Size = new System.Drawing.Size(116, 23);
            this.txtFolioVenta.TabIndex = 1;
            this.txtFolioVenta.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFolioVenta_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label4.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label4.Location = new System.Drawing.Point(16, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(85, 16);
            this.label4.TabIndex = 28;
            this.label4.Text = "Folio de Venta";
            // 
            // btnNuevoV
            // 
            this.btnNuevoV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnNuevoV.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNuevoV.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNuevoV.Image = global::frmReposteria.Properties.Resources.agregar_usuario;
            this.btnNuevoV.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNuevoV.Location = new System.Drawing.Point(614, 39);
            this.btnNuevoV.Name = "btnNuevoV";
            this.btnNuevoV.Size = new System.Drawing.Size(120, 57);
            this.btnNuevoV.TabIndex = 15;
            this.btnNuevoV.Text = "Nueva Venta";
            this.btnNuevoV.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNuevoV.UseVisualStyleBackColor = false;
            this.btnNuevoV.Click += new System.EventHandler(this.btnNuevoV_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label3.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3.Location = new System.Drawing.Point(239, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 16);
            this.label3.TabIndex = 23;
            this.label3.Text = "Fecha";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label2.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.Location = new System.Drawing.Point(15, 141);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 16);
            this.label2.TabIndex = 20;
            this.label2.Text = "Cliente";
            // 
            // dtpFechaV
            // 
            this.dtpFechaV.Enabled = false;
            this.dtpFechaV.Location = new System.Drawing.Point(242, 50);
            this.dtpFechaV.Name = "dtpFechaV";
            this.dtpFechaV.Size = new System.Drawing.Size(233, 23);
            this.dtpFechaV.TabIndex = 4;
            // 
            // btnBuscarV
            // 
            this.btnBuscarV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnBuscarV.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBuscarV.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscarV.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBuscarV.Location = new System.Drawing.Point(143, 21);
            this.btnBuscarV.Name = "btnBuscarV";
            this.btnBuscarV.Size = new System.Drawing.Size(39, 25);
            this.btnBuscarV.TabIndex = 21;
            this.btnBuscarV.Text = "<<";
            this.btnBuscarV.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBuscarV.UseVisualStyleBackColor = false;
            this.btnBuscarV.Click += new System.EventHandler(this.btnBuscarV_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(15, 85);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 16);
            this.label1.TabIndex = 13;
            this.label1.Text = "Empleado";
            // 
            // frmVentas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(816, 567);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "frmVentas";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmVentas";
            this.Load += new System.EventHandler(this.frmVentas_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaV)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtUtilidadV;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtTotalCompraV;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtTotalVentaV;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtPrecioCompraV;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtPrecioVentaV;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cmbProductoV;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtCodigoV;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnRealizaCompraV;
        private System.Windows.Forms.DataGridView dgvListaV;
        private System.Windows.Forms.Button btnCancelarV;
        private System.Windows.Forms.Button btnGuardarV;
        private System.Windows.Forms.Button btnLimpiarV;
        private System.Windows.Forms.Button btnBorrarV;
        private System.Windows.Forms.Button btnSalirV;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmbTipoPagoV;
        private System.Windows.Forms.ComboBox cmbClienteV;
        private System.Windows.Forms.ComboBox cmbEmpleadoV;
        private System.Windows.Forms.TextBox txtFolioVenta;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnNuevoV;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dtpFechaV;
        private System.Windows.Forms.Button btnBuscarV;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtCantidadV;
        private System.Windows.Forms.Label label13;
    }
}