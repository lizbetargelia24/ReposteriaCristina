﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;

namespace frmReposteria
{
    class DBEmpleados
    {
        private MySqlConnection conexion;
        private string strConexion;
        private MySqlCommand sqlComando;
        private string strConsulta;
        private MySqlDataAdapter adaptador;

        public DBEmpleados()
        {
            //Constructor
            conexion = new MySqlConnection();
            strConexion = "Server=localHost;User=root;DataBase=bdreposteria;port=3306;Password=";

            conexion.ConnectionString = strConexion;

            sqlComando = new MySqlCommand();
            adaptador = new MySqlDataAdapter();

        }
        public Boolean abrir()
        {
            Boolean exito = false;

            if (conexion.State == System.Data.ConnectionState.Closed)
            {

                conexion.Open();
                exito = true;

            }



            return exito;
        }
        public Boolean Cerrar()
        {
            Boolean exito = false;

            if (conexion.State == System.Data.ConnectionState.Closed)
            {

                exito = false;
            }
            else
            {
                conexion.Close();
                exito = true;
            }
            return exito;
        }
        // public Boolean Cerrar()
        // {
        //    Boolean exito = false;
        //    if (conexion.State == ConnectionState.Closed)
        //    {
        //    conexion.Close();
        //   exito = true;
        // }
        // return exito;
        // }


        //Agregar sin parametros
        // public void agregarSinParsametros(Empleado obj)
        //{
        //    string sqlConsulta = "insert into especialidades (idespecialidades,codigo,nombre,status) values (null," + obj.Clave + "," + obj.Nombre + ",0)";
        //    this.abrir();
        //    sqlComando.Connection = conexion;
        //    sqlComando.CommandText = sqlConsulta;

        //    sqlComando.ExecuteNonQuery();
        //    this.Cerrar();
        //}
        //Agregar usando parametros
        public void agregarUsandoParametros(Empleado obj)
        {
            string sqlConsulta = "insert into templeado (idEmpleado,clave,nombre, aPaterno, aMaterno, fechaNac, curp, colonia, calle, telefono, numeroCasa, foto, status)values(null, ?pclave, ?pnombre, ?paPaterno, ?paMaterno, ?pfechaNac, ?pcurp, ?pcolonia, ?pcalle,  ?ptelefono,?pnumeroCasa, ?pfoto, 0)";
            sqlComando.Parameters.Clear();

            sqlComando.Parameters.Add("?pclave", MySql.Data.MySqlClient.MySqlDbType.Int32).Value = obj.Clave;
            sqlComando.Parameters.Add("?pnombre", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Nombre;
            sqlComando.Parameters.Add("?paPaterno", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.APaterno;
            sqlComando.Parameters.Add("?paMaterno", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.AMaterno;
            sqlComando.Parameters.Add("?pfechaNac", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.FecNac;
            sqlComando.Parameters.Add("?pcurp", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Curp;
            sqlComando.Parameters.Add("?pcolonia", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Colonia;
            sqlComando.Parameters.Add("?pcalle", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Calle;
            sqlComando.Parameters.Add("?pnumeroCasa", MySql.Data.MySqlClient.MySqlDbType.Int32).Value = obj.Numero;
            sqlComando.Parameters.Add("?ptelefono", MySql.Data.MySqlClient.MySqlDbType.Int32).Value = obj.Telefono;
            sqlComando.Parameters.Add("?pfoto", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Foto;
            this.abrir();
            sqlComando.Connection = conexion;
            sqlComando.CommandText = sqlConsulta;

            sqlComando.ExecuteNonQuery();
            this.Cerrar();

        }
        //Actualizar
        public void Actualizar(Empleado obj)
        {
            string sqlConsulta = "Update templeado set nombre = ?pnombre , aPaterno = ?paPaterno, aMaterno = ?paMaterno, fechaNac = ?pfechaNac, curp = ?pcurp, colonia = ?pcolonia, calle = ?pcalle, telefono = ?ptelefono, numeroCasa = ?pnumeroCasa, foto = ?pfoto where clave = ?pclave and status=0";
            sqlComando.Parameters.Clear();

            sqlComando.Parameters.Add("?pclave", MySql.Data.MySqlClient.MySqlDbType.UInt32).Value = obj.Clave;
            sqlComando.Parameters.Add("?pnombre", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Nombre;
            sqlComando.Parameters.Add("?paPaterno", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.APaterno;
            sqlComando.Parameters.Add("?paMaterno", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.AMaterno;
            sqlComando.Parameters.Add("?pfechaNac", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.FecNac;
            sqlComando.Parameters.Add("?pcurp", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Curp;
            sqlComando.Parameters.Add("?pcolonia", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Colonia;
            sqlComando.Parameters.Add("?pcalle", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Calle;
            sqlComando.Parameters.Add("?ptelefono", MySql.Data.MySqlClient.MySqlDbType.Int32).Value = obj.Telefono;
            sqlComando.Parameters.Add("?pnumeroCasa", MySql.Data.MySqlClient.MySqlDbType.Int32).Value = obj.Numero;
            sqlComando.Parameters.Add("?pfoto", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Foto;
            this.abrir();
            sqlComando.Connection = conexion;
            sqlComando.CommandText = sqlConsulta;

            sqlComando.ExecuteNonQuery();
            this.Cerrar();
        }
        //Deshabilitar
        public void Deshabilitar(Empleado obj)
        {
            string sqlConsulta = "update templeado set status=1 where clave = ?pclave and status = 0";
            sqlComando.Parameters.Clear();

            sqlComando.Parameters.Add("?pclave", MySql.Data.MySqlClient.MySqlDbType.Int32).Value = obj.Clave;

            this.abrir();
            sqlComando.Connection = conexion;
            sqlComando.CommandText = sqlConsulta;

            sqlComando.ExecuteNonQuery();
            this.Cerrar();
        }
        //Consultar
        public DataTable Consultar(int Clave)
        {
            DataTable datos = new DataTable();
            strConsulta = "select * from templeado where status = 0 and clave =" + Clave;

            this.abrir();
            sqlComando.CommandText = strConsulta;
            sqlComando.Connection = conexion;
            adaptador.SelectCommand = sqlComando;
            adaptador.Fill(datos);

            this.Cerrar();

            return datos;
        }
        //Metodo consultar todos
        public DataTable ConsultarTodos()
        {
            DataTable datos = new DataTable();
            strConsulta = "select *from templeado where status = 0 order by clave asc";
            abrir();
            sqlComando.CommandText = strConsulta;
            sqlComando.Connection = conexion;

            adaptador.SelectCommand = sqlComando;
            adaptador.Fill(datos);
            Cerrar();
            return datos;
        }
        public DataTable ConsultarTodosDeshabilitar()
        {
            DataTable datos = new DataTable();
            strConsulta = "select *from templeado where status = 1 order by clave asc";
            abrir();
            sqlComando.CommandText = strConsulta;
            sqlComando.Connection = conexion;

            adaptador.SelectCommand = sqlComando;
            adaptador.Fill(datos);
            Cerrar();
            return datos;
        }
        public void Habilitar(Empleado obj)
        {
            string sqlConsulta = "update templeado set status=0 where clave = ?pclave and status = 1";
            sqlComando.Parameters.Clear();

            sqlComando.Parameters.Add("?pclave", MySql.Data.MySqlClient.MySqlDbType.Int32).Value = obj.Clave;

            this.abrir();
            sqlComando.Connection = conexion;
            sqlComando.CommandText = sqlConsulta;

            sqlComando.ExecuteNonQuery();
            this.Cerrar();
        }
        public DataTable ConsultarH(int Clave)
        {
            DataTable datos = new DataTable();
            strConsulta = "select * from templeado where status = 1 and clave =" + Clave;

            this.abrir();
            sqlComando.CommandText = strConsulta;
            sqlComando.Connection = conexion;
            adaptador.SelectCommand = sqlComando;
            adaptador.Fill(datos);

            this.Cerrar();

            return datos;
        }
        public DataTable ConsultarTodos3()
        {
            DataTable datos = new DataTable();
            strConsulta = "select *from templeado where status = 0 order by clave asc";
            abrir();
            sqlComando.CommandText = strConsulta;
            sqlComando.Connection = conexion;

            adaptador.SelectCommand = sqlComando;
            adaptador.Fill(datos);
            Cerrar();
            return datos;
        }
        //public DataTable mostrarEmpleados()
       // {
       //    DataTable registros = new DataTable();
        //    string sqlConsulta;
       //     this.abrir();
        //    sqlConsulta = "SELECT templeado.nombre AS empleado, templeado.clave, templeado.curp,templeado.nombre,templeado.idEmpleado, templeado.aPaterno, templeado.aMaterno, templeado.fechaNac, templeado.telefono, templeado.colonia, templeado.calle, templeado.numeroCasa, templeado.foto, templeado.status FROM templeado INNER JOIN tventas ON templeado.idEmpleado = tventas.folioVenta";

        //    sqlComando.CommandText = sqlConsulta;
        //    sqlComando.Connection = conexion;

        //    adaptador.SelectCommand = sqlComando;
        //    adaptador.Fill(registros);
        //    this.Cerrar();

      ///      return registros;
       // }
    }

}
