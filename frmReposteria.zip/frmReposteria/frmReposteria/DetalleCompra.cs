﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace frmReposteria
{
    class DetalleCompra
    {

        private int iddetalleventa;
        private int codigo;
        private float precioVenta;
        private float precioCompra;
        private string producto;
        private int folioCom;
        private float totalCompra;
        private float utilidad;
        private int cantidad;


        public DetalleCompra()
        {

            this.iddetalleventa = 0;
            this.precioVenta = 0.0f;
            this.precioCompra = 0.0f;
            this.producto = "";
            this.folioCom = 0;
            this.totalCompra = 0.0f;
            this.utilidad = 0.0f;
            this.codigo = 0;
            this.cantidad = 0;

        }
        public DetalleCompra(int iddetalleventa, int codigo,  float precioCompra, string producto, int folioCom,  float totalCompra, int cantidad)
        {

            this.iddetalleventa = iddetalleventa;
            this.codigo = codigo;
      
            this.precioCompra = precioCompra;
            this.producto = producto;
            this.folioCom = folioCom;
            this.totalCompra = totalCompra;
      
            this.cantidad = cantidad;

        }
       /// public int IddetalleVenta
     //   {
      //      set { this.iddetalleventa = value; }
      //      get { return this.iddetalleventa; }
     //   }

        public int Codigo
        {
            set { this.codigo = value; }
            get { return this.codigo; }
        }
       
       
        public float PrecioCompra
        {
            set { this.precioCompra = value; }
            get { return this.precioCompra; }
        }
        public string Producto
        {
            set { this.producto = value; }
            get { return this.producto; }
        }
        public int FolioCom
        {
            set { this.folioCom = value; }
            get { return this.folioCom; }
        }
        public float TotalCompra
        {
            set { this.totalCompra = value; }
            get { return this.totalCompra; }
        }
       
        public int Cantidad
        {
            set { this.cantidad = value; }
            get { return this.cantidad; }
        }

        // public float calcularTotalVentaC()
        //  {
        //       float costo = 0.0f;
        //       costo = this.PrecioVenta * this.cantidad;
        //       return costo;
        //    }
        public float calcularTotalCompraC()
        {
            float costo = 0.0f;
            costo = this.PrecioCompra * this.cantidad;
            return costo;
        }
        //    public float calcularUtilidadC()
        //   {
        //      float utilidad = 0.0f;
        //     utilidad = (this.precioVenta - this.PrecioCompra) * this.cantidad;
        //     return utilidad;
        // }
    }
}
