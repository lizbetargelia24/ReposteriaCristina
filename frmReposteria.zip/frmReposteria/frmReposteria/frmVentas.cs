﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace frmReposteria
{
    public partial class frmVentas : Form
    {
        public frmVentas()
        {
            InitializeComponent();
        }
        private ArrayList ven = new ArrayList();
        private Ventas vent;
        private DetalleVenta detalle;
        private void btnBorrarV_Click(object sender, EventArgs e)
        {
            if (dgvListaV.Rows.Count > 0)
            {
                int index = dgvListaV.CurrentRow.Index;
                DetalleVenta detalle = (DetalleVenta)ven[index];
                DialogResult res = MessageBox.Show("Deseas borrar el producto " + detalle.Producto, "Productos",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
                if (res == DialogResult.Yes)
                {
                    ven.RemoveAt(index);
                    dgvListaV.DataSource = null;
                    dgvListaV.DataSource = ven;

                }
            }
        }

        private void btnNuevoV_Click(object sender, EventArgs e)
        {
            cmbEmpleadoV.Text = "";
            cmbProductoV.Text = "";
            cmbClienteV.Text = "";
            cmbTipoPagoV.Text = "";
            txtFolioVenta.Text = "";
            dgvListaV.DataSource = null;
            txtFolioVenta.Enabled = true;
            cmbClienteV.Enabled = true;
            cmbTipoPagoV.Enabled = true;
            cmbProductoV.Enabled = true;
            cmbEmpleadoV.Enabled = true;
            txtCodigoV.Enabled = true;
            dtpFechaV.Enabled = true;
            txtPrecioCompraV.Enabled = true;
            txtPrecioVentaV.Enabled = true;
          //  txtTotalCompraV.Enabled = true;
          //  txtTotalVentaV.Enabled = true;
          //  txtUtilidadV.Enabled = true;
            btnBorrarV.Enabled = true;
            btnCancelarV.Enabled = true;
            btnBuscarV.Enabled = true;
            btnLimpiarV.Enabled = true;
            btnSalirV.Enabled = true;
            txtCantidadV.Enabled = true;
            btnGuardarV.Enabled = true;
            btnRealizaCompraV.Enabled = true;
        }

        private void cmbProductoV_SelectedIndexChanged(object sender, EventArgs e)
        {
         
            txtCodigoV.Text = cmbProductoV.SelectedValue.ToString();
        }

        private void frmVentas_Load(object sender, EventArgs e)
        {
          
            DBProductos alum = new DBProductos();
            DataTable datosEsp = alum.ConsultarTodos2();
            cmbProductoV.DataSource = datosEsp;
            cmbProductoV.DisplayMember = "nombre";
            cmbProductoV.ValueMember = "idTipoProducto";
            txtCodigoV.Text = "";
            cmbProductoV.AutoCompleteMode = AutoCompleteMode.Suggest;
            cmbProductoV.AutoCompleteSource = AutoCompleteSource.CustomSource;
            cmbProductoV.AutoCompleteCustomSource = this.cargarDatos();

            DBEmpleados alum2 = new DBEmpleados();
            DataTable datosEsp2 = alum2.ConsultarTodos3();
            cmbEmpleadoV.DataSource = datosEsp2;
            cmbEmpleadoV.DisplayMember = "nombre";
            cmbEmpleadoV.ValueMember = "idEmpleado";
            cmbEmpleadoV.AutoCompleteMode = AutoCompleteMode.Suggest;
            cmbEmpleadoV.AutoCompleteSource = AutoCompleteSource.CustomSource;
            cmbEmpleadoV.AutoCompleteCustomSource = this.cargarDatos2();

            DBTipoPago alum3 = new DBTipoPago();
            DataTable datosEsp3 = alum3.ConsultarTodos4();
            cmbTipoPagoV.DataSource = datosEsp3;
            cmbTipoPagoV.DisplayMember = "descripcion";
            cmbTipoPagoV.ValueMember = "idTipoPago";
            cmbTipoPagoV.AutoCompleteMode = AutoCompleteMode.Suggest;
            cmbTipoPagoV.AutoCompleteSource = AutoCompleteSource.CustomSource;
            cmbTipoPagoV.AutoCompleteCustomSource = this.cargarDatos4();

            DBClientes alum4 = new DBClientes();
            DataTable datosEsp4 = alum4.ConsultarTodos5();
            cmbClienteV.DataSource = datosEsp4;
            cmbClienteV.DisplayMember = "nombre";
            cmbClienteV.ValueMember = "idCliente";
            cmbClienteV.AutoCompleteMode = AutoCompleteMode.Suggest;
            cmbClienteV.AutoCompleteSource = AutoCompleteSource.CustomSource;
            cmbClienteV.AutoCompleteCustomSource = this.cargarDatos3();


        }

        private void btnGuardarV_Click(object sender, EventArgs e)
        {
            Boolean exito = false;
            if (txtFolioVenta.Text.Equals("")) { MessageBox.Show("Faltó Capturar el folio!!", "Ventas ♥"); exito = true; }

            if (txtCodigoV.Text.Equals("")) { MessageBox.Show("Faltó Capturar el codigo!!", "Ventas ♥"); exito = true; }
            if (cmbProductoV.Text.Equals("")) { MessageBox.Show("Faltó Capturar el producto!!", "Ventas ♥"); exito = true; }

            if (txtPrecioCompraV.Text.Equals("")) { MessageBox.Show("Faltó Capturar el precio compra!!", "Ventas ♥"); exito = true; }
            if (txtPrecioVentaV.Text.Equals("")) { MessageBox.Show("Faltó Capturar el precio venta!!", "Ventas ♥"); exito = true; }
            if (txtCantidadV.Text.Equals("")) { MessageBox.Show("Faltó Capturar la cantidad!!", "Ventas ♥"); exito = true; }

            if (exito == false)
            {
                DetalleVenta detalle = new DetalleVenta();

                DBVentas mibase = new DBVentas();
                DetalleVenta deta = new DetalleVenta();

                detalle.PrecioCompra = float.Parse(txtPrecioCompraV.Text);
                detalle.PrecioVenta = float.Parse(txtPrecioVentaV.Text);
                detalle.FolioVen = int.Parse(txtFolioVenta.Text);
                detalle.Codigo = int.Parse(txtCodigoV.Text);
                detalle.Cantidad = int.Parse(txtCantidadV.Text);
                detalle.Producto = cmbProductoV.Text;
               



                 float totalVenta = 0.0f;
                totalVenta = detalle.calcularTotalVentaV();
                 txtTotalVentaV.Text = totalVenta.ToString();
                detalle.TotalVenta = float.Parse(txtTotalVentaV.Text);

                float totalCompra = 0.0f;
               totalCompra = detalle.calcularTotalCompraV();
                txtTotalCompraV.Text = totalCompra.ToString();
                detalle.TotalCompra = float.Parse(txtTotalCompraV.Text);

                float utilidad = 0.0f;
               utilidad = detalle.calcularUtilidadV();
                txtUtilidadV.Text = utilidad.ToString();
                detalle.Utilidad = float.Parse(txtUtilidadV.Text);
                detalle.Utilidad = float.Parse(txtUtilidadV.Text);

                ven.Add(detalle);
                this.calcularUtilidad();
                detalle.TotalVenta = float.Parse(txtTotalVentaV.Text);   
detalle.TotalCompra = float.Parse(txtTotalCompraV.Text);
                detalle.Utilidad = float.Parse(txtUtilidadV.Text);
                dgvListaV.DataSource = null;
                dgvListaV.DataSource = ven;

              //  cmbClienteV.Text = "";
            //    cmbTipoPagoV.Text = "";
               cmbProductoV.Text = "";
              //  cmbEmpleadoV.Text = "";
                txtCodigoV.Text = "";
               // dtpFechaV.Text = "";
                txtPrecioCompraV.Text = "";
                txtPrecioVentaV.Text = "";
                txtCantidadV.Text = "";
               // txtTotalCompraV.Text = "";
              //  txtTotalVentaV.Text = "";
              //  txtUtilidadV.Text = "";

            }
        }
            private void cmbEmpleadoV_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private AutoCompleteStringCollection cargarDatos()
        {
            AutoCompleteStringCollection datos = new AutoCompleteStringCollection();
            DBProductos al = new DBProductos();

            DataTable tproducto = al.ConsultarTodos2();
            string tipoproducto = "";
            for (int i = 0; i < tproducto.Rows.Count; ++i)
            {
                tipoproducto = tproducto.Rows[i]["nombre"].ToString();
                datos.Add(tipoproducto);
            }
            return datos;
        }
        private AutoCompleteStringCollection cargarDatos2()
        {
            AutoCompleteStringCollection datos = new AutoCompleteStringCollection();
            DBEmpleados al = new DBEmpleados();

            DataTable tventas = al.ConsultarTodos3();
            string templeado = "";
            for (int i = 0; i < tventas.Rows.Count; ++i)
            {
                templeado = tventas.Rows[i]["nombre"].ToString();
                datos.Add(templeado);
            }
            return datos;
        }
        private AutoCompleteStringCollection cargarDatos3()
        {
            AutoCompleteStringCollection datos = new AutoCompleteStringCollection();
            DBClientes al = new DBClientes();

            DataTable tventas = al.ConsultarTodos5();
            string tclientes = "";
            for (int i = 0; i < tventas.Rows.Count; ++i)
            {
                tclientes = tventas.Rows[i]["nombre"].ToString();
                datos.Add(tclientes);
            }
            return datos;
        }
        private AutoCompleteStringCollection cargarDatos4()
        {
            AutoCompleteStringCollection datos = new AutoCompleteStringCollection();
            DBTipoPago al = new DBTipoPago();

            DataTable tventas = al.ConsultarTodos4();
            string ttipopago = "";
            for (int i = 0; i < tventas.Rows.Count; ++i)
            {
                ttipopago = tventas.Rows[i]["descripcion"].ToString();
                datos.Add(ttipopago);
            }
            return datos;
        }

        private void btnBuscarV_Click(object sender, EventArgs e)
        {
            DBVentas miBase = new DBVentas();



            if (txtFolioVenta.Text != "")
            {
                DataTable datos = miBase.Consultar(int.Parse(txtFolioVenta.Text));
                DataTable datos2 = miBase.Consultar2(int.Parse(txtFolioVenta.Text));
                if (datos.Rows.Count > 0)
                {




                    DataTable datosEsp2 = miBase.ConsultarTodos3();
                    cmbEmpleadoV.DataSource = datosEsp2;
                    cmbEmpleadoV.DisplayMember = "nombre";
                    cmbEmpleadoV.ValueMember = "idEmpleado";



                    DataTable datosEsp3 = miBase.ConsultarTodos4();
                    cmbTipoPagoV.DataSource = datosEsp3;
                    cmbTipoPagoV.DisplayMember = "descripcion";
                    cmbTipoPagoV.ValueMember = "idTipoPago";


                    
                    DataTable datosEsp4 = miBase.ConsultarTodos5();
                    cmbClienteV.DataSource = datosEsp4;
                    cmbClienteV.DisplayMember = "nombre";
                    cmbClienteV.ValueMember = "idCliente";
                   




                    cmbEmpleadoV.Text = datos.Rows[0]["empleado"].ToString();
                    cmbClienteV.Text = datos.Rows[0]["cliente"].ToString();
                    cmbTipoPagoV.Text = datos.Rows[0]["tipoPago"].ToString();
                    dtpFechaV.Text = datos.Rows[0]["fechaVenta"].ToString();



                    //  DataTable datosEsp = miBase.ConsultarTodosProductos();
                    //     cmbProductoC.DataSource = datosEsp;
                    //     cmbProductoC.DisplayMember = "descripcion";
                    //    cmbProductoC.ValueMember = "idproducto";
                    //  txtCodigoC.Text = datos.Rows[0]["codigo"].ToString();
                    //   txtPrecioCompraC.Text = datos.Rows[0]["precioCompra"].ToString();
                    //   txtCantidadC.Text = datos.Rows[0]["cantidad"].ToString();
                    //   txtTotalCompraC.Text = datos.Rows[0]["totalCompra"].ToString();

                    //cmbEmpleadoC.SelectedValue = datos.Rows[0]["empleado"].ToString();
                    // cmbTiendaC.SelectedValue = datos.Rows[0]["tienda"].ToString();
                    //  cmbTipoPagoC.SelectedValue = datos.Rows[0]["tipoPago"].ToString();
                    //   dtpFechaC.Text = datos.Rows[0]["fechaCompra"].ToString();

                    dgvListaV.DataSource = null;
                    dgvListaV.DataSource = datos2;
                    btnBorrarV.Enabled = false;
                    btnGuardarV.Enabled = false;

                }

                else
                {
                    MessageBox.Show("No hay registro con ese Folio", "Ventas ♥");
                }

            }
            else
            {
                MessageBox.Show("Faltó capturar el Folio", "Ventas ♥");
                txtFolioVenta.Focus();
            }



        }

        private void btnCancelarV_Click(object sender, EventArgs e)
        {
            txtPrecioVentaV.Enabled = false;
            txtFolioVenta.Text = "";
            cmbClienteV.Text = "";
            cmbTipoPagoV.Text = "";
            cmbProductoV.Text = "";
            cmbEmpleadoV.Text = "";
            txtCodigoV.Text = "";
            dtpFechaV.Text = "";
            txtPrecioCompraV.Text = "";
            txtPrecioVentaV.Text = "";
            txtCantidadV.Text = "";
            txtTotalCompraV.Text = "";
            txtTotalVentaV.Text = "";
            txtUtilidadV.Text = "";
            txtFolioVenta.Enabled = false;
            cmbClienteV.Enabled = false;
            cmbTipoPagoV.Enabled = false;
            cmbProductoV.Enabled = false;
            cmbEmpleadoV.Enabled = false;
            txtCodigoV.Enabled = false;
            dtpFechaV.Enabled = false;
            txtPrecioCompraV.Enabled = false;
            txtPrecioVentaV.Enabled = false;
            btnBorrarV.Enabled = false;
            txtCantidadV.Enabled = false;
            btnBuscarV.Enabled = false;
            dgvListaV.DataSource = null;
            btnGuardarV.Enabled = false;
            btnRealizaCompraV.Enabled = false;
        }

        private void btnSalirV_Click(object sender, EventArgs e)
        {
            DialogResult res;
            res = MessageBox.Show("¿Deseas salir?", "Ventas ♥",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
            if (res == DialogResult.Yes) this.Close();
        }

        private void btnLimpiarV_Click(object sender, EventArgs e)
        {
            txtPrecioVentaV.Enabled = false;
            txtFolioVenta.Text = "";
            cmbClienteV.Text = "";
            cmbTipoPagoV.Text = "";
            cmbProductoV.Text = "";
            cmbEmpleadoV.Text = "";
            txtCodigoV.Text = "";
            dtpFechaV.Text = "";
            txtTotalCompraV.Text = "";
            txtTotalVentaV.Text = "";
            txtUtilidadV.Text = "";
            txtPrecioCompraV.Text = "";
            txtPrecioVentaV.Text = "";
            txtCantidadV.Text = "";
            txtFolioVenta.Enabled = true;
            cmbClienteV.Enabled = false;
            cmbTipoPagoV.Enabled = false;
            cmbProductoV.Enabled = false;
            cmbEmpleadoV.Enabled = false;
            txtCodigoV.Enabled = false;
            dtpFechaV.Enabled = false;
            txtPrecioCompraV.Enabled = false;
            txtPrecioVentaV.Enabled = false;
            btnBorrarV.Enabled = false;
            txtCantidadV.Enabled = false;
            dgvListaV.DataSource = null;

            btnGuardarV.Enabled = false;
            btnRealizaCompraV.Enabled = false;
        }

        private void btnRealizaCompraV_Click(object sender, EventArgs e)
        {
            DialogResult res = MessageBox.Show("¿Deseas Realizar la Venta?", "Ventas", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);

            if (res == DialogResult.Yes)
            {
                Boolean exito = false;
                if (txtFolioVenta.Text.Equals("")) { MessageBox.Show("Faltó Capturar el folio!!", "Ventas ♥"); exito = true; }
                if (cmbClienteV.Text.Equals("")) { MessageBox.Show("Faltó Capturar el nombre!!", "Ventas ♥"); exito = true; }
                if (cmbTipoPagoV.Text.Equals("")) { MessageBox.Show("Faltó Capturar el tipo de pago!!", "Ventas ♥"); exito = true; }
                if (dtpFechaV.Text.Equals("")) { MessageBox.Show("Faltó Capturar la fecha de venta!!", "Ventas ♥"); exito = true; }
                if (cmbEmpleadoV.Text.Equals("")) { MessageBox.Show("Faltaron capturar el empleado!!", "Ventas ♥"); exito = true; }


                if (exito == false)
                {
                    DBVentas mibase = new DBVentas();
                    if (txtFolioVenta.Text == txtFolioVenta.Text)
                    {
                        DataTable dataa = mibase.Consultar(int.Parse(txtFolioVenta.Text));
                        if (dataa.Rows.Count > 0)
                        {
                            MessageBox.Show("Ya Existe el Folio", "Ventas ♥");
                        }
                        else
                        {


                            DataTable data = mibase.Consultar(int.Parse(txtFolioVenta.Text));


                            Ventas vent = new Ventas();
                            vent.FolioVenta = int.Parse(txtFolioVenta.Text);
                            vent.Cliente = cmbClienteV.Text;
                            vent.Empleado = cmbEmpleadoV.Text;
                            vent.TipoPago = cmbTipoPagoV.Text;

                            vent.FechaVenta = dtpFechaV.Value.Year + "-" + dtpFechaV.Value.Month + "-" + dtpFechaV.Value.Day;

                            mibase.agregarUsandoParametros(vent);

                            dgvListaV.DataSource = null;
                            dgvListaV.DataSource = ven;



                            foreach (DetalleVenta obj in ven)
                            {
                                mibase.agregarUsandoParametros2(obj);
                            }
                            MessageBox.Show("Se agrego con éxito", "Ventas ♥");

                            //   DetalleCompra detalle = new DetalleCompra();
                            //    detalle.Codigo = int.Parse(txtCodigoC.Text);
                            //   detalle.Producto = cmbProductoC.Text;
                            //   detalle.PrecioCompra = float.Parse(txtPrecioCompraC.Text);
                            //   detalle.PrecioVenta = float.Parse(txtPrecioVentaC.Text);
                            //      detalle.Cantidad = int.Parse(txtCantidadC.Text);
                            //      detalle.TotalCompra = float.Parse(txtTotalCompraC.Text);
                            //      detalle.PrecioVenta = float.Parse(txtPrecioVentaC.Text);
                            //        detalle.Utilidad = float.Parse(txtUtilidadC.Text);

                            //        com.Add(detalle);
                            //        dgvListaC.DataSource = null;
                            //         dgvListaC.DataSource = com;





                            // DataTable datos = mibase.ConsultarTodos();

                            //Pone los datos en la consulta
                            txtFolioVenta.Text = "";
                            cmbClienteV.Text = "";
                            cmbTipoPagoV.Text = "";
                            cmbProductoV.Text = "";
                            cmbEmpleadoV.Text = "";
                            txtCodigoV.Text = "";
                            dtpFechaV.Text = "";
                            txtPrecioCompraV.Text = "";
                            txtPrecioVentaV.Text = "";
                            txtCantidadV.Text = "";
                            txtTotalCompraV.Text = "";
                            txtTotalVentaV.Text = "";
                            txtUtilidadV.Text = "";
                            dgvListaV.DataSource = null;

                        }
                    }
                }
            }
        }

        private void txtFolioVenta_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void txtCodigoV_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void txtPrecioVentaV_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void txtPrecioCompraV_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void txtCantidadV_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }

        }




        private void calcularVenta()
        {
            float totCompra = 0;

            foreach (DetalleVenta item in ven)
            {
                totCompra = totCompra + item.PrecioCompra * item.Cantidad;
            }

            txtTotalVentaV.Text = totCompra.ToString();
        }

        public void calcularUtilidad()
          {
           float totalpreVenta = 0.0f;
           float totalpreCompra = 0.0f;

        foreach (DetalleVenta item in ven)
           {
             totalpreVenta = totalpreVenta + item.PrecioVenta * item.Cantidad;
              totalpreCompra = totalpreCompra + item.PrecioCompra * item.Cantidad;
          }
           txtTotalCompraV.Text = totalpreCompra.ToString();
           txtTotalVentaV.Text = totalpreVenta.ToString();
           txtUtilidadV.Text = (totalpreVenta - totalpreCompra).ToString();
         }

        private void dgvListaV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
