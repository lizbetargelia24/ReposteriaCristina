﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace frmReposteria
{
    class Producto
    {
        protected int idProducto;
        protected string tipoProducto;
        protected string descripcion;
        protected int status;
        protected float precioVenta;
        protected float precioCompra;
        protected string unidadProducto;
        protected string foto;
        protected int clave;


        public Producto()
        {
            idProducto = generaIdProducto();
            clave = generaIdProducto2();
            this.tipoProducto = "";
            this.descripcion = "";
            this.status = 0;
            this.precioVenta = 0.0f;
            this.precioCompra = 0.0f;
            this.unidadProducto = "";
            this.foto = "";
        }
        public Producto(int idProducto, string tipoProducto,
             string descripcion, int status, float precioVenta, 
             float precioCompra, string unidadProducto, string foto, int clave)
        {
            this.idProducto = idProducto;

            this.tipoProducto = tipoProducto;
            this.descripcion = descripcion;
            this.status = status;
            this.precioVenta = precioVenta;
            this.precioCompra = precioCompra;
            this.unidadProducto = unidadProducto;
            this.foto = foto;
            this.clave = clave;
        }
        public int generaIdProducto()
        {
            //genera valores aleatorios enteros positivos no mayores a 32000
            Random x = new Random();
            return x.Next(32000);
        }
        public int generaIdProducto2()
        {
            //genera valores aleatorios enteros positivos no mayores a 32000
            Random x = new Random();
            return x.Next(25000);
        }
        public int Clave
        {
            set { this.clave = value; }
            get { return this.clave; }
        }
        public int IdProducto
        {
            set { this.idProducto = value; }
            get { return this.idProducto; }
        }

        public string TipoProducto
        {
            set { this.tipoProducto = value; }
            get { return this.tipoProducto; }
        }
        public string Descripcion
        {
            set { this.descripcion = value; }
            get { return this.descripcion; }
        }
        public int Status
        {
            set { this.status = value; }
            get { return this.status; }
        }
        public float PrecioVenta
        {
            set { this.precioVenta = value; }
            get { return this.precioVenta; }
        }
        public float PrecioCompra
        {
            set { this.precioCompra = value; }
            get { return this.precioCompra; }
        }
        public string UnidadProducto
        {
            set { this.unidadProducto = value; }
            get { return this.unidadProducto; }
        }
        public string Foto
        {
            set { this.foto = value; }
            get { return this.foto; }
        }
    }
}
