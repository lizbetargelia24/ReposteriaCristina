﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace frmReposteria
{
    class DetalleVenta
    {
       

        private string producto;
        private float precioVenta;
        private float precioCompra;
        private int folioVen;
        private int codigo;
        private float totalVenta;
        private float totalCompra;
        private float utilidad;
        private int cantidad;


        public DetalleVenta()
        {
      
            this.codigo = 0;
       
            this.precioVenta = 0.0f;
            this.precioCompra = 0.0f;
            this.producto = "";
            this.folioVen = 0;
            this.totalVenta = 0.0f;
            this.totalCompra = 0.0f;
            this.utilidad = 0.0f;
            this.cantidad = 0;
        }
        public DetalleVenta( int codigo,  float precioVenta, float precioCompra, string producto, int folioVen,  float totalVenta, float totalCompra, float utilidad, int cantidad)
        {
           
            this.codigo = codigo;
            this.folioVen = folioVen;
            this.precioVenta = precioVenta;
            this.precioCompra = precioCompra;
            this.producto = producto;
            this.totalVenta = totalVenta;
            this.totalCompra = totalCompra;
            this.utilidad = utilidad;
            this.cantidad = cantidad;
        }

      
        public int Codigo
        {
            set { this.codigo = value; }
            get { return this.codigo; }
        }
       
        public float PrecioVenta
        {
            set { this.precioVenta = value; }
            get { return this.precioVenta; }
        }
        public float PrecioCompra
        {
            set { this.precioCompra = value; }
            get { return this.precioCompra; }
        }
        public string Producto
        {
            set { this.producto = value; }
            get { return this.producto; }
        }
        public int FolioVen
        {
            set { this.folioVen = value; }
            get { return this.folioVen; }
        }
        public float TotalVenta
        {
            set { this.totalVenta = value; }
            get { return this.totalVenta; }
        }
        public float TotalCompra
        {
            set { this.totalCompra = value; }
            get { return this.totalCompra; }
        }
        public float Utilidad
        {
            set { this.utilidad = value; }
            get { return this.utilidad; }
        }
        public int Cantidad
        {
            set { this.cantidad= value; }
            get { return this.cantidad; }
        }

        public float calcularTotalVentaV()
        {
            float costo = 0.0f;
            costo = this.PrecioVenta * this.cantidad;
            return costo;
        }
        public float calcularTotalCompraV()
        {
            float costo = 0.0f;
            costo = this.PrecioCompra * this.cantidad;
            return costo;
        }
        public float calcularUtilidadV()
        {
            float utilidad = 0.0f;
            utilidad = (this.precioVenta - this.PrecioCompra) * this.cantidad;
            return utilidad;
        }
    }
}

