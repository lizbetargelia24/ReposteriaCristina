﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;

namespace frmReposteria
{
    class DBVentas
    {
        
            private MySqlConnection conexion;
            private string strConexion;
            private MySqlCommand sqlComando;
            private string strConsulta;
            private MySqlDataAdapter adaptador;

            public DBVentas()
            {
                //Constructor
                conexion = new MySqlConnection();
                strConexion = "Server=localHost;User=root;DataBase=bdreposteria;port=3306;Password=";

                conexion.ConnectionString = strConexion;

                sqlComando = new MySqlCommand();
                adaptador = new MySqlDataAdapter();

            }
            public Boolean abrir()
            {
                Boolean exito = false;

                if (conexion.State == System.Data.ConnectionState.Closed)
                {

                    conexion.Open();
                    exito = true;

                }



                return exito;
            }
            public Boolean Cerrar()
            {
                Boolean exito = false;

                if (conexion.State == System.Data.ConnectionState.Closed)
                {

                    exito = false;
                }
                else
                {
                    conexion.Close();
                    exito = true;
                }
                return exito;
            }
            // public Boolean Cerrar()
            // {
            //    Boolean exito = false;
            //    if (conexion.State == ConnectionState.Closed)
            //    {
            //    conexion.Close();
            //   exito = true;
            // }
            // return exito;
            // }


            //Agregar sin parametros
            // public void agregarSinParsametros(Empleado obj)
            //{
            //    string sqlConsulta = "insert into especialidades (idespecialidades,codigo,nombre,status) values (null," + obj.Clave + "," + obj.Nombre + ",0)";
            //    this.abrir();
            //    sqlComando.Connection = conexion;
            //    sqlComando.CommandText = sqlConsulta;

            //    sqlComando.ExecuteNonQuery();
            //    this.Cerrar();
            //}
            //Agregar usando parametros
            public void agregarUsandoParametros(Ventas obj)
            {
                string sqlConsulta = "insert into tventas (folioVenta,fechaVenta,  empleado, cliente, tipoPago)values(?pfolioVenta, ?pfechaVenta, ?pempleado, ?pcliente, ?ptipoPago)";
                sqlComando.Parameters.Clear();
            sqlComando.Parameters.Add("?pfolioVenta", MySql.Data.MySqlClient.MySqlDbType.Int16).Value = obj.FolioVenta;
            sqlComando.Parameters.Add("?pfechaVenta", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.FechaVenta;
                sqlComando.Parameters.Add("?pempleado", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Empleado;
                sqlComando.Parameters.Add("?pcliente", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Cliente;
                sqlComando.Parameters.Add("?ptipoPago", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.TipoPago;
            //    sqlComando.Parameters.Add("?pcodigo", MySql.Data.MySqlClient.MySqlDbType.Int32).Value = obj.Codigo;
            //    sqlComando.Parameters.Add("?ptipoProducto", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Producto;
             //   sqlComando.Parameters.Add("?pprecioVenta", MySql.Data.MySqlClient.MySqlDbType.Float).Value = obj.PrecioVenta;
           //     sqlComando.Parameters.Add("?pprecioCompra", MySql.Data.MySqlClient.MySqlDbType.Float).Value = obj.PrecioCompra;
         //   sqlComando.Parameters.Add("?ptotalVenta", MySql.Data.MySqlClient.MySqlDbType.Float).Value = obj.TotalVenta;
          //  sqlComando.Parameters.Add("?ptotalCompra", MySql.Data.MySqlClient.MySqlDbType.Float).Value = obj.TotalCompra;
          //  sqlComando.Parameters.Add("?putilidad", MySql.Data.MySqlClient.MySqlDbType.Float).Value = obj.Utilidad;


            this.abrir();
                sqlComando.Connection = conexion;
                sqlComando.CommandText = sqlConsulta;

                sqlComando.ExecuteNonQuery();
                this.Cerrar();

            }
        public void agregarUsandoParametros2(DetalleVenta obj)
        {
            string sqlConsulta = "insert into tdetalleventa (iddetalleventa,codigo, tipoProducto, precioVenta, precioCompra,folioVen, totalVenta, totalCompra, utilidad, cantidad)values(null,?pcodigo, ?ptipoProducto, ?pprecioVenta, ?pprecioCompra,?pfolioVen, ?ptotalVenta,?ptotalCompra, ?putilidad, ?pcantidad)";
            sqlComando.Parameters.Clear();
          
               sqlComando.Parameters.Add("?pcodigo", MySql.Data.MySqlClient.MySqlDbType.Int32).Value = obj.Codigo;
               sqlComando.Parameters.Add("?ptipoProducto", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Producto;
              sqlComando.Parameters.Add("?pprecioVenta", MySql.Data.MySqlClient.MySqlDbType.Float).Value = obj.PrecioVenta;
              sqlComando.Parameters.Add("?pprecioCompra", MySql.Data.MySqlClient.MySqlDbType.Float).Value = obj.PrecioCompra;
            sqlComando.Parameters.Add("?pfolioVen", MySql.Data.MySqlClient.MySqlDbType.Int32).Value = obj.FolioVen;
            sqlComando.Parameters.Add("?ptotalVenta", MySql.Data.MySqlClient.MySqlDbType.Float).Value = obj.TotalVenta;
             sqlComando.Parameters.Add("?ptotalCompra", MySql.Data.MySqlClient.MySqlDbType.Float).Value = obj.TotalCompra;
             sqlComando.Parameters.Add("?putilidad", MySql.Data.MySqlClient.MySqlDbType.Float).Value = obj.Utilidad;
            sqlComando.Parameters.Add("?pcantidad", MySql.Data.MySqlClient.MySqlDbType.Int24).Value = obj.Cantidad;

            this.abrir();
            sqlComando.Connection = conexion;
            sqlComando.CommandText = sqlConsulta;

            sqlComando.ExecuteNonQuery();
            this.Cerrar();

        }
        //Actualizar
        public void Actualizar(Ventas obj)
            {
                string sqlConsulta = "Update tventas set fechaVenta = ?pfechaVenta , empleado = ?pempleado, cliente = ?pcliente, tipoPago = ?ptipoPago where folioVenta = ?pfolioVenta";
                sqlComando.Parameters.Clear();

            sqlComando.Parameters.Add("?pfechaVenta", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.FechaVenta;
            sqlComando.Parameters.Add("?pempleado", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Empleado;
            sqlComando.Parameters.Add("?pcliente", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Cliente;
            sqlComando.Parameters.Add("?ptipoPago", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.TipoPago;
          //  sqlComando.Parameters.Add("?pcodigo", MySql.Data.MySqlClient.MySqlDbType.Int32).Value = obj.Codigo;
          //  sqlComando.Parameters.Add("?ptipoProducto", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Producto;
        //    sqlComando.Parameters.Add("?pprecioVenta", MySql.Data.MySqlClient.MySqlDbType.Float).Value = obj.PrecioVenta;
          //  sqlComando.Parameters.Add("?pprecioCompra", MySql.Data.MySqlClient.MySqlDbType.Float).Value = obj.PrecioCompra;
          //  sqlComando.Parameters.Add("?putilidad", MySql.Data.MySqlClient.MySqlDbType.Float).Value = obj.Utilidad;


            this.abrir();
                sqlComando.Connection = conexion;
                sqlComando.CommandText = sqlConsulta;

                sqlComando.ExecuteNonQuery();
                this.Cerrar();
            }
        public void Actualizar2(DetalleVenta obj)
        {
            string sqlConsulta = "Update tdetalleventa set codigo = ?pcodigo , tipoProducto = ?ptipoProducto, precioVenta = ?pprecioVenta, precioCompra = ?pprecioCompra, utilidad = ?putilidad, cantidd = ?pcantidad ";
            sqlComando.Parameters.Clear();

            sqlComando.Parameters.Add("?pcodigo", MySql.Data.MySqlClient.MySqlDbType.Int32).Value = obj.Codigo;
            sqlComando.Parameters.Add("?ptipoProducto", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Producto;
            sqlComando.Parameters.Add("?pprecioVenta", MySql.Data.MySqlClient.MySqlDbType.Float).Value = obj.PrecioVenta;
            sqlComando.Parameters.Add("?pprecioCompra", MySql.Data.MySqlClient.MySqlDbType.Float).Value = obj.PrecioCompra;
            sqlComando.Parameters.Add("?putilidad", MySql.Data.MySqlClient.MySqlDbType.Float).Value = obj.Utilidad;
            sqlComando.Parameters.Add("?pcantidad", MySql.Data.MySqlClient.MySqlDbType.Int24).Value = obj.Cantidad;


            this.abrir();
            sqlComando.Connection = conexion;
            sqlComando.CommandText = sqlConsulta;

            sqlComando.ExecuteNonQuery();
            this.Cerrar();
        }
        //Deshabilitar
      
            //Consultar
            public DataTable Consultar(int FolioVenta)
            {
                DataTable datos = new DataTable();
                strConsulta = "select * from tventas where folioVenta =" + FolioVenta;

                this.abrir();
                sqlComando.CommandText = strConsulta;
                sqlComando.Connection = conexion;
                adaptador.SelectCommand = sqlComando;
                adaptador.Fill(datos);

                this.Cerrar();

                return datos;
            }
        public DataTable Consultar2(int FolioVen)
        {
            DataTable datos = new DataTable();
            strConsulta = "select * from tdetalleventa where folioVen =" + FolioVen;

            this.abrir();
            sqlComando.CommandText = strConsulta;
            sqlComando.Connection = conexion;
            adaptador.SelectCommand = sqlComando;
            adaptador.Fill(datos);

            this.Cerrar();

            return datos;
        }
        //Metodo consultar todos
        public DataTable ConsultarTodos()
            {
                DataTable datos = new DataTable();
                strConsulta = "select *from tventas order by folioVenta asc";
                abrir();
                sqlComando.CommandText = strConsulta;
                sqlComando.Connection = conexion;

                adaptador.SelectCommand = sqlComando;
                adaptador.Fill(datos);
                Cerrar();
                return datos;
            }
        public DataTable ConsultarTodos2()
        {
            DataTable datos = new DataTable();
            strConsulta = "select *from tdetalleventa order by codigo asc";
            abrir();
            sqlComando.CommandText = strConsulta;
            sqlComando.Connection = conexion;

            adaptador.SelectCommand = sqlComando;
            adaptador.Fill(datos);
            Cerrar();
            return datos;
        }
       



        public DataTable ConsultarTodos3()
        {
            DataTable datos = new DataTable();
            strConsulta = "select *from templeado where status = 0 order by clave asc";
            abrir();
            sqlComando.CommandText = strConsulta;
            sqlComando.Connection = conexion;

            adaptador.SelectCommand = sqlComando;
            adaptador.Fill(datos);
            Cerrar();
            return datos;
        }
        public DataTable ConsultarTodos4()
        {
            DataTable datos = new DataTable();
            strConsulta = "select *from ttipopago where status = 0 order by clave asc";
            abrir();
            sqlComando.CommandText = strConsulta;
            sqlComando.Connection = conexion;

            adaptador.SelectCommand = sqlComando;
            adaptador.Fill(datos);
            Cerrar();
            return datos;
        }
        public DataTable ConsultarTodos5()
        {
            DataTable datos = new DataTable();
            strConsulta = "select *from tclientes where status = 0 order by clave asc";
            abrir();
            sqlComando.CommandText = strConsulta;
            sqlComando.Connection = conexion;

            adaptador.SelectCommand = sqlComando;
            adaptador.Fill(datos);
            Cerrar();
            return datos;
        }

        public DataTable ConsultarTodosProductos()
        {
            DataTable datos2 = new DataTable();
            strConsulta = "select *from tproducto where status = 0 order by clave asc";
            abrir();
            sqlComando.CommandText = strConsulta;
            sqlComando.Connection = conexion;

            adaptador.SelectCommand = sqlComando;
            adaptador.Fill(datos2);
            Cerrar();
            return datos2;
        }
    }
}
