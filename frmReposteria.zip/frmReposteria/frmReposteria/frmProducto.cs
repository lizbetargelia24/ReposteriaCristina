﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
namespace frmReposteria
{
    public partial class frmProducto : Form
    {
        public frmProducto()
        {
            InitializeComponent();
        }


        private void btnBuscar_Click(object sender, EventArgs e)
        {


        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {

        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {


        }

        private void btnModificar_Click(object sender, EventArgs e)
        {

        }

        private void btnBorrar_Click(object sender, EventArgs e)
        {

        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {


        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {

        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {

        }

        private void btnBuscarH_Click(object sender, EventArgs e)
        {


        }

        private void btnNuevoH_Click(object sender, EventArgs e)
        {

        }

        private void btnGuardarH_Click(object sender, EventArgs e)
        {


        }

        private void btnModificarH_Click(object sender, EventArgs e)
        {



        }

        private void btnBorrarH_Click(object sender, EventArgs e)
        {

        }

        private void btnLimpiarH_Click(object sender, EventArgs e)
        {

        }

        private void btnCancelarH_Click(object sender, EventArgs e)
        {

        }

        private void btnnCerrarH_Click(object sender, EventArgs e)
        {

        }

        private void txtIdProducto_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void cmbStatus_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txtPrecio_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void cmbStatus_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void cmbUniPro_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void txtIdProductoH_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void cmbStatusH_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void txtPrecioH_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void cmbUniProH_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void txtTipoPH_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void cmbTipoPH_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void btnFotoP_Click(object sender, EventArgs e)
        {

        }

        private void cmbStatusTP_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void btnNuevo_Click_1(object sender, EventArgs e)
        {

        }

        private void btnGuardar_Click_1(object sender, EventArgs e)
        {


        }

        private void btnModificar_Click_1(object sender, EventArgs e)
        {
        }

        private void btnCerrar_Click_1(object sender, EventArgs e)
        {
        }

        private void btnCancelar_Click_1(object sender, EventArgs e)
        {

        }

        private void btnLimpiar_Click_1(object sender, EventArgs e)
        {

        }

        private void btnBuscar_Click_1(object sender, EventArgs e)
        {

        }

        private void btnBorrar_Click_1(object sender, EventArgs e)
        {

        }

        private void btnFotoP_Click_1(object sender, EventArgs e)
        {

        }

        private void txtClave_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void cmbUniPro_KeyPress_1(object sender, KeyPressEventArgs e)
        {

        }

        private void txtPrecio_KeyPress_1(object sender, KeyPressEventArgs e)
        {

        }

        private void frmProducto_Load(object sender, EventArgs e)
        {

            DBProductos alum = new DBProductos();
            DataTable datosss = alum.mostrartiposProdu();
            dgvLista.DataSource = datosss;

            DataTable datosEsp = alum.ConsultarTodos2();
            cmbTipoProducto.DataSource = datosEsp;
            cmbTipoProducto.DisplayMember = "nombre";
            cmbTipoProducto.ValueMember = "idTipoProducto";
            lblId.Text = "";

            DBProductos miBasee = new DBProductos();
           //Limpiar el DtaGriView
            dgvLista.DataSource = null;
            DataTable datoss = miBasee.ConsultarTodos();
            dgvLista.DataSource = datoss;
            //Poner Los Datos de Consulta en el DataGriView 

              DBProductos miBase = new DBProductos();
             dgvListaP.DataSource = null;
              DataTable datos = miBase.ConsultarTodosDeshabilitar();
             dgvListaP.DataSource = datos;

             cmbTipoProducto.AutoCompleteMode = AutoCompleteMode.Suggest;
             cmbTipoProducto.AutoCompleteSource = AutoCompleteSource.CustomSource;
             cmbTipoProducto.AutoCompleteCustomSource = this.cargarDatos();


        }
       

        private void btnNuevo_Click_2(object sender, EventArgs e)
        {
            btnGuardar.Enabled = true;
            btnBuscar.Enabled = true;


            txtClave.Enabled = true;
            cmbTipoProducto.Enabled = true;
            txtDescripcion.Enabled = true;
            cmbUniPro.Enabled = true;
         
            btnFotoP.Enabled = true;
            txtPrecioCompra.Enabled = true;
            txtPrecioVenta.Enabled = true;
            cmbUniPro.Enabled = true;

        }

        private void btnGuardar_Click_2(object sender, EventArgs e)
        {
            Boolean exito = false;


            if (txtClave.Text.Equals("")) { MessageBox.Show("Faltó Capturar la Clave del Producto!!", "Producto ♥"); exito = true; }

            if (cmbTipoProducto.Text.Equals("")) { MessageBox.Show("Faltó Capturar el TipoProducto!!", "Producto ♥"); exito = true; }
            if (txtDescripcion.Text.Equals("")) { MessageBox.Show("Faltó Capturar La Descripcion!!", "Producto ♥"); exito = true; }
            if (cmbUniPro.Text.Equals("")) { MessageBox.Show("Faltó Capturar La Unidad Del Producto!!", "Producto ♥"); exito = true; }
            if (txtPrecioVenta.Text.Equals("")) { MessageBox.Show("Faltó Capturar el precio de venta!!", "Producto ♥"); exito = true; }
            if (txtPrecioCompra.Text.Equals("")) { MessageBox.Show("Faltó Capturar el precio de compra!!", "Producto ♥"); exito = true; }
            if (txtFotoP.Text.Equals("")) { MessageBox.Show("Faltó Capturar La Foto!!", "Producto ♥"); exito = true; }

            if (exito == false)
            {
                DBProductos miBase = new DBProductos();
                if (txtClave.Text == txtClave.Text)
                {
                    DataTable data = miBase.Consultar(int.Parse(txtClave.Text));
                    if (data.Rows.Count > 0)
                    {
                        MessageBox.Show("Ya Existe la Clave", "Producto ♥");
                    }
                    else
                    {
                        Producto es = new Producto();
                        es.Clave = int.Parse(txtClave.Text);
                        es.TipoProducto = cmbTipoProducto.Text;
                        es.Descripcion = txtDescripcion.Text;
                        es.UnidadProducto = cmbUniPro.Text;
                        es.Foto = txtFotoP.Text;
                        es.PrecioVenta = int.Parse(txtPrecioVenta.Text);
                        es.PrecioCompra = int.Parse(txtPrecioCompra.Text);
                        ptbFotoP.Image = Image.FromFile(txtFotoP.Text);
                        

                        miBase.agregarUsandoParametros(es);
                        MessageBox.Show("Se Agregó con Éxito", "Producto ♥");
                        //limppia el dato griview dgv 
                        dgvLista.DataSource = null;

                        DataTable datos = miBase.ConsultarTodos();
                        //Pone todos los datos de connsulta en el dgv
                        dgvLista.DataSource = datos;
                        txtClave.Text = "";
                        cmbTipoProducto.Text = "";
                        txtStatus.Text = "";
                        txtDescripcion.Text = "";
                        txtPrecioVenta.Text = "";
                        txtPrecioCompra.Text = "";
                        cmbUniPro.Text = "";
                        txtFotoP.Text = "";
                        ptbFotoP.Image = frmReposteria.Properties.Resources.imagen5;
                        lblId.Text = "";
                    }

                }
                else
                {
                    MessageBox.Show("Faltó Capturar la Clave", "Producto ♥");
                    txtClave.Focus();
                }

            }

        }

        private void btnModificar_Click_2(object sender, EventArgs e)
        {
            DBProductos mibase = new DBProductos();

            Producto doc = new Producto();

            txtClave.Enabled = false;


            doc.Clave = int.Parse(txtClave.Text);
            doc.TipoProducto = cmbTipoProducto.Text;
            doc.Descripcion = txtDescripcion.Text;
            doc.UnidadProducto = cmbUniPro.Text;
            doc.Status = int.Parse(txtStatus.Text);
            doc.Foto = txtFotoP.Text;
            doc.PrecioVenta = float.Parse(txtPrecioVenta.Text);
            doc.PrecioCompra = float.Parse(txtPrecioCompra.Text);

            mibase.Actualizar(doc);
            dgvLista.DataSource = null;
            DataTable datos = mibase.ConsultarTodos();
            dgvLista.DataSource = datos;


            MessageBox.Show("Se ralizó la Modificación con éxito", "Producto ♥");

        }

        private void btnBorrar_Click_2(object sender, EventArgs e)
        {
            DialogResult res = MessageBox.Show("¿Deseas borrar el registro?", "Producto ♥",
        MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);

            if (res == DialogResult.Yes)
            {
                DBProductos mibase = new DBProductos();

                Producto docc = new Producto();

                docc.Clave = int.Parse(txtClave.Text);
                docc.TipoProducto = cmbTipoProducto.Text;
               docc.Descripcion = txtDescripcion.Text;
               docc.UnidadProducto = cmbUniPro.Text;

                mibase.Deshabilitar(docc);
                txtPrecioVenta.Text = "";
                txtPrecioCompra.Text = "";
                txtClave.Text = "";
                cmbTipoProducto.Text = "";
                txtStatus.Text = "";
                txtDescripcion.Text = "";
                cmbUniPro.Text = "";
                txtFotoP.Text = "";
                txtPrecioCompra.Enabled = false;
                txtPrecioVenta.Enabled = false;
                cmbTipoProducto.Enabled = false;
                cmbUniPro.Enabled = false;
                txtFotoP.Enabled = false;
                txtDescripcion.Enabled = false;

                ptbFotoP.Image = frmReposteria.Properties.Resources.imagen5;
                DBProductos miBase = new DBProductos();
                //Limpiar el DtaGriView
                dgvLista.DataSource = null;
                DataTable datos = miBase.ConsultarTodos();
                //Poner Los Datos de Consulta en el DataGriView 
                dgvLista.DataSource = datos;

                DBProductos miBasee = new DBProductos();
                //Limpiar el DtaGriView
                dgvListaP.DataSource = null;
                DataTable datoss = miBasee.ConsultarTodosDeshabilitar();
                //Poner Los Datos de Consulta en el DataGriView 

                dgvListaP.DataSource = datoss;
            }

        }

        private void btnFotoP_Click_2(object sender, EventArgs e)
        {
            OpenFileDialog foto = new OpenFileDialog();
            foto.InitialDirectory = "C:\\";
            foto.ShowDialog();
            txtFotoP.Text = foto.FileName;
            ptbFotoP.ImageLocation = foto.FileName;

        }

        private void btnBuscar_Click_2(object sender, EventArgs e)
        {
            DBProductos miBase = new DBProductos();

            if (txtClave.Text != "")
            {
                DataTable datos = miBase.Consultar(int.Parse(txtClave.Text));
                if (datos.Rows.Count > 0)
                {
                     cmbTipoProducto.Text = datos.Rows[0]["tipoproducto"].ToString();
                    txtDescripcion.Text = datos.Rows[0]["descripcion"].ToString();
                    txtStatus.Text = datos.Rows[0]["status"].ToString();
                    cmbUniPro.Text = datos.Rows[0]["unidadProducto"].ToString();
                    txtPrecioVenta.Text = datos.Rows[0]["precioVenta"].ToString();
                    txtPrecioCompra.Text = datos.Rows[0]["precioCompra"].ToString();
                    txtFotoP.Text = datos.Rows[0]["foto"].ToString();

                    ptbFotoP.Image = Image.FromFile(txtFotoP.Text);


                    txtClave.Enabled = false;
                    cmbTipoProducto.Enabled = true;
                    txtDescripcion.Enabled = true;
                    txtPrecioVenta.Enabled = true;
                    txtPrecioCompra.Enabled = true;
                    cmbUniPro.Enabled = true;
                    btnBorrar.Enabled = true;
                    btnModificar.Enabled = true;
                }
                else
                {
                    MessageBox.Show("No hay registro con esa Clave", "Producto ♥");
                }

            }

            else
            {
                MessageBox.Show("Faltó capturar la Clave", "Producto ♥");
                txtClave.Focus();
            }

        }

        private void btnLimpiar_Click_2(object sender, EventArgs e)
        {
            txtClave.Text = "";
            cmbTipoProducto.Text = "";
            txtStatus.Text = "";
            txtDescripcion.Text = "";
            txtPrecioVenta.Text = "";
            txtPrecioCompra.Text = "";
            cmbUniPro.Text = "";
            txtFotoP.Text = "";
            ptbFotoP.Image = frmReposteria.Properties.Resources.imagen5;
             lblId.Text = "";
            txtClave.Enabled = true;
            cmbTipoProducto.Enabled = false;
            txtDescripcion.Enabled = false;
            cmbUniPro.Enabled = false;
            txtPrecioVenta.Enabled = false;
            txtPrecioCompra.Enabled = false;
            btnBorrar.Enabled = false;
            btnModificar.Enabled = false;
          
        }

        private void btnCancelar_Click_2(object sender, EventArgs e)
        {
            txtClave.Text = "";
            cmbTipoProducto.Text = "";
            txtStatus.Text = "";
            txtDescripcion.Text = "";
            txtPrecioVenta.Text = "";
            txtPrecioCompra.Text = "";
            cmbUniPro.Text = "";
            txtFotoP.Text = "";
            ptbFotoP.Image = frmReposteria.Properties.Resources.imagen5;

            txtClave.Enabled = false;
            cmbTipoProducto.Enabled = false;
            txtDescripcion.Enabled = false;
            cmbUniPro.Enabled = false;
            txtPrecioVenta.Enabled = false;
            txtPrecioCompra.Enabled = false;
            btnBorrar.Enabled = false;
            btnModificar.Enabled = false;

        }

        private void btnCerrar_Click_2(object sender, EventArgs e)
        {
            DialogResult res;
            res = MessageBox.Show("¿Deseas salir?", "Producto ♥", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
            if (res == DialogResult.Yes) this.Close();

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {
           

        }

        private void cmbUniPro_KeyPress_2(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }

        }

        private void txtPrecio_KeyPress_2(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }

        }

        private void txtClave_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }

        }

        private void btnBuscarP_Click(object sender, EventArgs e)
        {
            DBProductos miBase = new DBProductos();

            if (txtClaveP.Text != "")
            {
                DataTable datos = miBase.ConsultarH(int.Parse(txtClaveP.Text));
                if (datos.Rows.Count > 0)
                {
                    cmbTipoProductoP.Text = datos.Rows[0]["tipoproducto"].ToString();
                    txtDescripcionP.Text = datos.Rows[0]["descripcion"].ToString();
                    txtStatusP.Text = datos.Rows[0]["status"].ToString();
                    cmbUniProP.Text = datos.Rows[0]["unidadProducto"].ToString();
                    txtPrecioVentaPro.Text = datos.Rows[0]["precioVenta"].ToString();
                    txtPrecioCompraPro.Text = datos.Rows[0]["precioCompra"].ToString();
                    txtFotoPro.Text = datos.Rows[0]["foto"].ToString();

                    ptbFotoPro.Image = Image.FromFile(txtFotoPro.Text);


                    txtClaveP.Enabled = false;
                   
                   
                }
                else
                {
                    MessageBox.Show("No hay registro con esa Clave", "Producto ♥");
                }

            }

            else
            {
                MessageBox.Show("Faltó capturar la Clave", "Producto ♥");
                txtClaveP.Focus();
            }
        }

        private void btnLimpiarP_Click(object sender, EventArgs e)
        {
            txtClaveP.Text = "";
            cmbTipoProductoP.Text = "";
            txtStatusP.Text = "";
            txtDescripcionP.Text = "";
            txtPrecioVenta.Text = "";
            txtPrecioCompra.Text = "";
            cmbUniProP.Text = "";
            txtFotoPro.Text = "";
            ptbFotoPro.Image = frmReposteria.Properties.Resources.imagen5;

            txtClaveP.Enabled = true;
            cmbTipoProductoP.Enabled = false;
            txtDescripcionP.Enabled = false;
            cmbUniProP.Enabled = false;
            txtPrecioVenta.Enabled = false;
            txtPrecioCompra.Enabled = false;
        }

        private void btnCancelarP_Click(object sender, EventArgs e)
        {
            txtClaveP.Text = "";
           cmbTipoProductoP.Text = "";
            txtStatusP.Text = "";
            txtDescripcionP.Text = "";
            txtPrecioVenta.Text = "";
            txtPrecioCompra.Text = "";
            cmbUniProP.Text = "";
            txtFotoPro.Text = "";
            ptbFotoPro.Image = frmReposteria.Properties.Resources.imagen5;

            txtClaveP.Enabled =false;
            cmbTipoProductoP.Enabled = false;
            txtDescripcionP.Enabled = false;
            cmbUniProP.Enabled = false;
            txtPrecioVenta.Enabled = false;
            txtPrecioCompra.Enabled = false;
        }

        private void btnSalirP_Click(object sender, EventArgs e)
        {
            DialogResult res;
            res = MessageBox.Show("¿Deseas salir?", "Producto ♥", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
            if (res == DialogResult.Yes) this.Close();
        }

        private void btnHabilitarEm_Click(object sender, EventArgs e)
        {
            DBProductos mibase = new DBProductos();

            Producto docc = new Producto();

            docc.Clave = int.Parse(txtClaveP.Text);
            docc.TipoProducto = cmbTipoProductoP.Text;
            docc.Descripcion = txtDescripcionP.Text;
            docc.UnidadProducto = cmbUniProP.Text;

            mibase.Habilitar(docc);
            txtPrecioVentaPro.Text = "";
            txtPrecioCompraPro.Text = "";
            txtClaveP.Text = "";
            cmbTipoProductoP.Text = "";
            txtStatusP.Text = "";
            txtDescripcionP.Text = "";
            cmbUniProP.Text = "";
            txtFotoPro.Text = "";
            ptbFotoPro.Image = frmReposteria.Properties.Resources.imagen5;
            txtPrecioVentaPro.Enabled = false;
            txtPrecioCompraPro.Enabled = false;
            cmbTipoProductoP.Enabled = false;
            cmbUniProP.Enabled = false;
            txtFotoPro.Enabled = false;
            txtDescripcionP.Enabled = false;

            DBProductos miBase = new DBProductos();
            //Limpiar el DtaGriView
            dgvLista.DataSource = null;
            DataTable datos = miBase.ConsultarTodos();
            //Poner Los Datos de Consulta en el DataGriView 
            dgvLista.DataSource = datos;

            DBProductos miBasee = new DBProductos();
            //Limpiar el DtaGriView
            dgvListaP.DataSource = null;
            DataTable datoss = miBasee.ConsultarTodosDeshabilitar();
            //Poner Los Datos de Consulta en el DataGriView 

            dgvListaP.DataSource = datoss;

        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void btnNuevoP_Click(object sender, EventArgs e)
        {
            txtClaveP.Enabled = true;
        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void cmbTipoProducto_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblId.Text = cmbTipoProducto.SelectedValue.ToString();
        }
        private AutoCompleteStringCollection cargarDatos()
        {
            AutoCompleteStringCollection datos = new AutoCompleteStringCollection();
            DBProductos al = new DBProductos();

            DataTable tproducto = al.ConsultarTodos2();
            string tipoproducto = "";
            for (int i = 0; i < tproducto.Rows.Count; ++i)
            {
                tipoproducto = tproducto.Rows[i]["nombre"].ToString();
                datos.Add(tipoproducto);
            }
            return datos;
        }

        private void txtPrecioCompra_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void dgvLista_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void cmbTipoProductoP_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lblId_Click(object sender, EventArgs e)
        {

        }
    }
}
