﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace frmReposteria
{
    class Clientes
    {
        protected int idCliente;
        protected string nombre;
        protected string curp;
        protected string correo;
        protected string telefono;
        protected string apellidoMaterno;
        protected string apellidoPaterno;
        protected string colonia;
        protected string calle;
        protected int numero;
        protected int cp;
        protected int statusC;
        protected string foto;
        protected int clave;

        //constructores
        public Clientes()
        {
            //constructor por omision
            idCliente = this.generaCliente();
            this.nombre = "";
            this.curp = "";
            this.correo = "";
            this.telefono = "";
            this.apellidoMaterno = "";
            this.apellidoPaterno = "";
            this.colonia = "";
            this.calle = "";
            this.numero = 0;
            this.cp = 0;
            this.statusC = 0;
            this.foto = "";
            clave = this.generaCliente2();



        }
        public Clientes(int idCliente, string nombre, string curp, string correo, string telefono, string apellidoMaterno, string apellidoPaterno, string colonia, string calle, int numero, int cp, int statusC, string foto, int clave)
        {
            //constructor por argumentos
            this.idCliente = idCliente;
            this.nombre = nombre;
            this.curp = curp;
            this.correo = correo;
            this.telefono = telefono;
            this.apellidoMaterno = apellidoMaterno;
            this.apellidoPaterno = apellidoPaterno;
            this.colonia = colonia;
            this.calle = calle;
            this.numero = numero;
            this.cp = cp;
            this.statusC = statusC;
            this.foto = foto;
            this.clave = clave;
        }
        public Clientes(Clientes x)
        {
            //constructor por copia
            this.idCliente = x.idCliente;
            this.nombre = x.nombre;
            this.curp = x.curp;
            this.correo = x.correo;
            this.telefono = x.telefono;
            this.apellidoMaterno = x.apellidoMaterno;
            this.apellidoPaterno = x.apellidoPaterno;
            this.colonia = x.colonia;
            this.calle = x.calle;
            this.numero = x.numero;
            this.cp = x.cp;
            this.statusC = x.statusC;
            this.foto = x.foto;
            this.clave = x.clave;
        }
        //metodos de propiedades
        public int  Clave
        {
            set { this.clave = value; }
            get { return this.clave; }
        }

        public int IdCliente
        {
            set { this.idCliente = value; }
            get { return this.idCliente; }
        }

        public string Nombre
        {
            set { this.nombre = value; }
            get { return this.nombre; }
        }
        public string ApellidoMaterno

        {
            set { this.apellidoMaterno = value; }
            get { return this.apellidoMaterno; }

        }

        public string ApellidoPaterno
        {
            set { this.apellidoPaterno = value; }
            get { return this.apellidoPaterno; }
        }

        public string Curp
        {
            set { this.curp = value; }
            get { return this.curp; }
        }

        public string Correo
        {
            set { this.correo = value; }
            get { return this.correo; }
        }

        public string Telefono
        {
            set { this.telefono = value; }
            get { return this.telefono; }
        }

        

        public string Colonia
        {
            set { this.colonia = value; }
            get { return this.colonia; }
        }

        public string Calle
        {
            set { this.calle = value; }
            get { return this.calle; }
        }

        public int Numero
        {
            set { this.numero = value; }
            get { return this.numero; }
        }

        public int Cp
        {
            set { this.cp = value; }
            get { return this.cp; }
        }

        public int StatusC
        {
            set { this.statusC = value; }
            get { return this.statusC; }
        }
        public string Foto
        {
            set { this.foto = value; }
            get { return this.foto; }
        }
        public int generaCliente()
        {
            //genera valores aleatorios enteros positivos no mayores a 32000
            Random x = new Random();
            return x.Next(32000);
        }
        public int generaCliente2()
        {
            //genera valores aleatorios enteros positivos no mayores a 32000
            Random x = new Random();
            return x.Next(25000);
        }
    }
}
