﻿namespace frmReposteria
{
    partial class frmTienda
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label4 = new System.Windows.Forms.Label();
            this.txtClaveT = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtNombreT = new System.Windows.Forms.TextBox();
            this.btnSalirT = new System.Windows.Forms.Button();
            this.btnCancelarT = new System.Windows.Forms.Button();
            this.btnLimpiarT = new System.Windows.Forms.Button();
            this.btnBorrarT = new System.Windows.Forms.Button();
            this.btnModificarT = new System.Windows.Forms.Button();
            this.btnGuardarT = new System.Windows.Forms.Button();
            this.btnNuevoT = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.dgvListaT = new System.Windows.Forms.DataGridView();
            this.cmbStatusT = new System.Windows.Forms.TextBox();
            this.btnBuscarT = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnHabilitarTG = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtClaveTGG = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtNombreTGG = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.dgvListaTG = new System.Windows.Forms.DataGridView();
            this.txtStatusTGG = new System.Windows.Forms.TextBox();
            this.btnSalirTG = new System.Windows.Forms.Button();
            this.btnCancelarTG = new System.Windows.Forms.Button();
            this.btnLimpiarTG = new System.Windows.Forms.Button();
            this.btnNuevoTG = new System.Windows.Forms.Button();
            this.btnBuscarTG = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaT)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaTG)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(6, 14);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(451, 397);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.txtClaveT);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.txtNombreT);
            this.tabPage1.Controls.Add(this.btnSalirT);
            this.tabPage1.Controls.Add(this.btnCancelarT);
            this.tabPage1.Controls.Add(this.btnLimpiarT);
            this.tabPage1.Controls.Add(this.btnBorrarT);
            this.tabPage1.Controls.Add(this.btnModificarT);
            this.tabPage1.Controls.Add(this.btnGuardarT);
            this.tabPage1.Controls.Add(this.btnNuevoT);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.dgvListaT);
            this.tabPage1.Controls.Add(this.cmbStatusT);
            this.tabPage1.Controls.Add(this.btnBuscarT);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(443, 371);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Tienda";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label4.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(17, 117);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(43, 16);
            this.label4.TabIndex = 39;
            this.label4.Text = "Status";
            // 
            // txtClaveT
            // 
            this.txtClaveT.Enabled = false;
            this.txtClaveT.Location = new System.Drawing.Point(18, 33);
            this.txtClaveT.MaxLength = 8;
            this.txtClaveT.Name = "txtClaveT";
            this.txtClaveT.Size = new System.Drawing.Size(116, 20);
            this.txtClaveT.TabIndex = 1;
            this.txtClaveT.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtClaveT_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label3.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(14, 11);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 16);
            this.label3.TabIndex = 38;
            this.label3.Text = "Clave";
            // 
            // txtNombreT
            // 
            this.txtNombreT.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtNombreT.Enabled = false;
            this.txtNombreT.Location = new System.Drawing.Point(18, 84);
            this.txtNombreT.MaxLength = 25;
            this.txtNombreT.Name = "txtNombreT";
            this.txtNombreT.Size = new System.Drawing.Size(116, 20);
            this.txtNombreT.TabIndex = 2;
            // 
            // btnSalirT
            // 
            this.btnSalirT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnSalirT.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSalirT.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalirT.Image = global::frmReposteria.Properties.Resources.salir_3;
            this.btnSalirT.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSalirT.Location = new System.Drawing.Point(209, 218);
            this.btnSalirT.Name = "btnSalirT";
            this.btnSalirT.Size = new System.Drawing.Size(70, 37);
            this.btnSalirT.TabIndex = 35;
            this.btnSalirT.Text = "Salir";
            this.btnSalirT.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSalirT.UseVisualStyleBackColor = false;
            this.btnSalirT.Click += new System.EventHandler(this.btnSalirT_Click);
            // 
            // btnCancelarT
            // 
            this.btnCancelarT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnCancelarT.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCancelarT.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelarT.Image = global::frmReposteria.Properties.Resources.prohibido__1_;
            this.btnCancelarT.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCancelarT.Location = new System.Drawing.Point(111, 218);
            this.btnCancelarT.Name = "btnCancelarT";
            this.btnCancelarT.Size = new System.Drawing.Size(91, 37);
            this.btnCancelarT.TabIndex = 34;
            this.btnCancelarT.Text = "Cancelar";
            this.btnCancelarT.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCancelarT.UseVisualStyleBackColor = false;
            this.btnCancelarT.Click += new System.EventHandler(this.btnCancelarT_Click);
            // 
            // btnLimpiarT
            // 
            this.btnLimpiarT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnLimpiarT.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnLimpiarT.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpiarT.Image = global::frmReposteria.Properties.Resources.escoba_de_limpieza_para_suelos__1_;
            this.btnLimpiarT.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLimpiarT.Location = new System.Drawing.Point(16, 218);
            this.btnLimpiarT.Name = "btnLimpiarT";
            this.btnLimpiarT.Size = new System.Drawing.Size(87, 37);
            this.btnLimpiarT.TabIndex = 32;
            this.btnLimpiarT.Text = "Limpiar";
            this.btnLimpiarT.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLimpiarT.UseVisualStyleBackColor = false;
            this.btnLimpiarT.Click += new System.EventHandler(this.btnLimpiarT_Click);
            // 
            // btnBorrarT
            // 
            this.btnBorrarT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnBorrarT.Enabled = false;
            this.btnBorrarT.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBorrarT.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBorrarT.Image = global::frmReposteria.Properties.Resources.cubo_de_basura;
            this.btnBorrarT.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBorrarT.Location = new System.Drawing.Point(343, 156);
            this.btnBorrarT.Name = "btnBorrarT";
            this.btnBorrarT.Size = new System.Drawing.Size(80, 36);
            this.btnBorrarT.TabIndex = 33;
            this.btnBorrarT.Text = "Borrar";
            this.btnBorrarT.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBorrarT.UseVisualStyleBackColor = false;
            this.btnBorrarT.Click += new System.EventHandler(this.btnBorrarT_Click);
            // 
            // btnModificarT
            // 
            this.btnModificarT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnModificarT.Enabled = false;
            this.btnModificarT.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnModificarT.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnModificarT.Image = global::frmReposteria.Properties.Resources.herramientas_del_empleado_de_mantenimiento;
            this.btnModificarT.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnModificarT.Location = new System.Drawing.Point(321, 112);
            this.btnModificarT.Name = "btnModificarT";
            this.btnModificarT.Size = new System.Drawing.Size(103, 37);
            this.btnModificarT.TabIndex = 31;
            this.btnModificarT.Text = "Modificar";
            this.btnModificarT.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnModificarT.UseVisualStyleBackColor = false;
            this.btnModificarT.Click += new System.EventHandler(this.btnModificarT_Click);
            // 
            // btnGuardarT
            // 
            this.btnGuardarT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnGuardarT.Enabled = false;
            this.btnGuardarT.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnGuardarT.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGuardarT.Image = global::frmReposteria.Properties.Resources.guardar2;
            this.btnGuardarT.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGuardarT.Location = new System.Drawing.Point(325, 63);
            this.btnGuardarT.Name = "btnGuardarT";
            this.btnGuardarT.Size = new System.Drawing.Size(99, 43);
            this.btnGuardarT.TabIndex = 29;
            this.btnGuardarT.Text = "Guardar";
            this.btnGuardarT.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnGuardarT.UseVisualStyleBackColor = false;
            this.btnGuardarT.Click += new System.EventHandler(this.btnGuardarT_Click);
            // 
            // btnNuevoT
            // 
            this.btnNuevoT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnNuevoT.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNuevoT.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNuevoT.Image = global::frmReposteria.Properties.Resources.agregar_usuario;
            this.btnNuevoT.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNuevoT.Location = new System.Drawing.Point(343, 22);
            this.btnNuevoT.Name = "btnNuevoT";
            this.btnNuevoT.Size = new System.Drawing.Size(80, 33);
            this.btnNuevoT.TabIndex = 6;
            this.btnNuevoT.Text = "Nuevo";
            this.btnNuevoT.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNuevoT.UseVisualStyleBackColor = false;
            this.btnNuevoT.Click += new System.EventHandler(this.btnNuevoT_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label2.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(14, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 16);
            this.label2.TabIndex = 37;
            this.label2.Text = "Nombre";
            // 
            // dgvListaT
            // 
            this.dgvListaT.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.dgvListaT.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvListaT.Location = new System.Drawing.Point(18, 265);
            this.dgvListaT.Name = "dgvListaT";
            this.dgvListaT.Size = new System.Drawing.Size(378, 96);
            this.dgvListaT.TabIndex = 36;
            // 
            // cmbStatusT
            // 
            this.cmbStatusT.Enabled = false;
            this.cmbStatusT.Location = new System.Drawing.Point(18, 142);
            this.cmbStatusT.MaxLength = 10;
            this.cmbStatusT.Name = "cmbStatusT";
            this.cmbStatusT.Size = new System.Drawing.Size(116, 20);
            this.cmbStatusT.TabIndex = 28;
            // 
            // btnBuscarT
            // 
            this.btnBuscarT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnBuscarT.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBuscarT.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscarT.Image = global::frmReposteria.Properties.Resources.buscar;
            this.btnBuscarT.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBuscarT.Location = new System.Drawing.Point(150, 11);
            this.btnBuscarT.Name = "btnBuscarT";
            this.btnBuscarT.Size = new System.Drawing.Size(80, 37);
            this.btnBuscarT.TabIndex = 30;
            this.btnBuscarT.Text = "Buscar";
            this.btnBuscarT.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBuscarT.UseVisualStyleBackColor = false;
            this.btnBuscarT.Click += new System.EventHandler(this.btnBuscarT_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tabPage2.Controls.Add(this.btnHabilitarTG);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.txtClaveTGG);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.txtNombreTGG);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.dgvListaTG);
            this.tabPage2.Controls.Add(this.txtStatusTGG);
            this.tabPage2.Controls.Add(this.btnSalirTG);
            this.tabPage2.Controls.Add(this.btnCancelarTG);
            this.tabPage2.Controls.Add(this.btnLimpiarTG);
            this.tabPage2.Controls.Add(this.btnNuevoTG);
            this.tabPage2.Controls.Add(this.btnBuscarTG);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(443, 371);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Habilitar";
            // 
            // btnHabilitarTG
            // 
            this.btnHabilitarTG.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnHabilitarTG.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnHabilitarTG.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHabilitarTG.Image = global::frmReposteria.Properties.Resources.copia_de_seguridad;
            this.btnHabilitarTG.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHabilitarTG.Location = new System.Drawing.Point(169, 61);
            this.btnHabilitarTG.Name = "btnHabilitarTG";
            this.btnHabilitarTG.Size = new System.Drawing.Size(87, 37);
            this.btnHabilitarTG.TabIndex = 216;
            this.btnHabilitarTG.Text = "Habilitar";
            this.btnHabilitarTG.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnHabilitarTG.UseVisualStyleBackColor = false;
            this.btnHabilitarTG.Click += new System.EventHandler(this.btnHabilitarTG_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(16, 128);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 16);
            this.label1.TabIndex = 54;
            this.label1.Text = "Status";
            // 
            // txtClaveTGG
            // 
            this.txtClaveTGG.Enabled = false;
            this.txtClaveTGG.Location = new System.Drawing.Point(19, 39);
            this.txtClaveTGG.MaxLength = 10;
            this.txtClaveTGG.Name = "txtClaveTGG";
            this.txtClaveTGG.Size = new System.Drawing.Size(116, 20);
            this.txtClaveTGG.TabIndex = 40;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label5.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(15, 17);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 16);
            this.label5.TabIndex = 53;
            this.label5.Text = "Clave";
            // 
            // txtNombreTGG
            // 
            this.txtNombreTGG.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtNombreTGG.Enabled = false;
            this.txtNombreTGG.Location = new System.Drawing.Point(19, 90);
            this.txtNombreTGG.MaxLength = 25;
            this.txtNombreTGG.Name = "txtNombreTGG";
            this.txtNombreTGG.Size = new System.Drawing.Size(116, 20);
            this.txtNombreTGG.TabIndex = 42;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label6.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(15, 71);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(50, 16);
            this.label6.TabIndex = 52;
            this.label6.Text = "Nombre";
            // 
            // dgvListaTG
            // 
            this.dgvListaTG.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.dgvListaTG.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvListaTG.Location = new System.Drawing.Point(19, 256);
            this.dgvListaTG.Name = "dgvListaTG";
            this.dgvListaTG.Size = new System.Drawing.Size(363, 96);
            this.dgvListaTG.TabIndex = 51;
            // 
            // txtStatusTGG
            // 
            this.txtStatusTGG.Enabled = false;
            this.txtStatusTGG.Location = new System.Drawing.Point(17, 153);
            this.txtStatusTGG.MaxLength = 10;
            this.txtStatusTGG.Name = "txtStatusTGG";
            this.txtStatusTGG.Size = new System.Drawing.Size(116, 20);
            this.txtStatusTGG.TabIndex = 43;
            // 
            // btnSalirTG
            // 
            this.btnSalirTG.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnSalirTG.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSalirTG.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalirTG.Image = global::frmReposteria.Properties.Resources.salir_3;
            this.btnSalirTG.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSalirTG.Location = new System.Drawing.Point(210, 209);
            this.btnSalirTG.Name = "btnSalirTG";
            this.btnSalirTG.Size = new System.Drawing.Size(70, 37);
            this.btnSalirTG.TabIndex = 50;
            this.btnSalirTG.Text = "Salir";
            this.btnSalirTG.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSalirTG.UseVisualStyleBackColor = false;
            this.btnSalirTG.Click += new System.EventHandler(this.btnSalirTG_Click);
            // 
            // btnCancelarTG
            // 
            this.btnCancelarTG.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnCancelarTG.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCancelarTG.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelarTG.Image = global::frmReposteria.Properties.Resources.prohibido__1_;
            this.btnCancelarTG.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCancelarTG.Location = new System.Drawing.Point(112, 209);
            this.btnCancelarTG.Name = "btnCancelarTG";
            this.btnCancelarTG.Size = new System.Drawing.Size(91, 37);
            this.btnCancelarTG.TabIndex = 49;
            this.btnCancelarTG.Text = "Cancelar";
            this.btnCancelarTG.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCancelarTG.UseVisualStyleBackColor = false;
            this.btnCancelarTG.Click += new System.EventHandler(this.btnCancelarTG_Click);
            // 
            // btnLimpiarTG
            // 
            this.btnLimpiarTG.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnLimpiarTG.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnLimpiarTG.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpiarTG.Image = global::frmReposteria.Properties.Resources.escoba_de_limpieza_para_suelos__1_;
            this.btnLimpiarTG.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLimpiarTG.Location = new System.Drawing.Point(17, 209);
            this.btnLimpiarTG.Name = "btnLimpiarTG";
            this.btnLimpiarTG.Size = new System.Drawing.Size(87, 37);
            this.btnLimpiarTG.TabIndex = 47;
            this.btnLimpiarTG.Text = "Limpiar";
            this.btnLimpiarTG.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLimpiarTG.UseVisualStyleBackColor = false;
            this.btnLimpiarTG.Click += new System.EventHandler(this.btnLimpiarTG_Click);
            // 
            // btnNuevoTG
            // 
            this.btnNuevoTG.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnNuevoTG.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNuevoTG.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNuevoTG.Image = global::frmReposteria.Properties.Resources.agregar_usuario;
            this.btnNuevoTG.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNuevoTG.Location = new System.Drawing.Point(340, 17);
            this.btnNuevoTG.Name = "btnNuevoTG";
            this.btnNuevoTG.Size = new System.Drawing.Size(80, 33);
            this.btnNuevoTG.TabIndex = 41;
            this.btnNuevoTG.Text = "Nuevo";
            this.btnNuevoTG.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNuevoTG.UseVisualStyleBackColor = false;
            this.btnNuevoTG.Click += new System.EventHandler(this.btnNuevoTG_Click);
            // 
            // btnBuscarTG
            // 
            this.btnBuscarTG.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnBuscarTG.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBuscarTG.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscarTG.Image = global::frmReposteria.Properties.Resources.buscar;
            this.btnBuscarTG.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBuscarTG.Location = new System.Drawing.Point(176, 17);
            this.btnBuscarTG.Name = "btnBuscarTG";
            this.btnBuscarTG.Size = new System.Drawing.Size(80, 37);
            this.btnBuscarTG.TabIndex = 45;
            this.btnBuscarTG.Text = "Buscar";
            this.btnBuscarTG.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBuscarTG.UseVisualStyleBackColor = false;
            this.btnBuscarTG.Click += new System.EventHandler(this.btnBuscarTG_Click);
            // 
            // frmTienda
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(466, 418);
            this.Controls.Add(this.tabControl1);
            this.Name = "frmTienda";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmTienda";
            this.Load += new System.EventHandler(this.frmTienda_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaT)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaTG)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtClaveT;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtNombreT;
        private System.Windows.Forms.Button btnSalirT;
        private System.Windows.Forms.Button btnCancelarT;
        private System.Windows.Forms.Button btnLimpiarT;
        private System.Windows.Forms.Button btnBorrarT;
        private System.Windows.Forms.Button btnModificarT;
        private System.Windows.Forms.Button btnGuardarT;
        private System.Windows.Forms.Button btnNuevoT;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dgvListaT;
        private System.Windows.Forms.TextBox cmbStatusT;
        private System.Windows.Forms.Button btnBuscarT;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btnHabilitarTG;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtClaveTGG;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtNombreTGG;
        private System.Windows.Forms.Button btnSalirTG;
        private System.Windows.Forms.Button btnCancelarTG;
        private System.Windows.Forms.Button btnLimpiarTG;
        private System.Windows.Forms.Button btnNuevoTG;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView dgvListaTG;
        private System.Windows.Forms.TextBox txtStatusTGG;
        private System.Windows.Forms.Button btnBuscarTG;
    }
}