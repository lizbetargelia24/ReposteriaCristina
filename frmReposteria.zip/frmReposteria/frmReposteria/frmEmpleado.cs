﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
namespace frmReposteria
{
    public partial class frmEmpleado : Form
    {
        public frmEmpleado()
        {
            InitializeComponent();
        }

        private void btnLimpiarE_Click(object sender, EventArgs e)
        {



        }

        private void btnCancelarE_Click(object sender, EventArgs e)
        {

        }

        private void btnNuevoE_Click(object sender, EventArgs e)
        {


        }

        private void btnGuardarE_Click(object sender, EventArgs e)
        {

        }

        private void btnModificarE_Click(object sender, EventArgs e)
        {

        }

        private void btnBorrarE_Click(object sender, EventArgs e)
        {


        }

        private void btnSalirE_Click(object sender, EventArgs e)
        {

        }

        private void btnBuscarE_Click(object sender, EventArgs e)
        {


        }

        private void txtIdEmpleadoE_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void txtTelefonoE_KeyPress(object sender, KeyPressEventArgs e)
        {
        }

        private void txtNumeroE_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void btnFotoE_Click(object sender, EventArgs e)
        {

        }

        private void txtColoniaE_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtClaveE_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void frmEmpleado_Load(object sender, EventArgs e)
        {
            

            DBEmpleados miBase = new DBEmpleados();
            //Limpiar el DtaGriView
            dgvListaE.DataSource = null;
            DataTable datos = miBase.ConsultarTodos();
            //Poner Los Datos de Consulta en el DataGriView 
            dgvListaE.DataSource = datos;

            DBEmpleados miBasee = new DBEmpleados();
            //Limpiar el DtaGriView
            dgvListaEm.DataSource = null;
            DataTable datoss = miBasee.ConsultarTodosDeshabilitar();
            //Poner Los Datos de Consulta en el DataGriView 

            dgvListaEm.DataSource = datoss;

        }

        private void btnNuevoPa_Click(object sender, EventArgs e)
        {

        }

        private void btnNuevoPa_Click_1(object sender, EventArgs e)
        {
            txtClaveE.Enabled = true;
            txtNombreE.Enabled = true;
            txtAPaternoE.Enabled = true;
            txtAMaternoE.Enabled = true;
            txtClaveE.Enabled = true;
            dtpFecha.Enabled = true;
            txtCurpE.Enabled = true;
            txtTelefonoE.Enabled = true;
            txtColoniaE.Enabled = true;
            txtCalleE.Enabled = true;
            txtNumeroE.Enabled = true;
            btnGuardarE.Enabled = true;
            btnBuscarE.Enabled = true;

        }

        private void btnGuardarE_Click_1(object sender, EventArgs e)
        {
            Boolean exito = false;
            if (txtClaveE.Text.Equals("")) { MessageBox.Show("Faltó Capturar la Clave empleado!!", "Empleado ♥"); exito = true; }

            if (txtNombreE.Text.Equals("")) { MessageBox.Show("Faltó Capturar el Nombre!!", "Empleado ♥"); exito = true; }
            if (txtAPaternoE.Text.Equals("")) { MessageBox.Show("Faltó Capturar el Apellido Paterno!!", "Empleado ♥"); exito = true; }
            if (txtAMaternoE.Text.Equals("")) { MessageBox.Show("Faltó Capturar el Apellido Materno!!", "Empleado ♥"); exito = true; }
            if (dtpFecha.Text.Equals("")) { MessageBox.Show("Faltaron capturar la Fecha de Nacimiento!!", "Empleado ♥"); exito = true; }
            if (txtCurpE.Text.Equals("")) { MessageBox.Show("Faltó Capturar la Curp!!", "Empleado ♥"); exito = true; }
            if (txtTelefonoE.Text.Equals("")) { MessageBox.Show("Faltó Capturar el Telefono !!", "Empleado ♥"); exito = true; }
            if (txtColoniaE.Text.Equals("")) { MessageBox.Show("Faltó Capturar la Colonia!!", "Empleado ♥"); exito = true; }
            if (txtCalleE.Text.Equals("")) { MessageBox.Show("Faltó Capturar la Calle!!", "Empleado ♥"); exito = true; }
            if (txtNumeroE.Text.Equals("")) { MessageBox.Show("Faltó Capturar el Número de Casa!!", "Empleado ♥"); exito = true; }
            if (txtFotoE.Text.Equals("")) { MessageBox.Show("Faltó Capturar la Foto!!!", "Empleado ♥"); exito = true; }


            if (exito == false)
            {
                DBEmpleados mibase = new DBEmpleados();
                if (txtClaveE.Text == txtClaveE.Text)
                {
                    DataTable data = mibase.Consultar(int.Parse(txtClaveE.Text));
                    if (data.Rows.Count > 0)
                    {
                        MessageBox.Show("Ya Existe esta clave", "Empleado ♥");
                    }
                    else
                    {
                        Empleado es = new Empleado();
                        es.Clave = int.Parse(txtClaveE.Text);
                        es.Nombre = txtNombreE.Text;
                        es.APaterno = txtAPaternoE.Text;
                        es.AMaterno = txtAMaternoE.Text;
                        es.Numero = int.Parse(txtNumeroE.Text);
                        es.Curp = txtCurpE.Text;
                        es.Colonia = txtColoniaE.Text;
                        es.Calle = txtCalleE.Text;
                        es.Telefono = txtTelefonoE.Text;
                        es.Foto = txtFotoE.Text;
                        ptbFotoE.Image = Image.FromFile(txtFotoE.Text);
                        es.FecNac = dtpFecha.Value.Year + "-" + dtpFecha.Value.Month + "-" + dtpFecha.Value.Day;


                        mibase.agregarUsandoParametros(es);

                        MessageBox.Show("Se agrego con exito", "Empleado ♥");

                        //Limpia 
                        dgvListaE.DataSource = null;

                        DataTable datos = mibase.ConsultarTodos();

                        //Pone los datos en la consulta

                        dgvListaE.DataSource = datos;
                        txtNombreE.Text = "";
                        txtAPaternoE.Text = "";
                        txtAMaternoE.Text = "";
                        dtpFecha.Text = "";
                        txtCurpE.Text = "";
                        txtTelefonoE.Text = "";
                        txtColoniaE.Text = "";
                        txtCalleE.Text = "";
                        txtNumeroE.Text = "";
                        txtFotoE.Text = "";
                        txtClaveE.Text = "";
                        txtStatusE.Text = "";
                    }
                }
                else
                {

                    MessageBox.Show("Falto capturar la clave", "Empleado ♥");
                    txtClaveE.Focus();
                }

            }
        }

        private void btnModificarE_Click_1(object sender, EventArgs e)
        {
            DBEmpleados mibase = new DBEmpleados();

            Empleado doc = new Empleado();
            txtClaveE.Enabled = false;
            txtStatusE.Enabled = false;
            doc.Foto = txtFotoE.Text;
            ptbFotoE.Image = Image.FromFile(txtFotoE.Text);
            doc.Clave = int.Parse(txtClaveE.Text);
            doc.Nombre = txtNombreE.Text;
            doc.APaterno = txtAPaternoE.Text;
            doc.Numero = int.Parse(txtNumeroE.Text);
            doc.AMaterno = txtAMaternoE.Text;
            doc.FecNac = dtpFecha.Value.Year + "-" + dtpFecha.Value.Month + "-" + dtpFecha.Value.Day;
            doc.Curp = txtCurpE.Text;
            doc.Colonia = txtColoniaE.Text;
            doc.Calle = txtCalleE.Text;
            doc.Telefono = txtTelefonoE.Text;






            mibase.Actualizar(doc);
            dgvListaE.DataSource = null;
            DataTable datos = mibase.ConsultarTodos();
            dgvListaE.DataSource = datos;





            MessageBox.Show("Se ralizó la modificación con éxito", "Empleado ♥");


        }

        private void btnBorrarE_Click_1(object sender, EventArgs e)
        {
                        DialogResult res = MessageBox.Show("¿Deseas borrar el registro?", " Empleado ♥",
         MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);

            if (res == DialogResult.Yes)
            {
                DBEmpleados mibase = new DBEmpleados();

                Empleado docc = new Empleado();

                docc.Clave = int.Parse(txtClaveE.Text);
                docc.Nombre = txtNombreE.Text;
                docc.APaterno = txtAPaternoE.Text;
                docc.AMaterno = txtAMaternoE.Text;
                docc.FecNac = dtpFecha.Text;
                docc.Curp = txtCurpE.Text;
                docc.Colonia = txtColoniaE.Text;
                docc.Calle = txtCalleE.Text;
                docc.Telefono = txtTelefonoE.Text;

                mibase.Deshabilitar(docc);



                txtClaveE.Text = "";
                txtStatusE.Text = "";
                txtNombreE.Text = "";
                txtAPaternoE.Text = "";
                txtAMaternoE.Text = "";
                dtpFecha.Value = DateTime.Now;
                txtCurpE.Text = "";
                txtTelefonoE.Text = "";
                txtColoniaE.Text = "";
                txtCalleE.Text = "";
                txtNumeroE.Text = "";
                txtFotoE.Text = "";

                ptbFotoE.Image = frmReposteria.Properties.Resources.imagen;
                DBEmpleados miBase = new DBEmpleados();
                //Limpiar el DtaGriView
                dgvListaE.DataSource = null;
                DataTable datos = miBase.ConsultarTodos();
                //Poner Los Datos de Consulta en el DataGriView 
                dgvListaE.DataSource = datos;

                DBEmpleados miBasee = new DBEmpleados();
                //Limpiar el DtaGriView
                dgvListaEm.DataSource = null;
                DataTable datoss = miBasee.ConsultarTodosDeshabilitar();
                //Poner Los Datos de Consulta en el DataGriView 

                dgvListaEm.DataSource = datoss;
            }

        }

        private void btnFotoE_Click_1(object sender, EventArgs e)
        {
            OpenFileDialog foto = new OpenFileDialog();
            foto.InitialDirectory = "C:\\";
            foto.ShowDialog();
            txtFotoE.Text = foto.FileName;
            ptbFotoE.ImageLocation = foto.FileName;
        }

        private void btnSalirE_Click_1(object sender, EventArgs e)
        {
            DialogResult res;
            res = MessageBox.Show("¿Deseas salir?", "Empleado ♥", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
            if (res == DialogResult.Yes) this.Close();

        }

        private void btnBuscarE_Click_1(object sender, EventArgs e)
        {
            DBEmpleados miBase = new DBEmpleados();



            if (txtClaveE.Text != "")
            {
                DataTable datos = miBase.Consultar(int.Parse(txtClaveE.Text));
                if (datos.Rows.Count > 0)
                {

                    txtNombreE.Text = datos.Rows[0]["Nombre"].ToString();
                    txtStatusE.Text = datos.Rows[0]["Status"].ToString();
                    txtAPaternoE.Text = datos.Rows[0]["APaterno"].ToString();
                    txtAMaternoE.Text = datos.Rows[0]["AMaterno"].ToString();

                    dtpFecha.Text = datos.Rows[0]["fechaNac"].ToString();



                    txtFotoE.Text = datos.Rows[0]["foto"].ToString();
                    ptbFotoE.Image = Image.FromFile(txtFotoE.Text);

                    txtCurpE.Text = datos.Rows[0]["Curp"].ToString();
                    txtColoniaE.Text = datos.Rows[0]["Colonia"].ToString();
                    txtCalleE.Text = datos.Rows[0]["Calle"].ToString();
                    txtTelefonoE.Text = datos.Rows[0]["Telefono"].ToString();
                    txtNumeroE.Text = datos.Rows[0]["NumeroCasa"].ToString();

                    txtClaveE.Enabled = false;
                    btnBorrarE.Enabled = true;
                    btnGuardarE.Enabled = true;
                    btnModificarE.Enabled = true;
                    txtNombreE.Enabled = true;
                    txtAPaternoE.Enabled = true;
                    txtAMaternoE.Enabled = true;
                    dtpFecha.Enabled = true;
                    txtCurpE.Enabled = true;
                    txtTelefonoE.Enabled = true;
                    txtColoniaE.Enabled = true;
                    txtCalleE.Enabled = true;
                    txtNumeroE.Enabled = true;

                }

                else
                {
                    MessageBox.Show("No hay registro con esa Clave", "Empleados ♥");
                }

            }
            else
            {
                MessageBox.Show("Faltó capturar la Clave", "Empleados ♥");
                txtClaveE.Focus();
            }

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {
          
        }

        private void btnLimpiarE_Click_1(object sender, EventArgs e)
        {
            txtNombreE.Text = "";
            txtAPaternoE.Text = "";
            txtAMaternoE.Text = "";
            dtpFecha.Text = "";
            txtCurpE.Text = "";
            txtTelefonoE.Text = "";
            txtColoniaE.Text = "";
            txtCalleE.Text = "";
            txtNumeroE.Text = "";
            txtFotoE.Text = "";
            txtClaveE.Text = "";
            txtStatusE.Text = "";



            ptbFotoE.Image = frmReposteria.Properties.Resources.imagen;
            txtNombreE.Enabled = false;
            txtAPaternoE.Enabled = false;
            txtAMaternoE.Enabled = false;
            dtpFecha.Enabled = false;
            txtClaveE.Enabled = true;
            txtTelefonoE.Enabled = false;
            txtColoniaE.Enabled = false;
            txtCalleE.Enabled = false;
            txtNumeroE.Enabled = false;
            btnBorrarE.Enabled = false;
            btnModificarE.Enabled = false;

            txtCurpE.Enabled = false;


        }

        private void btnCancelarE_Click_1(object sender, EventArgs e)
        {
            txtNombreE.Text = "";
            txtAPaternoE.Text = "";
            txtAMaternoE.Text = "";
            dtpFecha.Text = "";
            txtCurpE.Text = "";
            txtTelefonoE.Text = "";
            txtColoniaE.Text = "";
            txtCalleE.Text = "";
            txtNumeroE.Text = "";
            txtFotoE.Text = "";
            ptbFotoE.Image = frmReposteria.Properties.Resources.imagen;

            btnBorrarE.Enabled = false;
            btnModificarE.Enabled = false;

            txtClaveE.Enabled = false;
            txtNombreE.Enabled = false;
            txtAPaternoE.Enabled = false;
            txtAMaternoE.Enabled = false;
            dtpFecha.Enabled = false;
            txtCurpE.Enabled = false;
            txtTelefonoE.Enabled = false;
            txtColoniaE.Enabled = false;
            txtCalleE.Enabled = false;
            txtNumeroE.Enabled = false;
            txtClaveE.Enabled = true;

        }

        private void txtClaveE_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }

        }

        private void txtTelefonoE_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }

        }

        private void txtNumeroE_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }

        }

        private void btnBuscarEm_Click(object sender, EventArgs e)
        {
            DBEmpleados miBase = new DBEmpleados();



            if (txtClaveEm.Text != "")
            {
                DataTable datos = miBase.ConsultarH(int.Parse(txtClaveEm.Text));
                if (datos.Rows.Count > 0)
                {

                    txtNombreEm.Text = datos.Rows[0]["Nombre"].ToString();
                    txtStatusEm.Text = datos.Rows[0]["Status"].ToString();
                    txtaPaternoEm.Text = datos.Rows[0]["APaterno"].ToString();
                    txtaMaternoEm.Text = datos.Rows[0]["AMaterno"].ToString();

                    dtpFechaEm.Text = datos.Rows[0]["fechaNac"].ToString();



                    txtFotoEm.Text = datos.Rows[0]["foto"].ToString();
                    ptbFotoEm.Image = Image.FromFile(txtFotoEm.Text);

                    txtCurpEm.Text = datos.Rows[0]["Curp"].ToString();
                    txtColoniaEm.Text = datos.Rows[0]["Colonia"].ToString();
                    txtCalleEm.Text = datos.Rows[0]["Calle"].ToString();
                    txtTelefonoEm.Text = datos.Rows[0]["Telefono"].ToString();
                    txtNumCasaEm.Text = datos.Rows[0]["NumeroCasa"].ToString();

                    txtClaveEm.Enabled = false;
                   

                }

                else
                {
                    MessageBox.Show("No hay registro con esa Clave", "Empleados ♥");
                }

            }
            else
            {
                MessageBox.Show("Faltó capturar la Clave", "Empleados ♥");
                txtClaveEm.Focus();
            }

        }

        private void btnLimpiarEm_Click(object sender, EventArgs e)
        {
            txtNombreEm.Text = "";
            txtaPaternoEm.Text = "";
            txtaMaternoEm.Text = "";
            dtpFechaEm.Text = "";
            txtCurpEm.Text = "";
            txtTelefonoEm.Text = "";
            txtColoniaEm.Text = "";
            txtCalleEm.Text = "";
            txtNumCasaEm.Text = "";
            txtFotoEm.Text = "";
            txtClaveEm.Text = "";
            txtStatusEm.Text = "";



            ptbFotoEm.Image = frmReposteria.Properties.Resources.imagen;
            txtNombreEm.Enabled = false;
            txtaPaternoEm.Enabled = false;
            txtaMaternoEm.Enabled = false;
            dtpFechaEm.Enabled = false;
            txtClaveEm.Enabled = true;
            txtTelefonoE.Enabled = false;
            txtColoniaEm.Enabled = false;
            txtCalleEm.Enabled = false;
            txtNumCasaEm.Enabled = false;
        

            txtCurpEm.Enabled = false;
        }

        private void btnCancelarEm_Click(object sender, EventArgs e)
        {
            txtNombreEm.Text = "";
            txtaPaternoEm.Text = "";
            txtaMaternoEm.Text = "";
            dtpFechaEm.Text = "";
            txtCurpEm.Text = "";
            txtTelefonoEm.Text = "";
            txtColoniaEm.Text = "";
            txtCalleEm.Text = "";
            txtNumCasaEm.Text = "";
            txtFotoEm.Text = "";
            txtClaveEm.Text = "";
            txtStatusEm.Text = "";



            ptbFotoEm.Image = frmReposteria.Properties.Resources.imagen;
            txtNombreEm.Enabled = false;
            txtaPaternoEm.Enabled = false;
            txtaMaternoEm.Enabled = false;
            dtpFechaEm.Enabled = false;
            txtClaveEm.Enabled = true;
            txtTelefonoE.Enabled = false;
            txtColoniaEm.Enabled = false;
            txtCalleEm.Enabled = false;
            txtNumCasaEm.Enabled = false;

            txtClaveEm.Enabled = false;
            txtCurpEm.Enabled = false;
        }

        private void btnSalirEm_Click(object sender, EventArgs e)
        {
            DialogResult res;
            res = MessageBox.Show("¿Deseas salir?", "Empleado ♥", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
            if (res == DialogResult.Yes) this.Close();
        }

        private void btnNuevoEm_Click(object sender, EventArgs e)
        {
            txtClaveEm.Enabled = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DBEmpleados mibasee = new DBEmpleados();

            Empleado docc = new Empleado();

            docc.Clave = int.Parse(txtClaveEm.Text);
            docc.Nombre = txtNombreEm.Text;
            docc.APaterno = txtaPaternoEm.Text;
            docc.AMaterno = txtaMaternoEm.Text;
            docc.FecNac = dtpFechaEm.Text;
            docc.Curp = txtCurpEm.Text;
            docc.Colonia = txtColoniaEm.Text;
            docc.Calle = txtCalleEm.Text;
            docc.Telefono = txtTelefonoEm.Text;

            mibasee.Habilitar(docc);



            txtClaveEm.Text = "";
            txtStatusEm.Text = "";
            txtNombreEm.Text = "";
            txtaPaternoEm.Text = "";
            txtaMaternoEm.Text = "";
            dtpFechaEm.Value = DateTime.Now;
            txtCurpEm.Text = "";
            txtTelefonoEm.Text = "";
            txtColoniaEm.Text = "";
            txtCalleEm.Text = "";
            txtNumCasaEm.Text = "";
            txtFotoEm.Text = "";
            ptbFotoEm.Image = frmReposteria.Properties.Resources.imagen;

            DBEmpleados miBase = new DBEmpleados();
            //Limpiar el DtaGriView
            dgvListaE.DataSource = null;
            DataTable datos = miBase.ConsultarTodos();
            //Poner Los Datos de Consulta en el DataGriView 
            dgvListaE.DataSource = datos;

            DBEmpleados miBasee = new DBEmpleados();
            //Limpiar el DtaGriView
            dgvListaEm.DataSource = null;
            DataTable datoss = miBasee.ConsultarTodosDeshabilitar();
            //Poner Los Datos de Consulta en el DataGriView 

            dgvListaEm.DataSource = datoss;



        }

        private void tabPage2_Click(object sender, EventArgs e)
        {
           
        }

        private void dgvListaEm_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
