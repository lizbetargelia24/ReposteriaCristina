﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;

namespace frmReposteria
{
    class DBCompras
    {
        private MySqlConnection conexion;
        private string strConexion;
        private MySqlCommand sqlComando;
        private string strConsulta;
        private MySqlDataAdapter adaptador;

        public DBCompras()
        {
            //Constructor
            conexion = new MySqlConnection();
            strConexion = "Server=localHost;User=root;DataBase=bdreposteria;port=3306;Password=";

            conexion.ConnectionString = strConexion;

            sqlComando = new MySqlCommand();
            adaptador = new MySqlDataAdapter();

        }
        public Boolean abrir()
        {
            Boolean exito = false;

            if (conexion.State == System.Data.ConnectionState.Closed)
            {

                conexion.Open();
                exito = true;

            }



            return exito;
        }
        public Boolean Cerrar()
        {
            Boolean exito = false;

            if (conexion.State == System.Data.ConnectionState.Closed)
            {

                exito = false;
            }
            else
            {
                conexion.Close();
                exito = true;
            }
            return exito;
        }
        // public Boolean Cerrar()
        // {
        //    Boolean exito = false;
        //    if (conexion.State == ConnectionState.Closed)
        //    {
        //    conexion.Close();
        //   exito = true;
        // }
        // return exito;
        // }


        //Agregar sin parametros
        // public void agregarSinParsametros(Empleado obj)
        //{
        //    string sqlConsulta = "insert into especialidades (idespecialidades,codigo,nombre,status) values (null," + obj.Clave + "," + obj.Nombre + ",0)";
        //    this.abrir();
        //    sqlComando.Connection = conexion;
        //    sqlComando.CommandText = sqlConsulta;

        //    sqlComando.ExecuteNonQuery();
        //    this.Cerrar();
        //}
        //Agregar usando parametros
        public void agregarUsandoParametros(Compras obj)
        {
            string sqlConsulta = "insert into tcompras (folioCompra,fechaCompra,  empleado, tienda, tipoPago)values(?pfolioCompra, ?pfechaCompra, ?pempleado, ?ptienda, ?ptipoPago)";
            sqlComando.Parameters.Clear();

            sqlComando.Parameters.Add("?pfolioCompra", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.FolioCompra;
            sqlComando.Parameters.Add("?pfechaCompra", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.FechaCompra;
            sqlComando.Parameters.Add("?pempleado", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Empleado;
            sqlComando.Parameters.Add("?ptienda", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Tienda;
            sqlComando.Parameters.Add("?ptipoPago", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.TipoPago;
            ////    sqlComando.Parameters.Add("?pcodigo", MySql.Data.MySqlClient.MySqlDbType.Int32).Value = obj.Codigo;
            //   sqlComando.Parameters.Add("?ptipoProducto", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Producto;
            //  sqlComando.Parameters.Add("?pprecioVenta", MySql.Data.MySqlClient.MySqlDbType.Float).Value = obj.PrecioVenta;
            //   sqlComando.Parameters.Add("?pprecioCompra", MySql.Data.MySqlClient.MySqlDbType.Float).Value = obj.PrecioCompra;
            //   sqlComando.Parameters.Add("?putilidad", MySql.Data.MySqlClient.MySqlDbType.Float).Value = obj.Utilidad;


            this.abrir();
            sqlComando.Connection = conexion;
            sqlComando.CommandText = sqlConsulta;

            sqlComando.ExecuteNonQuery();
            this.Cerrar();

        }
        public void agregarUsandoParametros2(DetalleCompra obj)
        {
            string sqlConsulta = "insert into tdetallecompra (iddetallecompra, codigo,tipoProducto,precioCompra,folioCom,totalCompra,  cantidad)values(null, ?pcodigo, ?ptipoProducto, ?pprecioCompra,?pfolioCom, ?ptotalCompra,  ?pcantidad)";
            sqlComando.Parameters.Clear();

            sqlComando.Parameters.Add("?pcodigo", MySql.Data.MySqlClient.MySqlDbType.Int32).Value = obj.Codigo;
            sqlComando.Parameters.Add("?ptipoProducto", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Producto;
            sqlComando.Parameters.Add("?pfolioCom", MySql.Data.MySqlClient.MySqlDbType.Int32).Value = obj.FolioCom;
            sqlComando.Parameters.Add("?pprecioCompra", MySql.Data.MySqlClient.MySqlDbType.Float).Value = obj.PrecioCompra;
            sqlComando.Parameters.Add("?ptotalCompra", MySql.Data.MySqlClient.MySqlDbType.Float).Value = obj.TotalCompra;
            sqlComando.Parameters.Add("?pcantidad", MySql.Data.MySqlClient.MySqlDbType.Int24).Value = obj.Cantidad;

            this.abrir();
            sqlComando.Connection = conexion;
            sqlComando.CommandText = sqlConsulta;

            sqlComando.ExecuteNonQuery();
            this.Cerrar();

        }
     //   public Producto buscarProductos(string clave)
     //   {
     //     DataTable registros = new DataTable();
    //      Producto pro = new Producto();
    //      sqlComando.Parameters.Clear();
    //      sqlComando.Parameters.Add("?pclave", MySqlDbType.VarChar).Value = clave;
    //      string sqlConsulta = "Select * FROM tproducto where clave = ?pclave and status = 0";
       //   this.abrir();
    //       sqlComando.Connection = conexion;
     //      sqlComando.CommandText = sqlConsulta;
//
     //     adaptador.SelectCommand = sqlComando;
     //     adaptador.Fill(registros);
     //       this.Cerrar();
     //      if(registros.Rows.Count > 0)
       //   {
       //      pro.Clave = int.Parse(registros.Rows[0]["clave"].ToString());
       //      pro.Descripcion = (registros.Rows[0]["descripcion"].ToString());
       //      pro.PrecioVenta = float.Parse(registros.Rows[0]["precioVenta"].ToString());
       //      pro.PrecioCompra = float.Parse(registros.Rows[0]["precioCompra"].ToString());

       //   }
      // }
        public void Actualizar(Compras obj)
        {
            string sqlConsulta = "Update tcompras set folioCompra = ?pfolioCompra, fechaCompra = ?pfechaCompra , empleado = ?pempleado, tienda = ?ptienda, tipoPago = ?ptipoPago where folioCompra = ?pfolioCompra";
            sqlComando.Parameters.Clear();
            sqlComando.Parameters.Add("?pfolioCompra", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.FolioCompra;
            sqlComando.Parameters.Add("?pfechaCompra", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.FechaCompra;
            sqlComando.Parameters.Add("?pempleado", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Empleado;
            sqlComando.Parameters.Add("?ptienda", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Tienda;
            sqlComando.Parameters.Add("?ptipoPago", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.TipoPago;
          //  sqlComando.Parameters.Add("?pcodigo", MySql.Data.MySqlClient.MySqlDbType.Int32).Value = obj.Codigo;
         //   sqlComando.Parameters.Add("?ptipoProducto", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Producto;
          //  sqlComando.Parameters.Add("?pprecioVenta", MySql.Data.MySqlClient.MySqlDbType.Float).Value = obj.PrecioVenta;
         //   sqlComando.Parameters.Add("?pprecioCompra", MySql.Data.MySqlClient.MySqlDbType.Float).Value = obj.PrecioCompra;
         //   sqlComando.Parameters.Add("?putilidad", MySql.Data.MySqlClient.MySqlDbType.Float).Value = obj.Utilidad;

            this.abrir();
            sqlComando.Connection = conexion;
            sqlComando.CommandText = sqlConsulta;

            sqlComando.ExecuteNonQuery();
            this.Cerrar();
        }
     
        //Deshabilitar

        //Consultar
        public DataTable Consultar(int FolioCompra)
        {
            DataTable datos = new DataTable();
            strConsulta = "select * from tcompras where  folioCompra =" + FolioCompra;

            this.abrir();
            sqlComando.CommandText = strConsulta;
            sqlComando.Connection = conexion;
            adaptador.SelectCommand = sqlComando;
            adaptador.Fill(datos);

            this.Cerrar();

            return datos;
        }
        public DataTable Consultar2(int folioCom)
        {
            DataTable datos = new DataTable();
            strConsulta = "select * from tdetallecompra where  folioCom =" + folioCom  ;

            this.abrir();
            sqlComando.CommandText = strConsulta;
            sqlComando.Connection = conexion;
            adaptador.SelectCommand = sqlComando;
            adaptador.Fill(datos);

            this.Cerrar();

            return datos;
        }
        //Metodo consultar todos
        public DataTable ConsultarTodos()
        {
            DataTable datos = new DataTable();
            strConsulta = "select *from tcompras order by foliocompra asc";
            abrir();
            sqlComando.CommandText = strConsulta;
            sqlComando.Connection = conexion;

            adaptador.SelectCommand = sqlComando;
            adaptador.Fill(datos);
            Cerrar();
            return datos;
        }
        public DataTable ConsultarTodos2()
        {
            DataTable datos = new DataTable();
            strConsulta = "select *from tdetalleventa order by codigo asc";
            abrir();
            sqlComando.CommandText = strConsulta;
            sqlComando.Connection = conexion;

            adaptador.SelectCommand = sqlComando;
            adaptador.Fill(datos);
            Cerrar();
            return datos;
        }

        public DataTable ConsultarTodos3()
        {
            DataTable datos = new DataTable();
            strConsulta = "select *from templeado where status = 0 order by clave asc";
            abrir();
            sqlComando.CommandText = strConsulta;
            sqlComando.Connection = conexion;

            adaptador.SelectCommand = sqlComando;
            adaptador.Fill(datos);
            Cerrar();
            return datos;
        }
        public DataTable ConsultarTodos4()
        {
            DataTable datos = new DataTable();
            strConsulta = "select *from ttipopago where status = 0 order by clave asc";
            abrir();
            sqlComando.CommandText = strConsulta;
            sqlComando.Connection = conexion;

            adaptador.SelectCommand = sqlComando;
            adaptador.Fill(datos);
            Cerrar();
            return datos;
        }
        public DataTable ConsultarTodos5()
        {
            DataTable datos = new DataTable();
            strConsulta = "select *from ttienda where status = 0 order by clave asc";
            abrir();
            sqlComando.CommandText = strConsulta;
            sqlComando.Connection = conexion;

            adaptador.SelectCommand = sqlComando;
            adaptador.Fill(datos);
            Cerrar();
            return datos;
        }
        public DataTable ConsultarTodosProductos()
        {
            DataTable datos2 = new DataTable();
            strConsulta = "select *from tproducto where status = 0 order by clave asc";
            abrir();
            sqlComando.CommandText = strConsulta;
            sqlComando.Connection = conexion;

            adaptador.SelectCommand = sqlComando;
            adaptador.Fill(datos2);
            Cerrar();
            return datos2;
        }
    }
}
