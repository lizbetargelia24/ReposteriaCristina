﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace frmReposteria
{
    public partial class frmCompras : Form
    {
        public frmCompras()
        {
            InitializeComponent();
        }
        private ArrayList com = new ArrayList();
        private Compras comp;
      //  public Boolean siExistee(int folioCompra)

       // {
       //     Boolean existe = false;

      //      foreach (Compras pr in com)
         //   {
           //     if (pr.FolioCompra == int.Parse(txtFolioCompraC.Text))
         //       {
               //     existe = true;
         //       }
       //     }
           // return existe;
       // }
        private DetalleCompra detalle;
       


        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtCodigoC.Text = cmbProductoC.SelectedValue.ToString();
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void btnNuevoV_Click(object sender, EventArgs e)
        {
            txtFolioCompraC.Text = "";
            txtFolioCompraC.Enabled = true;
            cmbTiendaC.Enabled = true;
            cmbTipoPagoC.Enabled = true;
            cmbProductoC.Enabled = true;
            cmbEmpleadoC.Enabled = true;
            txtCodigoC.Enabled = true;
            dtpFechaC.Enabled = true;
            txtPrecioCompraC.Enabled = true;
            cmbEmpleadoC.Text = "";
            cmbProductoC.Text = "";
            cmbTiendaC.Text = "";
            cmbTipoPagoC.Text = "";
          //  txtTotalCompraC.Enabled = true;
          //  txtTotalVentaC.Enabled = true;
          //  txtUtilidadC.Enabled = true;
            txtCantidadC.Enabled = true;
            btnBorrarC.Enabled = true;
            btnGuardarC.Enabled = true;
            btnBuscarC.Enabled = true;
            dgvListaC.DataSource = null;
            btnGuardarC.Enabled = true;
            btnRealizarCompraC.Enabled = true;
        }

        private void frmCompras_Load(object sender, EventArgs e)
        {
            DBProductos alum = new DBProductos();
            DataTable datosEsp = alum.ConsultarTodosProductos();
            cmbProductoC.DataSource = datosEsp;
            cmbProductoC.DisplayMember = "descripcion";
            cmbProductoC.ValueMember = "idproducto";
            txtCodigoC.Text = "";
            cmbProductoC.AutoCompleteMode = AutoCompleteMode.Suggest;
            cmbProductoC.AutoCompleteSource = AutoCompleteSource.CustomSource;
            cmbProductoC.AutoCompleteCustomSource = this.cargarDatos();

            DBEmpleados alum2 = new DBEmpleados();
            DataTable datosEsp2 = alum2.ConsultarTodos3();
            cmbEmpleadoC.DataSource = datosEsp2;
            cmbEmpleadoC.DisplayMember = "nombre";
            cmbEmpleadoC.ValueMember = "idEmpleado";
            cmbEmpleadoC.AutoCompleteMode = AutoCompleteMode.Suggest;
            cmbEmpleadoC.AutoCompleteSource = AutoCompleteSource.CustomSource;
            cmbEmpleadoC.AutoCompleteCustomSource = this.cargarDatos2();

            DBTipoPago alum3 = new DBTipoPago();
            DataTable datosEsp3 = alum3.ConsultarTodos4();
            cmbTipoPagoC.DataSource = datosEsp3;
            cmbTipoPagoC.DisplayMember = "descripcion";
            cmbTipoPagoC.ValueMember = "idTipoPago";
            cmbTipoPagoC.AutoCompleteMode = AutoCompleteMode.Suggest;
            cmbTipoPagoC.AutoCompleteSource = AutoCompleteSource.CustomSource;
            cmbTipoPagoC.AutoCompleteCustomSource = this.cargarDatos4();

            DBTienda alum4 = new DBTienda();
            DataTable datosEsp4 = alum4.ConsultarTodos5();
            cmbTiendaC.DataSource = datosEsp4;
            cmbTiendaC.DisplayMember = "nombre";
            cmbTiendaC.ValueMember = "idTienda";
            cmbTiendaC.AutoCompleteMode = AutoCompleteMode.Suggest;
            cmbTiendaC.AutoCompleteSource = AutoCompleteSource.CustomSource;
            cmbTiendaC.AutoCompleteCustomSource = this.cargarDatos3();

           // DBCompras miBase = new DBCompras();
            //Limpiar el DtaGriView
          //  dgvListaC.DataSource = null;
           // DataTable datos = miBase.ConsultarTodos();
            //Poner Los Datos de Consulta en el DataGriView 
          //  dgvListaC.DataSource = datos;

        }
        private AutoCompleteStringCollection cargarDatos()
        {
            AutoCompleteStringCollection datos = new AutoCompleteStringCollection();
            DBProductos al = new DBProductos();

            DataTable tcompras = al.ConsultarTodosProductos();
            string tproducto = "";
            for (int i = 0; i < tcompras.Rows.Count; ++i)
            {
                tproducto = tcompras.Rows[i]["descripcion"].ToString();
                datos.Add(tproducto);
            }
            return datos;
        }
        private AutoCompleteStringCollection cargarDatos2()
        {
            AutoCompleteStringCollection datos = new AutoCompleteStringCollection();
            DBEmpleados al = new DBEmpleados();

            DataTable tventas = al.ConsultarTodos3();
            string templeado = "";
            for (int i = 0; i < tventas.Rows.Count; ++i)
            {
                templeado = tventas.Rows[i]["nombre"].ToString();
                datos.Add(templeado);
            }
            return datos;
        }
        private AutoCompleteStringCollection cargarDatos3()
        {
            AutoCompleteStringCollection datos = new AutoCompleteStringCollection();
            DBTienda al = new DBTienda();

            DataTable tcompras = al.ConsultarTodos5();
            string ttienda = "";
            for (int i = 0; i < tcompras.Rows.Count; ++i)
            {
                ttienda = tcompras.Rows[i]["nombre"].ToString();
                datos.Add(ttienda);
            }
            return datos;
        }
        private AutoCompleteStringCollection cargarDatos4()
        {
            AutoCompleteStringCollection datos = new AutoCompleteStringCollection();
            DBTipoPago al = new DBTipoPago();

            DataTable tventas = al.ConsultarTodos4();
            string ttipopago = "";
            for (int i = 0; i < tventas.Rows.Count; ++i)
            {
                ttipopago = tventas.Rows[i]["descripcion"].ToString();
                datos.Add(ttipopago);
            }
            return datos;
        }

        private void txtCodigoC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void txtFolioCompraC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void txtPrecioVentaC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void txtPrecioCompraC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void txtCantidadC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void btnLimpiarC_Click(object sender, EventArgs e)
        {
            txtFolioCompraC.Text = "";
            cmbTiendaC.Text = "";
            cmbTipoPagoC.Text = "";
            cmbProductoC.Text = "";
            cmbEmpleadoC.Text = "";
            txtCodigoC.Text = "";
            dtpFechaC.Text = "";
            txtPrecioCompraC.Text = "";
            txtCantidadC.Text = "";
            dgvListaC.DataSource = null;
            txtTotalCompraC.Text = "";
            txtCantidadC.Enabled = false;
            txtFolioCompraC.Enabled = true;
            cmbTiendaC.Enabled = false;
            cmbTipoPagoC.Enabled = false;
            cmbProductoC.Enabled = false;
            cmbEmpleadoC.Enabled = false;
            txtCodigoC.Enabled = false;
            dtpFechaC.Enabled = false;
            txtPrecioCompraC.Enabled = false;
           
            

            btnBuscarC.Enabled = true;

            btnGuardarC.Enabled = false;
            btnRealizarCompraC.Enabled = false;
        }

        private void btnCancelarC_Click(object sender, EventArgs e)
        {
           
            txtFolioCompraC.Text = "";
            cmbTiendaC.Text = "";
            cmbTipoPagoC.Text = "";
            cmbProductoC.Text = "";
            cmbEmpleadoC.Text = "";
            txtCodigoC.Text = "";
            dtpFechaC.Text = "";
            txtPrecioCompraC.Text = "";
            txtTotalCompraC.Text = "";
            dgvListaC.DataSource = null;
            txtFolioCompraC.Enabled = false;
            cmbTiendaC.Enabled = false;
            cmbTipoPagoC.Enabled = false;
            cmbProductoC.Enabled = false;
            cmbEmpleadoC.Enabled = false;
            txtCodigoC.Enabled = false;
            dtpFechaC.Enabled = false;
            txtPrecioCompraC.Enabled = false;
            
            btnBorrarC.Enabled = false;

            btnBuscarC.Enabled = false;

            btnGuardarC.Enabled = false;
            btnRealizarCompraC.Enabled = false;
        }

        private void btnSalirC_Click(object sender, EventArgs e)
        {
            DialogResult res;
            res = MessageBox.Show("¿Deseas salir?", "Compras ♥", 
                MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
            if (res == DialogResult.Yes) this.Close();
        }

        private void btnBorrarC_Click(object sender, EventArgs e)
        {
            if (dgvListaC.Rows.Count >0)
            {
                int index = dgvListaC.CurrentRow.Index;
                DetalleCompra detalle = (DetalleCompra)com[index];
                DialogResult res = MessageBox.Show("Deseas borrar el producto " + detalle.Producto, "Productos",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
                if(res == DialogResult.Yes)
                {
                    com.RemoveAt(index);
                    dgvListaC.DataSource = null;
                    dgvListaC.DataSource = com;

                }
            }


        }

        private void btnGuardarC_Click(object sender, EventArgs e)
        {
            Boolean exito = false;
            if (txtFolioCompraC.Text.Equals("")) { MessageBox.Show("Faltó Capturar el folio!!", "Compras ♥"); exito = true; }
      
            if (txtCodigoC.Text.Equals("")) { MessageBox.Show("Faltó Capturar el codigo!!", "Compras ♥"); exito = true; }
            if (cmbProductoC.Text.Equals("")) { MessageBox.Show("Faltó Capturar el producto!!", "Compras ♥"); exito = true; }
         
            if (txtPrecioCompraC.Text.Equals("")) { MessageBox.Show("Faltó Capturar el precio compra!!", "Compras ♥"); exito = true; }


            if (exito == false)
            {
                DetalleCompra detalle = new DetalleCompra();

                DBCompras mibase = new DBCompras();
                DetalleCompra deta = new DetalleCompra();
                
                detalle.PrecioCompra = float.Parse(txtPrecioCompraC.Text);
                detalle.FolioCom = int.Parse(txtFolioCompraC.Text);
                detalle.Codigo = int.Parse(txtCodigoC.Text);
                detalle.Cantidad = int.Parse(txtCantidadC.Text);
                detalle.Producto = cmbProductoC.Text;


                float totalCompra = 0.0f;
                totalCompra = detalle.calcularTotalCompraC();
                txtTotalCompraC.Text = totalCompra.ToString();
                detalle.TotalCompra = float.Parse(txtTotalCompraC.Text);

                //detalle.PrecioCompra = float.Parse(txtPrecioCompraC.Text);


                //this.calcularUtilidad();
                com.Add(detalle);
                detalle.PrecioCompra = float.Parse(txtPrecioCompraC.Text);
                this.calcularCompra();

                dgvListaC.DataSource = null;
                dgvListaC.DataSource = com;

                

               // cmbTiendaC.Text = "";
             //   cmbTipoPagoC.Text = "";
                cmbProductoC.Text = "";
             //   cmbEmpleadoC.Text = "";
                txtCodigoC.Text = "";
           //     dtpFechaC.Text = "";
                txtPrecioCompraC.Text = "";
                
                txtCantidadC.Text = "";
              //  txtTotalCompraC.Text = "";
                
                






            }
        }

        private void btnRealizarCompraC_Click(object sender, EventArgs e)
        {
            DialogResult res = MessageBox.Show("¿Deseas Realizar la Compra?", "Compras", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);

            if(res == DialogResult.Yes)
            {
                Boolean exito = false;
                if (txtFolioCompraC.Text.Equals("")) { MessageBox.Show("Faltó Capturar el folio!!", "Compras ♥"); exito = true; }
                if (cmbTiendaC.Text.Equals("")) { MessageBox.Show("Faltó Capturar el nombre de la tienda!!", "Compras ♥"); exito = true; }
                if (cmbTipoPagoC.Text.Equals("")) { MessageBox.Show("Faltó Capturar el tipo de pago!!", "Compras ♥"); exito = true; }
                if (dtpFechaC.Text.Equals("")) { MessageBox.Show("Faltó Capturar la fecha de compra!!", "Compras ♥"); exito = true; }
                if (cmbEmpleadoC.Text.Equals("")) { MessageBox.Show("Faltaron capturar el nombre de empleado!!", "Compras ♥"); exito = true; }
           

                if (exito == false)
                { DBCompras mibase = new DBCompras();
                    if (txtFolioCompraC.Text == txtFolioCompraC.Text)
                    {
                        DataTable dataa = mibase.Consultar(int.Parse(txtFolioCompraC.Text));
                        if (dataa.Rows.Count > 0)
                        {
                            MessageBox.Show("Ya Existe el Folio", "Compras ♥");
                        }
                        else
                        {
                           

                            DataTable data = mibase.Consultar(int.Parse(txtFolioCompraC.Text));


                            Compras comp = new Compras();
                            comp.FolioCompra = int.Parse(txtFolioCompraC.Text);
                            comp.Tienda = cmbTiendaC.Text;
                            comp.Empleado = cmbEmpleadoC.Text;
                            comp.TipoPago = cmbTipoPagoC.Text;

                            comp.FechaCompra = dtpFechaC.Value.Year + "-" + dtpFechaC.Value.Month + "-" + dtpFechaC.Value.Day;

                            mibase.agregarUsandoParametros(comp);

                            dgvListaC.DataSource = null;
                            dgvListaC.DataSource = com;



                            foreach (DetalleCompra obj in com)
                            {
                                mibase.agregarUsandoParametros2(obj);
                            }
                            MessageBox.Show("Se agrego con éxito", "Compras ♥");

                            //   DetalleCompra detalle = new DetalleCompra();
                            //    detalle.Codigo = int.Parse(txtCodigoC.Text);
                            //   detalle.Producto = cmbProductoC.Text;
                            //   detalle.PrecioCompra = float.Parse(txtPrecioCompraC.Text);
                            //   detalle.PrecioVenta = float.Parse(txtPrecioVentaC.Text);
                            //      detalle.Cantidad = int.Parse(txtCantidadC.Text);
                            //      detalle.TotalCompra = float.Parse(txtTotalCompraC.Text);
                            //      detalle.PrecioVenta = float.Parse(txtPrecioVentaC.Text);
                            //        detalle.Utilidad = float.Parse(txtUtilidadC.Text);

                            //        com.Add(detalle);
                            //        dgvListaC.DataSource = null;
                            //         dgvListaC.DataSource = com;





                            // DataTable datos = mibase.ConsultarTodos();

                            //Pone los datos en la consulta
                            txtFolioCompraC.Text = "";
                            cmbTiendaC.Text = "";
                            cmbTipoPagoC.Text = "";
                            cmbProductoC.Text = "";
                            cmbEmpleadoC.Text = "";
                            txtCodigoC.Text = "";
                            dtpFechaC.Text = "";
                            txtPrecioCompraC.Text = "";
                            dgvListaC.DataSource = null;
                            txtCantidadC.Text = "";
                            txtTotalCompraC.Text = "";
                           
                         


                        }
                    }
                }
            }
        }

        private void btnBuscarC_Click(object sender, EventArgs e)
        {
           DBCompras miBase = new DBCompras();



            if (txtFolioCompraC.Text != "")
            {
                DataTable datos = miBase.Consultar(int.Parse(txtFolioCompraC.Text));
                DataTable datos2 = miBase.Consultar2(int.Parse(txtFolioCompraC.Text));
                if (datos.Rows.Count > 0)
                {
                    
                   
                 

                    DataTable datosEsp2 = miBase.ConsultarTodos3();
                    cmbEmpleadoC.DataSource = datosEsp2;
                    cmbEmpleadoC.DisplayMember = "nombre";
                    cmbEmpleadoC.ValueMember = "idEmpleado";
                  

                  
                    DataTable datosEsp3 = miBase.ConsultarTodos4();
                    cmbTipoPagoC.DataSource = datosEsp3;
                    cmbTipoPagoC.DisplayMember = "descripcion";
                    cmbTipoPagoC.ValueMember = "idTipoPago";
                 

                   
                    DataTable datosEsp4 = miBase.ConsultarTodos5();
                    cmbTiendaC.DataSource = datosEsp4;
                    cmbTiendaC.DisplayMember = "nombre";
                    cmbTiendaC.ValueMember = "idTienda";


                   cmbEmpleadoC.Text = datos.Rows[0]["empleado"].ToString();
                    cmbTiendaC.Text = datos.Rows[0]["tienda"].ToString();
                    cmbTipoPagoC.Text = datos.Rows[0]["tipoPago"].ToString();
                    dtpFechaC.Text = datos.Rows[0]["fechaCompra"].ToString();


                   
                  //  DataTable datosEsp = miBase.ConsultarTodosProductos();
               //     cmbProductoC.DataSource = datosEsp;
               //     cmbProductoC.DisplayMember = "descripcion";
                //    cmbProductoC.ValueMember = "idproducto";
                  //  txtCodigoC.Text = datos.Rows[0]["codigo"].ToString();
                 //   txtPrecioCompraC.Text = datos.Rows[0]["precioCompra"].ToString();
                 //   txtCantidadC.Text = datos.Rows[0]["cantidad"].ToString();
                 //   txtTotalCompraC.Text = datos.Rows[0]["totalCompra"].ToString();
                   
                    //cmbEmpleadoC.SelectedValue = datos.Rows[0]["empleado"].ToString();
                    // cmbTiendaC.SelectedValue = datos.Rows[0]["tienda"].ToString();
                    //  cmbTipoPagoC.SelectedValue = datos.Rows[0]["tipoPago"].ToString();
                    //   dtpFechaC.Text = datos.Rows[0]["fechaCompra"].ToString();

                    dgvListaC.DataSource = null;
                    dgvListaC.DataSource = datos2;
                    btnBorrarC.Enabled = false;
                    btnGuardarC.Enabled = false;

                }

                else
                {
                    MessageBox.Show("No hay registro con ese Folio", "Compras ♥");
                }

            }
            else
            {
                MessageBox.Show("Faltó capturar el Folio", "Compras ♥");
                txtFolioCompraC.Focus();
            }


        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }
          private void calcularCompra ()
        {
            float totCompra = 0;

            foreach(DetalleCompra item in com)
            {
                totCompra = totCompra + item.PrecioCompra * item.Cantidad;
            }

            txtTotalCompraC.Text = totCompra.ToString();
        }
    }
}
