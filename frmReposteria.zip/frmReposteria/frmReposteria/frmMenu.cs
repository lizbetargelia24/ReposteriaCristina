﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmReposteria
{
    public partial class frmMenu : Form
    {
        public frmMenu()
        {
            InitializeComponent();
        }

        private void ventasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmVentas vista = new frmVentas();
            vista.MdiParent = this;
            vista.Show();
        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmTipoProducto vista = new frmTipoProducto ();
            vista.MdiParent = this;
            vista.Show();
        }

        private void frmMenu_Load(object sender, EventArgs e)
        {
            ts.Text = DateTime.Now.ToShortDateString();
        }

        private void tipoDePagoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmTipoPago vista = new frmTipoPago();
            vista.MdiParent = this;
            vista.Show();
        }

        private void clientesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCliente vista = new frmCliente();
            vista.MdiParent = this;
            vista.Show();
        }

        private void empleadoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmEmpleado vista = new frmEmpleado();
            vista.MdiParent = this;
            vista.Show();
        }

        private void productoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmProducto vista = new frmProducto();
            vista.MdiParent = this;
            vista.Show();
        }

        private void tipoDePagoToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            frmPedidos vista = new frmPedidos();
            vista.MdiParent = this;
            vista.Show();
        }

        private void salirToolStripMenuItem3_Click(object sender, EventArgs e)
        {
            frmCompras vista = new frmCompras();
            vista.MdiParent = this;
            vista.Show();
        }

        private void salirToolStripMenuItem5_Click(object sender, EventArgs e)
        {
            frmTienda vista = new frmTienda();
            vista.MdiParent = this;
            vista.Show();
        }

        private void salirToolStripMenuItem7_Click(object sender, EventArgs e)
        {
            DialogResult res = MessageBox.Show("¿Deseas salir del sistema?!", "Menu ♥",
          MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);

            if (DialogResult.Yes == res) this.Close();
        }
    }
}
