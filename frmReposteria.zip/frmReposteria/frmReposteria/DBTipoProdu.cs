﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;
namespace frmReposteria
{
    class DBTipoProdu
    {
        private MySqlConnection conexion;
        private string strConexion;
        private MySqlCommand sqlComando;
        private string strConsulta;
        private MySqlDataAdapter adaptador;

        public DBTipoProdu()
        {
            //Constructor
            conexion = new MySqlConnection();
            strConexion = "Server=localHost;User=root;DataBase=bdreposteria;port=3306;Password=";

            conexion.ConnectionString = strConexion;

            sqlComando = new MySqlCommand();
            adaptador = new MySqlDataAdapter();

        }
        public Boolean abrir()
        {
            Boolean exito = false;

            if (conexion.State == System.Data.ConnectionState.Closed)
            {

                conexion.Open();
                exito = true;

            }



            return exito;
        }
        public Boolean Cerrar()
        {
            Boolean exito = false;

            if (conexion.State == System.Data.ConnectionState.Closed)
            {

                exito = false;
            }
            else
            {
                conexion.Close();
                exito = true;
            }
            return exito;
        }
        // public Boolean Cerrar()
        // {
        //    Boolean exito = false;
        //    if (conexion.State == ConnectionState.Closed)
        //    {
        //    conexion.Close();
        //   exito = true;
        // }
        // return exito;
        // }


        //Agregar sin parametros
        public void agregarSinParsametros(TipoProducto obj)
        {
            string sqlConsulta = "insert into ttipoproducto(idTipoProducto,clave,nombre, foto,status) values (null," + obj.Clave + "," + obj.Nombre + ",0)";
            this.abrir();
            sqlComando.Connection = conexion;
            sqlComando.CommandText = sqlConsulta;

            sqlComando.ExecuteNonQuery();
            this.Cerrar();
        }
        //Agregar usando parametros
        public void agregarUsandoParametros(TipoProducto obj)
        {
            string sqlConsulta = "insert into ttipoproducto (idTipoProducto,clave,nombre,foto,status)values(null, ?pclave, ?pnombre,?pfoto,0)";
            sqlComando.Parameters.Clear();

            sqlComando.Parameters.Add("?pclave", MySql.Data.MySqlClient.MySqlDbType.Int32).Value = obj.Clave;
       
            sqlComando.Parameters.Add("?pnombre", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Nombre;
            sqlComando.Parameters.Add("?pfoto", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Foto;
            this.abrir();
            sqlComando.Connection = conexion;
            sqlComando.CommandText = sqlConsulta;

            sqlComando.ExecuteNonQuery();
            this.Cerrar();

        }
        //Actualizar
        public void Actualizar(TipoProducto obj)
        {
            string sqlConsulta = "Update ttipoproducto set nombre = ?pnombre, foto = ?pfoto where clave= ?pclave and status=0";
            sqlComando.Parameters.Clear();

            sqlComando.Parameters.Add("?pclave", MySql.Data.MySqlClient.MySqlDbType.UInt32).Value = obj.Clave;
       
            sqlComando.Parameters.Add("?pnombre", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Nombre;
            sqlComando.Parameters.Add("?pfoto", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Foto;
            this.abrir();
            sqlComando.Connection = conexion;
            sqlComando.CommandText = sqlConsulta;

            sqlComando.ExecuteNonQuery();
            this.Cerrar();
        }
        //Deshabilitar
        public void Deshabilitar(TipoProducto obj)
        {
            string sqlConsulta = "update ttipoproducto set status=1 where clave= ?pclave and status=0";
            sqlComando.Parameters.Clear();

            sqlComando.Parameters.Add("?pclave", MySql.Data.MySqlClient.MySqlDbType.Int32).Value = obj.Clave;


            this.abrir();
            sqlComando.Connection = conexion;
            sqlComando.CommandText = sqlConsulta;

            sqlComando.ExecuteNonQuery();
            this.Cerrar();
        }
        //Consultar
        public DataTable Consultar(int Clave)
        {
            DataTable datos = new DataTable();
            strConsulta = "select *from ttipoproducto where status = 0 and clave =" + Clave;

            this.abrir();
            sqlComando.CommandText = strConsulta;
            sqlComando.Connection = conexion;
            adaptador.SelectCommand = sqlComando;
            adaptador.Fill(datos);

            this.Cerrar();

            return datos;
        }
        //Metodo consultar todos
        public DataTable ConsultarTodos()
        {
            DataTable datos = new DataTable();
            strConsulta = "select *from ttipoproducto where status = 0 order by clave asc";
            abrir();
            sqlComando.CommandText = strConsulta;
            sqlComando.Connection = conexion;

            adaptador.SelectCommand = sqlComando;
            adaptador.Fill(datos);
            this.Cerrar();
            return datos;
        }
        public DataTable ConsultarTodosDeshabilitar()
        {
            DataTable datos = new DataTable();
            strConsulta = "select *from ttipoproducto where status = 1 order by clave asc";
            abrir();
            sqlComando.CommandText = strConsulta;
            sqlComando.Connection = conexion;

            adaptador.SelectCommand = sqlComando;
            adaptador.Fill(datos);
            Cerrar();
            return datos;
        }
        public void Habilitar(TipoProducto obj)
        {
            string sqlConsulta = "update ttipoproducto set status=0 where clave = ?pclave and status = 1";
            sqlComando.Parameters.Clear();

            sqlComando.Parameters.Add("?pclave", MySql.Data.MySqlClient.MySqlDbType.Int32).Value = obj.Clave;

            this.abrir();
            sqlComando.Connection = conexion;
            sqlComando.CommandText = sqlConsulta;

            sqlComando.ExecuteNonQuery();
            this.Cerrar();
        }
        public DataTable ConsultarH(int Clave)
        {
            DataTable datos = new DataTable();
            strConsulta = "select * from ttipoproducto where status = 1 and clave =" + Clave;

            this.abrir();
            sqlComando.CommandText = strConsulta;
            sqlComando.Connection = conexion;
            adaptador.SelectCommand = sqlComando;
            adaptador.Fill(datos);

            this.Cerrar();

            return datos;
        }
        
    }
}
