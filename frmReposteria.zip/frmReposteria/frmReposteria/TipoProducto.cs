﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace frmReposteria
{
    class TipoProducto : Producto
    {
        private int idTipoProducto;
        private string nombre;
        private string tipoDProducto;
        private int statusTP;

        public TipoProducto()
        {
            idTipoProducto = generaIdTipoProducto();
            this.nombre = "";
            this.tipoDProducto = "";
            this.status = 0;
        }
        public TipoProducto(int idProducto, string nombreProducto,
             string descripcion, int status, float precioVenta, float precioCompra, string unidadProducto, string foto,int clave, int idTipoProducto, string nombre,int tipoDProducto, int statusTP ) : base(idProducto, nombreProducto,
              descripcion, status, precioVenta,precioCompra, unidadProducto, foto, clave)
        {
            this.idTipoProducto = idTipoProducto;
            this.nombre = nombre;
        }

        public int IdTipoProducto
        {
            set { this.idTipoProducto = value; }
            get { return this.idTipoProducto; }
        }
        public int generaIdTipoProducto()
        {
            //genera valores aleatorios enteros positivos no mayores a 32000
            Random x = new Random();
            return x.Next(32000);
        }
        public string TipoDProducto
        {
            set { this.tipoDProducto = value; }
            get { return this.tipoDProducto; }
        }
        public string Nombre
        {
            set { this.nombre = value; }
            get { return this.nombre; }
        }
        public int StatusTP
        {
            set { this.statusTP = value; }
            get { return this.statusTP; }
        }
    }
}
