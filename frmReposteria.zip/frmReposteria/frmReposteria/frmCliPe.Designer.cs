﻿namespace frmReposteria
{
    partial class frmCliPe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Cliente = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.txtClaveC = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.txtFotoC = new System.Windows.Forms.TextBox();
            this.ptbFotoC = new System.Windows.Forms.PictureBox();
            this.btnFotoC = new System.Windows.Forms.Button();
            this.txtCurpC = new System.Windows.Forms.TextBox();
            this.btnBuscarC = new System.Windows.Forms.Button();
            this.cmbStatusC = new System.Windows.Forms.ComboBox();
            this.btnCancelarC = new System.Windows.Forms.Button();
            this.btnLimpiarC = new System.Windows.Forms.Button();
            this.btnCerrarC = new System.Windows.Forms.Button();
            this.btnBorrarC = new System.Windows.Forms.Button();
            this.btnModificarC = new System.Windows.Forms.Button();
            this.btnGuardarC = new System.Windows.Forms.Button();
            this.btnNuevoC = new System.Windows.Forms.Button();
            this.dbgListaC = new System.Windows.Forms.DataGridView();
            this.txtCodigoPostC = new System.Windows.Forms.TextBox();
            this.txtNumeroC = new System.Windows.Forms.TextBox();
            this.txtCalleC = new System.Windows.Forms.TextBox();
            this.txtColoniaC = new System.Windows.Forms.TextBox();
            this.txtApellidoPatC = new System.Windows.Forms.TextBox();
            this.txtApellidoMatC = new System.Windows.Forms.TextBox();
            this.txtTelefonoC = new System.Windows.Forms.TextBox();
            this.txtCorreoC = new System.Windows.Forms.TextBox();
            this.txtNombreC = new System.Windows.Forms.TextBox();
            this.txtIdClienteC = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.txtClaveP = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.txtFotoP = new System.Windows.Forms.TextBox();
            this.btnFotoP = new System.Windows.Forms.Button();
            this.txtCurpP = new System.Windows.Forms.TextBox();
            this.cmbStatusCP = new System.Windows.Forms.ComboBox();
            this.txtCodigoPostP = new System.Windows.Forms.TextBox();
            this.txtNumeroP = new System.Windows.Forms.TextBox();
            this.txtCalleP = new System.Windows.Forms.TextBox();
            this.txtColoniaP = new System.Windows.Forms.TextBox();
            this.txtApellidoPatP = new System.Windows.Forms.TextBox();
            this.txtApellidoMatP = new System.Windows.Forms.TextBox();
            this.txtTelefonoP = new System.Windows.Forms.TextBox();
            this.txtCorreoP = new System.Windows.Forms.TextBox();
            this.txtNombreP = new System.Windows.Forms.TextBox();
            this.txtIdClienteP = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.dtpFechaP = new System.Windows.Forms.DateTimePicker();
            this.cmbStatusP = new System.Windows.Forms.ComboBox();
            this.txtAnticipoP = new System.Windows.Forms.TextBox();
            this.txtDescripcionP = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dgvListaP = new System.Windows.Forms.DataGridView();
            this.txtIdPedidosP = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.ptbFotoP = new System.Windows.Forms.PictureBox();
            this.btnBuscarP = new System.Windows.Forms.Button();
            this.btnSalirP = new System.Windows.Forms.Button();
            this.btnCancelarP = new System.Windows.Forms.Button();
            this.btnLimpiarP = new System.Windows.Forms.Button();
            this.btnBorrarP = new System.Windows.Forms.Button();
            this.btnModificarP = new System.Windows.Forms.Button();
            this.btnGuardarP = new System.Windows.Forms.Button();
            this.btnNuevoP = new System.Windows.Forms.Button();
            this.Cliente.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptbFotoC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbgListaC)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptbFotoP)).BeginInit();
            this.SuspendLayout();
            // 
            // Cliente
            // 
            this.Cliente.Controls.Add(this.tabPage1);
            this.Cliente.Controls.Add(this.tabPage2);
            this.Cliente.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cliente.Location = new System.Drawing.Point(23, 12);
            this.Cliente.Name = "Cliente";
            this.Cliente.SelectedIndex = 0;
            this.Cliente.Size = new System.Drawing.Size(691, 478);
            this.Cliente.TabIndex = 89;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tabPage1.Controls.Add(this.txtClaveC);
            this.tabPage1.Controls.Add(this.label31);
            this.tabPage1.Controls.Add(this.txtFotoC);
            this.tabPage1.Controls.Add(this.ptbFotoC);
            this.tabPage1.Controls.Add(this.btnFotoC);
            this.tabPage1.Controls.Add(this.txtCurpC);
            this.tabPage1.Controls.Add(this.btnBuscarC);
            this.tabPage1.Controls.Add(this.cmbStatusC);
            this.tabPage1.Controls.Add(this.btnCancelarC);
            this.tabPage1.Controls.Add(this.btnLimpiarC);
            this.tabPage1.Controls.Add(this.btnCerrarC);
            this.tabPage1.Controls.Add(this.btnBorrarC);
            this.tabPage1.Controls.Add(this.btnModificarC);
            this.tabPage1.Controls.Add(this.btnGuardarC);
            this.tabPage1.Controls.Add(this.btnNuevoC);
            this.tabPage1.Controls.Add(this.dbgListaC);
            this.tabPage1.Controls.Add(this.txtCodigoPostC);
            this.tabPage1.Controls.Add(this.txtNumeroC);
            this.tabPage1.Controls.Add(this.txtCalleC);
            this.tabPage1.Controls.Add(this.txtColoniaC);
            this.tabPage1.Controls.Add(this.txtApellidoPatC);
            this.tabPage1.Controls.Add(this.txtApellidoMatC);
            this.tabPage1.Controls.Add(this.txtTelefonoC);
            this.tabPage1.Controls.Add(this.txtCorreoC);
            this.tabPage1.Controls.Add(this.txtNombreC);
            this.tabPage1.Controls.Add(this.txtIdClienteC);
            this.tabPage1.Controls.Add(this.label13);
            this.tabPage1.Controls.Add(this.label12);
            this.tabPage1.Controls.Add(this.label11);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.label14);
            this.tabPage1.Controls.Add(this.label15);
            this.tabPage1.Controls.Add(this.label16);
            this.tabPage1.Controls.Add(this.label17);
            this.tabPage1.Controls.Add(this.label18);
            this.tabPage1.Location = new System.Drawing.Point(4, 24);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(683, 450);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Clientes";
            // 
            // txtClaveC
            // 
            this.txtClaveC.Enabled = false;
            this.txtClaveC.Location = new System.Drawing.Point(29, 29);
            this.txtClaveC.MaxLength = 10;
            this.txtClaveC.Name = "txtClaveC";
            this.txtClaveC.Size = new System.Drawing.Size(100, 23);
            this.txtClaveC.TabIndex = 2;
            this.txtClaveC.TextChanged += new System.EventHandler(this.txtClaveC_TextChanged);
            this.txtClaveC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtClaveC_KeyPress);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label31.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(26, 10);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(35, 16);
            this.label31.TabIndex = 76;
            this.label31.Text = "Clave";
            // 
            // txtFotoC
            // 
            this.txtFotoC.Enabled = false;
            this.txtFotoC.Location = new System.Drawing.Point(558, 375);
            this.txtFotoC.Name = "txtFotoC";
            this.txtFotoC.Size = new System.Drawing.Size(100, 23);
            this.txtFotoC.TabIndex = 74;
            // 
            // ptbFotoC
            // 
            this.ptbFotoC.Image = global::frmReposteria.Properties.Resources.imagen;
            this.ptbFotoC.Location = new System.Drawing.Point(558, 203);
            this.ptbFotoC.Name = "ptbFotoC";
            this.ptbFotoC.Size = new System.Drawing.Size(100, 135);
            this.ptbFotoC.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ptbFotoC.TabIndex = 73;
            this.ptbFotoC.TabStop = false;
            // 
            // btnFotoC
            // 
            this.btnFotoC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnFotoC.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnFotoC.Location = new System.Drawing.Point(558, 344);
            this.btnFotoC.Name = "btnFotoC";
            this.btnFotoC.Size = new System.Drawing.Size(32, 24);
            this.btnFotoC.TabIndex = 15;
            this.btnFotoC.Text = "...";
            this.btnFotoC.UseVisualStyleBackColor = false;
            this.btnFotoC.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // txtCurpC
            // 
            this.txtCurpC.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtCurpC.Enabled = false;
            this.txtCurpC.Location = new System.Drawing.Point(29, 269);
            this.txtCurpC.MaxLength = 25;
            this.txtCurpC.Name = "txtCurpC";
            this.txtCurpC.Size = new System.Drawing.Size(100, 23);
            this.txtCurpC.TabIndex = 7;
            // 
            // btnBuscarC
            // 
            this.btnBuscarC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnBuscarC.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBuscarC.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscarC.Image = global::frmReposteria.Properties.Resources.buscar;
            this.btnBuscarC.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBuscarC.Location = new System.Drawing.Point(155, 15);
            this.btnBuscarC.Name = "btnBuscarC";
            this.btnBuscarC.Size = new System.Drawing.Size(75, 32);
            this.btnBuscarC.TabIndex = 17;
            this.btnBuscarC.Text = "Buscar";
            this.btnBuscarC.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBuscarC.UseVisualStyleBackColor = false;
            this.btnBuscarC.Click += new System.EventHandler(this.btnBuscarC_Click);
            // 
            // cmbStatusC
            // 
            this.cmbStatusC.Enabled = false;
            this.cmbStatusC.FormattingEnabled = true;
            this.cmbStatusC.Items.AddRange(new object[] {
            "No Existente",
            "Existente"});
            this.cmbStatusC.Location = new System.Drawing.Point(285, 310);
            this.cmbStatusC.Name = "cmbStatusC";
            this.cmbStatusC.Size = new System.Drawing.Size(121, 23);
            this.cmbStatusC.TabIndex = 14;
            this.cmbStatusC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbStatusC_KeyPress);
            // 
            // btnCancelarC
            // 
            this.btnCancelarC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnCancelarC.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCancelarC.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelarC.Image = global::frmReposteria.Properties.Resources.prohibido__1_;
            this.btnCancelarC.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCancelarC.Location = new System.Drawing.Point(109, 305);
            this.btnCancelarC.Name = "btnCancelarC";
            this.btnCancelarC.Size = new System.Drawing.Size(75, 33);
            this.btnCancelarC.TabIndex = 20;
            this.btnCancelarC.Text = "Cancelar";
            this.btnCancelarC.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCancelarC.UseVisualStyleBackColor = false;
            this.btnCancelarC.Click += new System.EventHandler(this.btnCancelarC_Click);
            // 
            // btnLimpiarC
            // 
            this.btnLimpiarC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnLimpiarC.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnLimpiarC.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpiarC.Image = global::frmReposteria.Properties.Resources.escoba_de_limpieza_para_suelos__1_;
            this.btnLimpiarC.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLimpiarC.Location = new System.Drawing.Point(28, 305);
            this.btnLimpiarC.Name = "btnLimpiarC";
            this.btnLimpiarC.Size = new System.Drawing.Size(75, 33);
            this.btnLimpiarC.TabIndex = 19;
            this.btnLimpiarC.Text = "Limpiar";
            this.btnLimpiarC.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLimpiarC.UseVisualStyleBackColor = false;
            this.btnLimpiarC.Click += new System.EventHandler(this.btnLimpiarC_Click);
            // 
            // btnCerrarC
            // 
            this.btnCerrarC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnCerrarC.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCerrarC.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCerrarC.Image = global::frmReposteria.Properties.Resources.salir_3;
            this.btnCerrarC.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCerrarC.Location = new System.Drawing.Point(190, 305);
            this.btnCerrarC.Name = "btnCerrarC";
            this.btnCerrarC.Size = new System.Drawing.Size(66, 33);
            this.btnCerrarC.TabIndex = 22;
            this.btnCerrarC.Text = "Cerrar";
            this.btnCerrarC.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCerrarC.UseVisualStyleBackColor = false;
            this.btnCerrarC.Click += new System.EventHandler(this.btnCerrarC_Click);
            // 
            // btnBorrarC
            // 
            this.btnBorrarC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnBorrarC.Enabled = false;
            this.btnBorrarC.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBorrarC.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBorrarC.Image = global::frmReposteria.Properties.Resources.cubo_de_basura;
            this.btnBorrarC.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBorrarC.Location = new System.Drawing.Point(588, 149);
            this.btnBorrarC.Name = "btnBorrarC";
            this.btnBorrarC.Size = new System.Drawing.Size(70, 35);
            this.btnBorrarC.TabIndex = 21;
            this.btnBorrarC.Text = "Borrar";
            this.btnBorrarC.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBorrarC.UseVisualStyleBackColor = false;
            this.btnBorrarC.Click += new System.EventHandler(this.btnBorrar_Click);
            // 
            // btnModificarC
            // 
            this.btnModificarC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnModificarC.Enabled = false;
            this.btnModificarC.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnModificarC.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnModificarC.Image = global::frmReposteria.Properties.Resources.herramientas_del_empleado_de_mantenimiento;
            this.btnModificarC.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnModificarC.Location = new System.Drawing.Point(567, 109);
            this.btnModificarC.Name = "btnModificarC";
            this.btnModificarC.Size = new System.Drawing.Size(91, 34);
            this.btnModificarC.TabIndex = 18;
            this.btnModificarC.Text = "Modificar";
            this.btnModificarC.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnModificarC.UseVisualStyleBackColor = false;
            this.btnModificarC.Click += new System.EventHandler(this.btnModificarC_Click);
            // 
            // btnGuardarC
            // 
            this.btnGuardarC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnGuardarC.Enabled = false;
            this.btnGuardarC.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnGuardarC.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGuardarC.Image = global::frmReposteria.Properties.Resources.guardar2;
            this.btnGuardarC.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGuardarC.Location = new System.Drawing.Point(575, 66);
            this.btnGuardarC.Name = "btnGuardarC";
            this.btnGuardarC.Size = new System.Drawing.Size(83, 35);
            this.btnGuardarC.TabIndex = 16;
            this.btnGuardarC.Text = "Guardar";
            this.btnGuardarC.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnGuardarC.UseVisualStyleBackColor = false;
            this.btnGuardarC.Click += new System.EventHandler(this.btnGuardarC_Click);
            // 
            // btnNuevoC
            // 
            this.btnNuevoC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnNuevoC.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNuevoC.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNuevoC.Image = global::frmReposteria.Properties.Resources.agregar_usuario;
            this.btnNuevoC.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNuevoC.Location = new System.Drawing.Point(583, 23);
            this.btnNuevoC.Name = "btnNuevoC";
            this.btnNuevoC.Size = new System.Drawing.Size(75, 32);
            this.btnNuevoC.TabIndex = 1;
            this.btnNuevoC.Text = "Nuevo";
            this.btnNuevoC.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNuevoC.UseVisualStyleBackColor = false;
            this.btnNuevoC.Click += new System.EventHandler(this.btnNuevoC_Click);
            // 
            // dbgListaC
            // 
            this.dbgListaC.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.dbgListaC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dbgListaC.Location = new System.Drawing.Point(29, 344);
            this.dbgListaC.Name = "dbgListaC";
            this.dbgListaC.Size = new System.Drawing.Size(467, 93);
            this.dbgListaC.TabIndex = 60;
            // 
            // txtCodigoPostC
            // 
            this.txtCodigoPostC.Enabled = false;
            this.txtCodigoPostC.Location = new System.Drawing.Point(285, 263);
            this.txtCodigoPostC.MaxLength = 10;
            this.txtCodigoPostC.Name = "txtCodigoPostC";
            this.txtCodigoPostC.Size = new System.Drawing.Size(100, 23);
            this.txtCodigoPostC.TabIndex = 13;
            this.txtCodigoPostC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCodigoPostC_KeyPress);
            // 
            // txtNumeroC
            // 
            this.txtNumeroC.Enabled = false;
            this.txtNumeroC.Location = new System.Drawing.Point(285, 216);
            this.txtNumeroC.MaxLength = 25;
            this.txtNumeroC.Name = "txtNumeroC";
            this.txtNumeroC.Size = new System.Drawing.Size(100, 23);
            this.txtNumeroC.TabIndex = 12;
            this.txtNumeroC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumeroC_KeyPress);
            // 
            // txtCalleC
            // 
            this.txtCalleC.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtCalleC.Enabled = false;
            this.txtCalleC.Location = new System.Drawing.Point(285, 171);
            this.txtCalleC.MaxLength = 45;
            this.txtCalleC.Name = "txtCalleC";
            this.txtCalleC.Size = new System.Drawing.Size(100, 23);
            this.txtCalleC.TabIndex = 11;
            // 
            // txtColoniaC
            // 
            this.txtColoniaC.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtColoniaC.Enabled = false;
            this.txtColoniaC.Location = new System.Drawing.Point(285, 122);
            this.txtColoniaC.MaxLength = 45;
            this.txtColoniaC.Name = "txtColoniaC";
            this.txtColoniaC.Size = new System.Drawing.Size(100, 23);
            this.txtColoniaC.TabIndex = 10;
            // 
            // txtApellidoPatC
            // 
            this.txtApellidoPatC.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtApellidoPatC.Enabled = false;
            this.txtApellidoPatC.Location = new System.Drawing.Point(29, 222);
            this.txtApellidoPatC.MaxLength = 45;
            this.txtApellidoPatC.Name = "txtApellidoPatC";
            this.txtApellidoPatC.Size = new System.Drawing.Size(100, 23);
            this.txtApellidoPatC.TabIndex = 6;
            // 
            // txtApellidoMatC
            // 
            this.txtApellidoMatC.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtApellidoMatC.Enabled = false;
            this.txtApellidoMatC.Location = new System.Drawing.Point(29, 174);
            this.txtApellidoMatC.MaxLength = 45;
            this.txtApellidoMatC.Name = "txtApellidoMatC";
            this.txtApellidoMatC.Size = new System.Drawing.Size(100, 23);
            this.txtApellidoMatC.TabIndex = 5;
            // 
            // txtTelefonoC
            // 
            this.txtTelefonoC.Enabled = false;
            this.txtTelefonoC.Location = new System.Drawing.Point(285, 78);
            this.txtTelefonoC.MaxLength = 25;
            this.txtTelefonoC.Name = "txtTelefonoC";
            this.txtTelefonoC.Size = new System.Drawing.Size(100, 23);
            this.txtTelefonoC.TabIndex = 9;
            this.txtTelefonoC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTelefonoC_KeyPress);
            // 
            // txtCorreoC
            // 
            this.txtCorreoC.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtCorreoC.Enabled = false;
            this.txtCorreoC.Location = new System.Drawing.Point(285, 27);
            this.txtCorreoC.MaxLength = 25;
            this.txtCorreoC.Name = "txtCorreoC";
            this.txtCorreoC.Size = new System.Drawing.Size(100, 23);
            this.txtCorreoC.TabIndex = 8;
            // 
            // txtNombreC
            // 
            this.txtNombreC.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtNombreC.Enabled = false;
            this.txtNombreC.Location = new System.Drawing.Point(29, 123);
            this.txtNombreC.MaxLength = 45;
            this.txtNombreC.Name = "txtNombreC";
            this.txtNombreC.Size = new System.Drawing.Size(100, 23);
            this.txtNombreC.TabIndex = 4;
            // 
            // txtIdClienteC
            // 
            this.txtIdClienteC.Enabled = false;
            this.txtIdClienteC.Location = new System.Drawing.Point(29, 75);
            this.txtIdClienteC.MaxLength = 10;
            this.txtIdClienteC.Name = "txtIdClienteC";
            this.txtIdClienteC.Size = new System.Drawing.Size(100, 23);
            this.txtIdClienteC.TabIndex = 3;
            this.txtIdClienteC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIdClienteC_KeyPress);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label13.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(282, 291);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(40, 16);
            this.label13.TabIndex = 49;
            this.label13.Text = "status";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label12.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(282, 242);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(78, 16);
            this.label12.TabIndex = 48;
            this.label12.Text = "Codigo Postal";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label11.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(282, 197);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(49, 16);
            this.label11.TabIndex = 47;
            this.label11.Text = "Numero";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label10.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(282, 151);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(33, 16);
            this.label10.TabIndex = 46;
            this.label10.Text = "Calle";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label9.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(282, 103);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(45, 16);
            this.label9.TabIndex = 45;
            this.label9.Text = "Colonia";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label8.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(26, 103);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(50, 16);
            this.label8.TabIndex = 44;
            this.label8.Text = "Nombre";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(32, 319);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 15);
            this.label7.TabIndex = 43;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label6.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(26, 202);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(94, 16);
            this.label6.TabIndex = 42;
            this.label6.Text = "Apellido Paterno";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label14.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(26, 152);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(99, 16);
            this.label14.TabIndex = 41;
            this.label14.Text = "Apellido Materno";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label15.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(282, 57);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(55, 16);
            this.label15.TabIndex = 40;
            this.label15.Text = "Telefono";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label16.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(282, 7);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(43, 16);
            this.label16.TabIndex = 39;
            this.label16.Text = "Correo";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label17.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(26, 250);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(32, 16);
            this.label17.TabIndex = 38;
            this.label17.Text = "Curp";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label18.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(26, 56);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(56, 16);
            this.label18.TabIndex = 37;
            this.label18.Text = "IdCliente";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tabPage2.Controls.Add(this.txtClaveP);
            this.tabPage2.Controls.Add(this.label32);
            this.tabPage2.Controls.Add(this.txtFotoP);
            this.tabPage2.Controls.Add(this.btnFotoP);
            this.tabPage2.Controls.Add(this.txtCurpP);
            this.tabPage2.Controls.Add(this.cmbStatusCP);
            this.tabPage2.Controls.Add(this.txtCodigoPostP);
            this.tabPage2.Controls.Add(this.txtNumeroP);
            this.tabPage2.Controls.Add(this.txtCalleP);
            this.tabPage2.Controls.Add(this.txtColoniaP);
            this.tabPage2.Controls.Add(this.txtApellidoPatP);
            this.tabPage2.Controls.Add(this.txtApellidoMatP);
            this.tabPage2.Controls.Add(this.txtTelefonoP);
            this.tabPage2.Controls.Add(this.txtCorreoP);
            this.tabPage2.Controls.Add(this.txtNombreP);
            this.tabPage2.Controls.Add(this.txtIdClienteP);
            this.tabPage2.Controls.Add(this.label19);
            this.tabPage2.Controls.Add(this.label20);
            this.tabPage2.Controls.Add(this.label21);
            this.tabPage2.Controls.Add(this.label22);
            this.tabPage2.Controls.Add(this.label23);
            this.tabPage2.Controls.Add(this.label24);
            this.tabPage2.Controls.Add(this.label25);
            this.tabPage2.Controls.Add(this.label26);
            this.tabPage2.Controls.Add(this.label27);
            this.tabPage2.Controls.Add(this.label28);
            this.tabPage2.Controls.Add(this.label29);
            this.tabPage2.Controls.Add(this.label30);
            this.tabPage2.Controls.Add(this.dtpFechaP);
            this.tabPage2.Controls.Add(this.cmbStatusP);
            this.tabPage2.Controls.Add(this.txtAnticipoP);
            this.tabPage2.Controls.Add(this.txtDescripcionP);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.dgvListaP);
            this.tabPage2.Controls.Add(this.txtIdPedidosP);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.ptbFotoP);
            this.tabPage2.Controls.Add(this.btnBuscarP);
            this.tabPage2.Controls.Add(this.btnSalirP);
            this.tabPage2.Controls.Add(this.btnCancelarP);
            this.tabPage2.Controls.Add(this.btnLimpiarP);
            this.tabPage2.Controls.Add(this.btnBorrarP);
            this.tabPage2.Controls.Add(this.btnModificarP);
            this.tabPage2.Controls.Add(this.btnGuardarP);
            this.tabPage2.Controls.Add(this.btnNuevoP);
            this.tabPage2.Location = new System.Drawing.Point(4, 24);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(683, 450);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Pedidos";
            // 
            // txtClaveP
            // 
            this.txtClaveP.Enabled = false;
            this.txtClaveP.Location = new System.Drawing.Point(16, 29);
            this.txtClaveP.MaxLength = 10;
            this.txtClaveP.Name = "txtClaveP";
            this.txtClaveP.Size = new System.Drawing.Size(100, 23);
            this.txtClaveP.TabIndex = 2;
            this.txtClaveP.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtClaveP_KeyPress);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label32.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(13, 10);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(35, 16);
            this.label32.TabIndex = 137;
            this.label32.Text = "Clave";
            // 
            // txtFotoP
            // 
            this.txtFotoP.Enabled = false;
            this.txtFotoP.Location = new System.Drawing.Point(559, 360);
            this.txtFotoP.MaxLength = 10;
            this.txtFotoP.Name = "txtFotoP";
            this.txtFotoP.Size = new System.Drawing.Size(100, 23);
            this.txtFotoP.TabIndex = 135;
            // 
            // btnFotoP
            // 
            this.btnFotoP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnFotoP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnFotoP.Location = new System.Drawing.Point(559, 330);
            this.btnFotoP.Name = "btnFotoP";
            this.btnFotoP.Size = new System.Drawing.Size(32, 24);
            this.btnFotoP.TabIndex = 20;
            this.btnFotoP.Text = "...";
            this.btnFotoP.UseVisualStyleBackColor = false;
            this.btnFotoP.Click += new System.EventHandler(this.btnFotoP_Click);
            // 
            // txtCurpP
            // 
            this.txtCurpP.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtCurpP.Enabled = false;
            this.txtCurpP.Location = new System.Drawing.Point(16, 278);
            this.txtCurpP.MaxLength = 25;
            this.txtCurpP.Name = "txtCurpP";
            this.txtCurpP.Size = new System.Drawing.Size(100, 23);
            this.txtCurpP.TabIndex = 7;
            // 
            // cmbStatusCP
            // 
            this.cmbStatusCP.Enabled = false;
            this.cmbStatusCP.FormattingEnabled = true;
            this.cmbStatusCP.Items.AddRange(new object[] {
            "No Existente",
            "Existente"});
            this.cmbStatusCP.Location = new System.Drawing.Point(370, 25);
            this.cmbStatusCP.Name = "cmbStatusCP";
            this.cmbStatusCP.Size = new System.Drawing.Size(121, 23);
            this.cmbStatusCP.TabIndex = 14;
            this.cmbStatusCP.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbStatusCP_KeyPress);
            // 
            // txtCodigoPostP
            // 
            this.txtCodigoPostP.Enabled = false;
            this.txtCodigoPostP.Location = new System.Drawing.Point(237, 278);
            this.txtCodigoPostP.MaxLength = 10;
            this.txtCodigoPostP.Name = "txtCodigoPostP";
            this.txtCodigoPostP.Size = new System.Drawing.Size(100, 23);
            this.txtCodigoPostP.TabIndex = 13;
            this.txtCodigoPostP.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCodigoPostP_KeyPress);
            // 
            // txtNumeroP
            // 
            this.txtNumeroP.Enabled = false;
            this.txtNumeroP.Location = new System.Drawing.Point(237, 231);
            this.txtNumeroP.MaxLength = 25;
            this.txtNumeroP.Name = "txtNumeroP";
            this.txtNumeroP.Size = new System.Drawing.Size(100, 23);
            this.txtNumeroP.TabIndex = 12;
            this.txtNumeroP.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumeroP_KeyPress);
            // 
            // txtCalleP
            // 
            this.txtCalleP.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtCalleP.Enabled = false;
            this.txtCalleP.Location = new System.Drawing.Point(237, 186);
            this.txtCalleP.MaxLength = 45;
            this.txtCalleP.Name = "txtCalleP";
            this.txtCalleP.Size = new System.Drawing.Size(100, 23);
            this.txtCalleP.TabIndex = 11;
            // 
            // txtColoniaP
            // 
            this.txtColoniaP.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtColoniaP.Enabled = false;
            this.txtColoniaP.Location = new System.Drawing.Point(237, 136);
            this.txtColoniaP.MaxLength = 45;
            this.txtColoniaP.Name = "txtColoniaP";
            this.txtColoniaP.Size = new System.Drawing.Size(100, 23);
            this.txtColoniaP.TabIndex = 10;
            // 
            // txtApellidoPatP
            // 
            this.txtApellidoPatP.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtApellidoPatP.Enabled = false;
            this.txtApellidoPatP.Location = new System.Drawing.Point(16, 231);
            this.txtApellidoPatP.MaxLength = 45;
            this.txtApellidoPatP.Name = "txtApellidoPatP";
            this.txtApellidoPatP.Size = new System.Drawing.Size(100, 23);
            this.txtApellidoPatP.TabIndex = 6;
            // 
            // txtApellidoMatP
            // 
            this.txtApellidoMatP.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtApellidoMatP.Enabled = false;
            this.txtApellidoMatP.Location = new System.Drawing.Point(16, 181);
            this.txtApellidoMatP.MaxLength = 45;
            this.txtApellidoMatP.Name = "txtApellidoMatP";
            this.txtApellidoMatP.Size = new System.Drawing.Size(100, 23);
            this.txtApellidoMatP.TabIndex = 5;
            // 
            // txtTelefonoP
            // 
            this.txtTelefonoP.Enabled = false;
            this.txtTelefonoP.Location = new System.Drawing.Point(237, 87);
            this.txtTelefonoP.MaxLength = 25;
            this.txtTelefonoP.Name = "txtTelefonoP";
            this.txtTelefonoP.Size = new System.Drawing.Size(100, 23);
            this.txtTelefonoP.TabIndex = 9;
            this.txtTelefonoP.TextChanged += new System.EventHandler(this.txtTelefonoP_TextChanged);
            this.txtTelefonoP.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTelefonoP_KeyPress);
            // 
            // txtCorreoP
            // 
            this.txtCorreoP.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtCorreoP.Enabled = false;
            this.txtCorreoP.Location = new System.Drawing.Point(237, 29);
            this.txtCorreoP.MaxLength = 45;
            this.txtCorreoP.Name = "txtCorreoP";
            this.txtCorreoP.Size = new System.Drawing.Size(100, 23);
            this.txtCorreoP.TabIndex = 8;
            // 
            // txtNombreP
            // 
            this.txtNombreP.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtNombreP.Enabled = false;
            this.txtNombreP.Location = new System.Drawing.Point(16, 130);
            this.txtNombreP.MaxLength = 45;
            this.txtNombreP.Name = "txtNombreP";
            this.txtNombreP.Size = new System.Drawing.Size(100, 23);
            this.txtNombreP.TabIndex = 4;
            // 
            // txtIdClienteP
            // 
            this.txtIdClienteP.Enabled = false;
            this.txtIdClienteP.Location = new System.Drawing.Point(16, 82);
            this.txtIdClienteP.MaxLength = 10;
            this.txtIdClienteP.Name = "txtIdClienteP";
            this.txtIdClienteP.Size = new System.Drawing.Size(100, 23);
            this.txtIdClienteP.TabIndex = 3;
            this.txtIdClienteP.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIdClienteP_KeyPress);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label19.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(367, 6);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(40, 16);
            this.label19.TabIndex = 119;
            this.label19.Text = "status";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label20.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(234, 257);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(78, 16);
            this.label20.TabIndex = 118;
            this.label20.Text = "Codigo Postal";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label21.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(234, 212);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(49, 16);
            this.label21.TabIndex = 117;
            this.label21.Text = "Numero";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label22.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(234, 166);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(33, 16);
            this.label22.TabIndex = 116;
            this.label22.Text = "Calle";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label23.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(234, 117);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(45, 16);
            this.label23.TabIndex = 115;
            this.label23.Text = "Colonia";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label24.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(13, 110);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(50, 16);
            this.label24.TabIndex = 114;
            this.label24.Text = "Nombre";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label25.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(13, 211);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(94, 16);
            this.label25.TabIndex = 113;
            this.label25.Text = "Apellido Paterno";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label26.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(13, 161);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(99, 16);
            this.label26.TabIndex = 112;
            this.label26.Text = "Apellido Materno";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label27.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(234, 66);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(55, 16);
            this.label27.TabIndex = 111;
            this.label27.Text = "Telefono";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label28.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(234, 9);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(43, 16);
            this.label28.TabIndex = 110;
            this.label28.Text = "Correo";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label29.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(13, 259);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(32, 16);
            this.label29.TabIndex = 109;
            this.label29.Text = "Curp";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label30.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(13, 63);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(56, 16);
            this.label30.TabIndex = 108;
            this.label30.Text = "IdCliente";
            // 
            // dtpFechaP
            // 
            this.dtpFechaP.Enabled = false;
            this.dtpFechaP.Location = new System.Drawing.Point(369, 174);
            this.dtpFechaP.Name = "dtpFechaP";
            this.dtpFechaP.Size = new System.Drawing.Size(184, 23);
            this.dtpFechaP.TabIndex = 17;
            // 
            // cmbStatusP
            // 
            this.cmbStatusP.Enabled = false;
            this.cmbStatusP.FormattingEnabled = true;
            this.cmbStatusP.Items.AddRange(new object[] {
            "No Existente",
            "Existente"});
            this.cmbStatusP.Location = new System.Drawing.Point(370, 226);
            this.cmbStatusP.Name = "cmbStatusP";
            this.cmbStatusP.Size = new System.Drawing.Size(121, 23);
            this.cmbStatusP.TabIndex = 18;
            this.cmbStatusP.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbStatusP_KeyPress);
            // 
            // txtAnticipoP
            // 
            this.txtAnticipoP.Enabled = false;
            this.txtAnticipoP.Location = new System.Drawing.Point(370, 278);
            this.txtAnticipoP.MaxLength = 10;
            this.txtAnticipoP.Name = "txtAnticipoP";
            this.txtAnticipoP.Size = new System.Drawing.Size(100, 23);
            this.txtAnticipoP.TabIndex = 19;
            this.txtAnticipoP.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAnticipoP_KeyPress);
            // 
            // txtDescripcionP
            // 
            this.txtDescripcionP.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtDescripcionP.Enabled = false;
            this.txtDescripcionP.Location = new System.Drawing.Point(369, 125);
            this.txtDescripcionP.MaxLength = 45;
            this.txtDescripcionP.Name = "txtDescripcionP";
            this.txtDescripcionP.Size = new System.Drawing.Size(100, 23);
            this.txtDescripcionP.TabIndex = 16;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label5.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(366, 259);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 16);
            this.label5.TabIndex = 103;
            this.label5.Text = "Anticipo";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label4.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(367, 207);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(43, 16);
            this.label4.TabIndex = 102;
            this.label4.Text = "Status";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label3.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(366, 153);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(101, 16);
            this.label3.TabIndex = 101;
            this.label3.Text = "Fecha De Pedidos";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label2.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(366, 103);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 16);
            this.label2.TabIndex = 93;
            this.label2.Text = "Descripcion";
            // 
            // dgvListaP
            // 
            this.dgvListaP.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.dgvListaP.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvListaP.Location = new System.Drawing.Point(26, 359);
            this.dgvListaP.Name = "dgvListaP";
            this.dgvListaP.Size = new System.Drawing.Size(444, 83);
            this.dgvListaP.TabIndex = 92;
            // 
            // txtIdPedidosP
            // 
            this.txtIdPedidosP.Enabled = false;
            this.txtIdPedidosP.Location = new System.Drawing.Point(369, 72);
            this.txtIdPedidosP.MaxLength = 10;
            this.txtIdPedidosP.Name = "txtIdPedidosP";
            this.txtIdPedidosP.Size = new System.Drawing.Size(100, 23);
            this.txtIdPedidosP.TabIndex = 15;
            this.txtIdPedidosP.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIdPedidosP_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(367, 53);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 16);
            this.label1.TabIndex = 89;
            this.label1.Text = "Id Pedidos";
            // 
            // ptbFotoP
            // 
            this.ptbFotoP.Image = global::frmReposteria.Properties.Resources.imagen;
            this.ptbFotoP.Location = new System.Drawing.Point(559, 189);
            this.ptbFotoP.Name = "ptbFotoP";
            this.ptbFotoP.Size = new System.Drawing.Size(100, 135);
            this.ptbFotoP.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ptbFotoP.TabIndex = 134;
            this.ptbFotoP.TabStop = false;
            // 
            // btnBuscarP
            // 
            this.btnBuscarP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnBuscarP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBuscarP.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscarP.Image = global::frmReposteria.Properties.Resources.buscar;
            this.btnBuscarP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBuscarP.Location = new System.Drawing.Point(131, 23);
            this.btnBuscarP.Name = "btnBuscarP";
            this.btnBuscarP.Size = new System.Drawing.Size(75, 32);
            this.btnBuscarP.TabIndex = 22;
            this.btnBuscarP.Text = "Buscar";
            this.btnBuscarP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBuscarP.UseVisualStyleBackColor = false;
            this.btnBuscarP.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnSalirP
            // 
            this.btnSalirP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnSalirP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSalirP.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalirP.Image = global::frmReposteria.Properties.Resources.salir_3;
            this.btnSalirP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSalirP.Location = new System.Drawing.Point(191, 321);
            this.btnSalirP.Name = "btnSalirP";
            this.btnSalirP.Size = new System.Drawing.Size(60, 32);
            this.btnSalirP.TabIndex = 27;
            this.btnSalirP.Text = "Salir";
            this.btnSalirP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSalirP.UseVisualStyleBackColor = false;
            this.btnSalirP.Click += new System.EventHandler(this.btnSalirP_Click_1);
            // 
            // btnCancelarP
            // 
            this.btnCancelarP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnCancelarP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCancelarP.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelarP.Image = global::frmReposteria.Properties.Resources.prohibido__1_;
            this.btnCancelarP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCancelarP.Location = new System.Drawing.Point(107, 321);
            this.btnCancelarP.Name = "btnCancelarP";
            this.btnCancelarP.Size = new System.Drawing.Size(78, 32);
            this.btnCancelarP.TabIndex = 26;
            this.btnCancelarP.Text = "Cancelar";
            this.btnCancelarP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCancelarP.UseVisualStyleBackColor = false;
            this.btnCancelarP.Click += new System.EventHandler(this.btnCancelarP_Click_1);
            // 
            // btnLimpiarP
            // 
            this.btnLimpiarP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnLimpiarP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnLimpiarP.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpiarP.Image = global::frmReposteria.Properties.Resources.escoba_de_limpieza_para_suelos__1_;
            this.btnLimpiarP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLimpiarP.Location = new System.Drawing.Point(26, 321);
            this.btnLimpiarP.Name = "btnLimpiarP";
            this.btnLimpiarP.Size = new System.Drawing.Size(75, 32);
            this.btnLimpiarP.TabIndex = 24;
            this.btnLimpiarP.Text = "Limpiar";
            this.btnLimpiarP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLimpiarP.UseVisualStyleBackColor = false;
            this.btnLimpiarP.Click += new System.EventHandler(this.btnLimpiarP_Click_1);
            // 
            // btnBorrarP
            // 
            this.btnBorrarP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnBorrarP.Enabled = false;
            this.btnBorrarP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBorrarP.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBorrarP.Image = global::frmReposteria.Properties.Resources.cubo_de_basura;
            this.btnBorrarP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBorrarP.Location = new System.Drawing.Point(590, 126);
            this.btnBorrarP.Name = "btnBorrarP";
            this.btnBorrarP.Size = new System.Drawing.Size(69, 31);
            this.btnBorrarP.TabIndex = 25;
            this.btnBorrarP.Text = "Borrar";
            this.btnBorrarP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBorrarP.UseVisualStyleBackColor = false;
            this.btnBorrarP.Click += new System.EventHandler(this.btnBorrarP_Click_1);
            // 
            // btnModificarP
            // 
            this.btnModificarP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnModificarP.Enabled = false;
            this.btnModificarP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnModificarP.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnModificarP.Image = global::frmReposteria.Properties.Resources.herramientas_del_empleado_de_mantenimiento;
            this.btnModificarP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnModificarP.Location = new System.Drawing.Point(571, 88);
            this.btnModificarP.Name = "btnModificarP";
            this.btnModificarP.Size = new System.Drawing.Size(88, 32);
            this.btnModificarP.TabIndex = 23;
            this.btnModificarP.Text = "Modificar";
            this.btnModificarP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnModificarP.UseVisualStyleBackColor = false;
            this.btnModificarP.Click += new System.EventHandler(this.btnModificarP_Click_1);
            // 
            // btnGuardarP
            // 
            this.btnGuardarP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnGuardarP.Enabled = false;
            this.btnGuardarP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnGuardarP.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGuardarP.Image = global::frmReposteria.Properties.Resources.guardar2;
            this.btnGuardarP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGuardarP.Location = new System.Drawing.Point(574, 45);
            this.btnGuardarP.Name = "btnGuardarP";
            this.btnGuardarP.Size = new System.Drawing.Size(85, 37);
            this.btnGuardarP.TabIndex = 21;
            this.btnGuardarP.Text = "Guardar";
            this.btnGuardarP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnGuardarP.UseVisualStyleBackColor = false;
            this.btnGuardarP.Click += new System.EventHandler(this.btnGuardarP_Click_1);
            // 
            // btnNuevoP
            // 
            this.btnNuevoP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnNuevoP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNuevoP.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNuevoP.Image = global::frmReposteria.Properties.Resources.agregar_usuario;
            this.btnNuevoP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNuevoP.Location = new System.Drawing.Point(590, 10);
            this.btnNuevoP.Name = "btnNuevoP";
            this.btnNuevoP.Size = new System.Drawing.Size(69, 29);
            this.btnNuevoP.TabIndex = 1;
            this.btnNuevoP.Text = "Nuevo";
            this.btnNuevoP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNuevoP.UseVisualStyleBackColor = false;
            this.btnNuevoP.Click += new System.EventHandler(this.btnNuevoP_Click);
            // 
            // frmCliPe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(743, 502);
            this.Controls.Add(this.Cliente);
            this.Name = "frmCliPe";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Clientes";
            this.Cliente.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptbFotoC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbgListaC)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptbFotoP)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl Cliente;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox txtCurpC;
        private System.Windows.Forms.Button btnBuscarC;
        private System.Windows.Forms.ComboBox cmbStatusC;
        private System.Windows.Forms.Button btnCancelarC;
        private System.Windows.Forms.Button btnLimpiarC;
        private System.Windows.Forms.Button btnCerrarC;
        private System.Windows.Forms.Button btnBorrarC;
        private System.Windows.Forms.Button btnModificarC;
        private System.Windows.Forms.Button btnGuardarC;
        private System.Windows.Forms.Button btnNuevoC;
        private System.Windows.Forms.DataGridView dbgListaC;
        private System.Windows.Forms.TextBox txtCodigoPostC;
        private System.Windows.Forms.TextBox txtNumeroC;
        private System.Windows.Forms.TextBox txtCalleC;
        private System.Windows.Forms.TextBox txtColoniaC;
        private System.Windows.Forms.TextBox txtApellidoPatC;
        private System.Windows.Forms.TextBox txtApellidoMatC;
        private System.Windows.Forms.TextBox txtTelefonoC;
        private System.Windows.Forms.TextBox txtCorreoC;
        private System.Windows.Forms.TextBox txtNombreC;
        private System.Windows.Forms.TextBox txtIdClienteC;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button btnFotoC;
        private System.Windows.Forms.PictureBox ptbFotoC;
        private System.Windows.Forms.TextBox txtFotoC;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.PictureBox ptbFotoP;
        private System.Windows.Forms.Button btnFotoP;
        private System.Windows.Forms.TextBox txtCurpP;
        private System.Windows.Forms.ComboBox cmbStatusCP;
        private System.Windows.Forms.TextBox txtCodigoPostP;
        private System.Windows.Forms.TextBox txtNumeroP;
        private System.Windows.Forms.TextBox txtCalleP;
        private System.Windows.Forms.TextBox txtColoniaP;
        private System.Windows.Forms.TextBox txtApellidoPatP;
        private System.Windows.Forms.TextBox txtApellidoMatP;
        private System.Windows.Forms.TextBox txtTelefonoP;
        private System.Windows.Forms.TextBox txtCorreoP;
        private System.Windows.Forms.TextBox txtNombreP;
        private System.Windows.Forms.TextBox txtIdClienteP;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.DateTimePicker dtpFechaP;
        private System.Windows.Forms.ComboBox cmbStatusP;
        private System.Windows.Forms.TextBox txtAnticipoP;
        private System.Windows.Forms.TextBox txtDescripcionP;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dgvListaP;
        private System.Windows.Forms.TextBox txtIdPedidosP;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnBuscarP;
        private System.Windows.Forms.Button btnSalirP;
        private System.Windows.Forms.Button btnCancelarP;
        private System.Windows.Forms.Button btnLimpiarP;
        private System.Windows.Forms.Button btnBorrarP;
        private System.Windows.Forms.Button btnModificarP;
        private System.Windows.Forms.Button btnGuardarP;
        private System.Windows.Forms.Button btnNuevoP;
        private System.Windows.Forms.TextBox txtFotoP;
        private System.Windows.Forms.TextBox txtClaveC;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox txtClaveP;
        private System.Windows.Forms.Label label32;
    }
}