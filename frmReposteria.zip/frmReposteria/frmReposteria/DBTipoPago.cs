﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;
namespace frmReposteria
{
    class DBTipoPago
    {
        private MySqlConnection conexion;
        private string strConexion;
        private MySqlCommand sqlComando;
        private string strConsulta;
        private MySqlDataAdapter adaptador;

        public DBTipoPago()
        {
            //Constructor
            conexion = new MySqlConnection();
            strConexion = "Server=localHost;User=root;DataBase=bdreposteria;port=3306;Password=";

            conexion.ConnectionString = strConexion;

            sqlComando = new MySqlCommand();
            adaptador = new MySqlDataAdapter();

        }
        public Boolean abrir()
        {
            Boolean exito = false;

            if (conexion.State == System.Data.ConnectionState.Closed)
            {

                conexion.Open();
                exito = true;

            }



            return exito;
        }
        public Boolean Cerrar()
        {
            Boolean exito = false;

            if (conexion.State == System.Data.ConnectionState.Closed)
            {

                exito = false;
            }
            else
            {
                conexion.Close();
                exito = true;
            }
            return exito;
        }
        // public Boolean Cerrar()
        // {
        //    Boolean exito = false;
        //    if (conexion.State == ConnectionState.Closed)
        //    {
        //    conexion.Close();
        //   exito = true;
        // }
        // return exito;
        // }


        //Agregar sin parametros
        public void agregarSinParsametros(TipoPago obj)
        {
            string sqlConsulta = "insert into ttipopago(idtipopago,clave,descripcion,status) values (null," + obj.Clave + "," + obj.Descripcion + ",0)";
            this.abrir();
            sqlComando.Connection = conexion;
            sqlComando.CommandText = sqlConsulta;

            sqlComando.ExecuteNonQuery();
            this.Cerrar();
        }
        //Agregar usando parametros
        public void agregarUsandoParametros(TipoPago obj)
        {
            string sqlConsulta = "insert into ttipopago (idtipopago,clave,descripcion,status)values(null, ?pclave, ?pdescripcion,0)";
            sqlComando.Parameters.Clear();

            sqlComando.Parameters.Add("?pclave", MySql.Data.MySqlClient.MySqlDbType.Int32).Value = obj.Clave;
            sqlComando.Parameters.Add("?pdescripcion", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Descripcion;
            this.abrir();
            sqlComando.Connection = conexion;
            sqlComando.CommandText = sqlConsulta;

            sqlComando.ExecuteNonQuery();
            this.Cerrar();

        }
        //Actualizar
        public void Actualizar(TipoPago obj)
        {
            string sqlConsulta = "Update ttipopago set descripcion = ?pdescripcion where clave= ?pclave and status=0";
            sqlComando.Parameters.Clear();

            sqlComando.Parameters.Add("?pclave", MySql.Data.MySqlClient.MySqlDbType.UInt32).Value = obj.Clave;

            sqlComando.Parameters.Add("?pdescripcion", MySql.Data.MySqlClient.MySqlDbType.VarChar).Value = obj.Descripcion;
            this.abrir();
            sqlComando.Connection = conexion;
            sqlComando.CommandText = sqlConsulta;

            sqlComando.ExecuteNonQuery();
            this.Cerrar();
        }
        //Deshabilitar
        public void Deshabilitar(TipoPago obj)
        {
            string sqlConsulta = "update ttipoPago set status=1 where clave= ?pclave and status=0";
            sqlComando.Parameters.Clear();

            sqlComando.Parameters.Add("?pclave", MySql.Data.MySqlClient.MySqlDbType.Int32).Value = obj.Clave;

            this.abrir();
            sqlComando.Connection = conexion;
            sqlComando.CommandText = sqlConsulta;

            sqlComando.ExecuteNonQuery();
            this.Cerrar();
        }
        //Consultar
        public DataTable Consultar(int Clave)
        {
            DataTable datos = new DataTable();
            strConsulta = "select *from ttipopago where status = 0 and clave =" + Clave;

            this.abrir();
            sqlComando.CommandText = strConsulta;
            sqlComando.Connection = conexion;
            adaptador.SelectCommand = sqlComando;
            adaptador.Fill(datos);

            this.Cerrar();

            return datos;
        }
        //Metodo consultar todos
        public DataTable ConsultarTodos4()
        {
            DataTable datos = new DataTable();
            strConsulta = "select *from ttipopago where status = 0 order by clave asc";
            abrir();
            sqlComando.CommandText = strConsulta;
            sqlComando.Connection = conexion;

            adaptador.SelectCommand = sqlComando;
            adaptador.Fill(datos);
            this.Cerrar();
            return datos;
        }
        public DataTable ConsultarTodosDeshabilitar()
        {
            DataTable datos = new DataTable();
            strConsulta = "select *from ttipopago where status = 1 order by clave asc";
            abrir();
            sqlComando.CommandText = strConsulta;
            sqlComando.Connection = conexion;

            adaptador.SelectCommand = sqlComando;
            adaptador.Fill(datos);
            Cerrar();
            return datos;
        }
        public void Habilitar(TipoPago obj)
        {
            string sqlConsulta = "update ttipopago set status=0 where clave = ?pclave and status = 1";
            sqlComando.Parameters.Clear();

            sqlComando.Parameters.Add("?pclave", MySql.Data.MySqlClient.MySqlDbType.Int32).Value = obj.Clave;

            this.abrir();
            sqlComando.Connection = conexion;
            sqlComando.CommandText = sqlConsulta;

            sqlComando.ExecuteNonQuery();
            this.Cerrar();
        }
        public DataTable ConsultarH(int Clave)
        {
            DataTable datos = new DataTable();
            strConsulta = "select * from ttipopago where status = 1 and clave =" + Clave;

            this.abrir();
            sqlComando.CommandText = strConsulta;
            sqlComando.Connection = conexion;
            adaptador.SelectCommand = sqlComando;
            adaptador.Fill(datos);

            this.Cerrar();

            return datos;
        }
    }
}
