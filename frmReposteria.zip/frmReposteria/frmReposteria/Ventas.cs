﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace frmReposteria
{
    class Ventas
    {
        private int folioVenta;
     
        private string fechaVenta;
        private string empleado;
        private string cliente;
        private string tipoPago;
        private string producto;
      //  private float precioVenta;
        //private float precioCompra;
      //  private int codigo;
       // private float totalVenta;
        //private float totalCompra;
        //private float utilidad;


        public Ventas()
        {
            this.folioVenta = 0;
            this.fechaVenta = ""; 
            this.empleado = "";
            this.cliente = "";
            this.tipoPago = "";
       //     this.codigo = 0;

         //   this.precioVenta = 0.0f;
           // this.precioCompra = 0.0f;
            //this.producto = "";

           // this.totalVenta = 0.0f;
           // this.totalCompra = 0.0f;
           // this.utilidad = 0.0f;

        }
        public Ventas(int folioVenta, string fechaVenta, string empleado, string cliente, string tipoPago, string producto)
        {
            this.folioVenta =folioVenta;
            this.fechaVenta = fechaVenta;
            this.empleado = empleado;
            this.cliente = cliente;
            this.tipoPago = tipoPago;
           
            this.producto = producto;
          

        }
        
        public int FolioVenta
        {
            set { this.folioVenta = value; }
            get { return this.folioVenta; }
        }
       
        public string FechaVenta
        {
            set { this.fechaVenta = value; }
            get { return this.fechaVenta; }
        }
        public string Empleado
        {
            set { this.empleado = value; }
            get { return this.empleado; }
        }
        public string Cliente
        {
            set { this.cliente = value; }
            get { return this.cliente; }
        }
        public string TipoPago
        {
            set { this.tipoPago = value; }
            get { return this.tipoPago; }
        }
      
    }
}
