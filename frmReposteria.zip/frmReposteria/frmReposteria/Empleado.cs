﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace frmReposteria
{
    class Empleado
    {
        private int idEmpleado;
        private string nombre;
        private string aPaterno;
        private string aMaterno;
        private string curp;
        private string fecNac;
        private string telefono;
        private string colonia;
        private string calle;
        private int numero;
        private string foto;
        private int clave;
        private int status;

        public Empleado()
        {
            //constructor por omisio
            idEmpleado = this.generaEmpleado();
            this.nombre = "";
            this.aPaterno = "";
            this.aMaterno = "";
            this.curp = "";
            this.fecNac = "";
            this.telefono = "";
            this.colonia = "";
            this.calle = "";
            this.numero = 0;
            this.foto = "";
            clave = this.generaEmpleado2();
            this.status = 0;
        }
        public Empleado(int idEmpleado, string nombre, string aPaterno, string aMaterno,  string curp,string fecNac, string telefono, string colonia, string calle, int numero, string foto, int clave, int status)

        {
            //constructor por argumentos
            this.idEmpleado = idEmpleado;
            this.nombre = nombre;
            this.aPaterno = aPaterno;
            this.aMaterno = aMaterno;
            this.curp = curp;
            this.fecNac = fecNac;
            this.telefono = telefono;
            this.colonia = colonia;
            this.calle = calle;
            this.numero = numero;
            this.foto = foto;
            this.clave = clave;
            this.status = status;
        }
        public Empleado(Empleado A)
        {
            //constructor por pago
            this.idEmpleado = A.idEmpleado;
            this.nombre = A.nombre;
            this.aPaterno = A.aPaterno;
            this.aMaterno = A.aMaterno;
            this.curp = A.curp;
            this.fecNac = A.fecNac;
            this.telefono = A.telefono;
            this.colonia = A.colonia;
            this.calle = A.calle;
            this.numero = A.numero;
            this.foto = A.foto;
            this.clave = A.clave;
            this.status = A.status;
        }
        public int Clave
        {
            set { this.clave = value; }
            get { return this.clave; }
        }
        
        public int IdEmpleado
        {
            set { this.idEmpleado = value; }
            get { return this.idEmpleado; }
        }
        public string Curp
        {
            set { this.curp = value; }
            get { return this.curp; }
        }
        public string Nombre
        {
            set { this.nombre = value; }
            get { return this.nombre; }
        }
        public string APaterno
        {
            set { this.aPaterno = value; }
            get { return this.aPaterno; }
        }
        public string AMaterno
        {
            set { this.aMaterno = value; }
            get { return this.aMaterno; }
        }
        
        
        public string FecNac
        {
            set { this.fecNac = value; }
            get { return this.fecNac; }
        }
        public string Telefono
        {
            set { this.telefono = value; }
            get { return this.telefono; }
        }
        public string Colonia
        {
            set { this.colonia = value; }
            get { return this.colonia; }
        }
        public string Calle
        {
            set { this.calle = value; }
            get { return this.calle; }
        }
        public int Numero
        {
            set { this.numero = value; }
            get { return this.numero; }
        }
        public string Foto
        {
            set { this.foto = value; }
            get { return this.foto; }
        }
        public int Status
        {
            set { this.status = value; }
            get { return this.status; }
        }
        public int generaEmpleado()
        {
            //genera valores aleatorios enteros positivos no mayores a 32000
            Random x = new Random();
            return x.Next(32000);
        }
        public int generaEmpleado2()
        {
            //genera valores aleatorios enteros positivos no mayores a 32000
            Random x = new Random();
            return x.Next(25000);
        }
    }
}
