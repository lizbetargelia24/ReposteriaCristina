﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmReposteria
{
    public partial class frmTipoProducto : Form
    {
        public frmTipoProducto()
        {
            InitializeComponent();
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {
           

        }

        private void btnNuevoTP_Click(object sender, EventArgs e)
        {
            btnGuardarTP.Enabled = true;








            txtClaveTP.Enabled = true;
         
            txtNombreTP.Enabled = true;
            btnFotoTP.Enabled = true;

        }

        private void btnGuardarTP_Click(object sender, EventArgs e)
        {
            Boolean exito = false;
            if (txtClaveTP.Text.Equals("")) { MessageBox.Show("Faltó Capturar la Clave", "Tipo Producto ♥"); exito = true; }
            if (txtFotoTP.Text.Equals("")) { MessageBox.Show("Faltó capturar la Foto", "Tipo Producto ♥"); exito = true; }
            if (txtNombreTP.Text.Equals("")) { MessageBox.Show("Faltó capturar el nombre", "Tipo Producto ♥"); exito = true; }
           


            if (exito == false)
            {
                DBTipoProdu miBase = new DBTipoProdu();
                if (txtClaveTP.Text == txtClaveTP.Text)
                {
                    DataTable data = miBase.Consultar(int.Parse(txtClaveTP.Text));
                    if (data.Rows.Count > 0)
                    {
                        MessageBox.Show("Ya existe la clave", "Tipo Producto ♥");
                    }
                    else
                    {


                        TipoProducto es = new TipoProducto();

                        es.Clave = int.Parse(txtClaveTP.Text);
                        es.Nombre = txtNombreTP.Text;
                      
                        es.Foto = txtFotoTP.Text;
                        ptbFotoTP.Image = Image.FromFile(txtFotoTP.Text);

                        miBase.agregarUsandoParametros(es);
                        MessageBox.Show("Se guardó con exito", "Tipo Producto ♥");

                        dgvListaTP.DataSource = null;

                        DataTable datos2 = miBase.ConsultarTodos();

                        dgvListaTP.DataSource = datos2;
                        txtClaveTP.Text = "";

                        txtNombreTP.Text = "";
                        txtStatusTP.Text = "";
                        txtFotoTP.Text = "";
                        ptbFotoTP.Image = frmReposteria.Properties.Resources.imagen5;

                    }
                }
                else
                {
                    MessageBox.Show("Faltó capturar la clave", "Tipo Producto ♥");
                    txtClaveTP.Focus();
                }
            }

        }

        private void btnModificarTP_Click(object sender, EventArgs e)
        {
            DBTipoProdu mibase = new DBTipoProdu();

            TipoProducto doc = new TipoProducto();

            txtStatusTP.Enabled = false;
            txtClaveTP.Enabled = false;
            doc.Clave = int.Parse(txtClaveTP.Text);
            doc.Nombre = txtNombreTP.Text;
        
            doc.Foto = txtFotoTP.Text;
            ptbFotoTP.Image = Image.FromFile(txtFotoTP.Text);
            mibase.Actualizar(doc);
            dgvListaTP.DataSource = null;
            DataTable datos2 = mibase.ConsultarTodos();
            dgvListaTP.DataSource = datos2;

            MessageBox.Show("Se ralizó la modificación con éxito", "Tipo Producto ♥");

        }

        private void btnBorrarTP_Click(object sender, EventArgs e)
        {
            DialogResult res = MessageBox.Show("¿deseas borrar el registro?", " Tipo Producto ♥",
       MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);

            if (res == DialogResult.Yes)
            {
                DBTipoProdu mibase = new DBTipoProdu();

                TipoProducto docc = new TipoProducto();

                docc.Clave = int.Parse(txtClaveTP.Text);
                docc.Nombre = txtNombreTP.Text;
            

                mibase.Deshabilitar(docc);

                txtClaveTP.Text = "";
             
                txtNombreTP.Text = "";
                txtStatusTP.Text = "";
                txtFotoTP.Text = "";

                ptbFotoTP.Image = frmReposteria.Properties.Resources.imagen5;
                txtClaveTP.Enabled = true;
                btnGuardarTP.Enabled = true;

                DBTipoProdu miBase = new DBTipoProdu();
                //Limpiar el DtaGriView
                dgvListaTP.DataSource = null;
                DataTable datos = miBase.ConsultarTodos();
                //Poner Los Datos de Consulta en el DataGriView 
                dgvListaTP.DataSource = datos;

                DBTipoProdu miBasee = new DBTipoProdu();
                //Limpiar el DtaGriView
                dgvListaTPO.DataSource = null;
                DataTable datoss = miBasee.ConsultarTodosDeshabilitar();
                //Poner Los Datos de Consulta en el DataGriView 

                dgvListaTPO.DataSource = datoss;
            }
        }

        private void btnFotoTP_Click(object sender, EventArgs e)
        {
            OpenFileDialog foto = new OpenFileDialog();
            foto.InitialDirectory = "C:\\";
            foto.ShowDialog();
            txtFotoTP.Text = foto.FileName;
            ptbFotoTP.ImageLocation = foto.FileName;
        }

        private void btnBuscarTP_Click(object sender, EventArgs e)
        {
            DBTipoProdu miBase = new DBTipoProdu();

            if (txtClaveTP.Text != "")
            {
                DataTable datos = miBase.Consultar(int.Parse(txtClaveTP.Text));
                if (datos.Rows.Count > 0)
                {
                    txtNombreTP.Text = datos.Rows[0]["nombre"].ToString();
                
                    txtStatusTP.Text = datos.Rows[0]["status"].ToString();
                    txtFotoTP.Text = datos.Rows[0]["foto"].ToString();
                    ptbFotoTP.Image = Image.FromFile(txtFotoTP.Text);
                    txtClaveTP.Enabled = false;
                    btnBorrarTP.Enabled = true;
                    btnModificarTP.Enabled = true;
                }
                else
                {
                    MessageBox.Show("No hay registro con esa Clave", "Tipo Producto ♥");
                }

            }

            else
            {
                MessageBox.Show("Faltó capturar la Clave", "Tipo Producto ♥");
                txtClaveTP.Focus();
            }

        }

        private void btnLimpiarTP_Click(object sender, EventArgs e)
        {
            txtClaveTP.Text = "";
           
            txtNombreTP.Text = "";
            txtStatusTP.Text = "";
            txtFotoTP.Text = "";
            ptbFotoTP.Image = frmReposteria.Properties.Resources.imagen5;
            txtNombreTP.Enabled = false;
            btnGuardarTP.Enabled = false;
            btnModificarTP.Enabled = false;
            btnBorrarTP.Enabled = false;
            txtClaveTP.Enabled = true;
            txtStatusTP.Enabled = false;
            btnBuscarTP.Enabled = true;
           

        }

        private void btnCancelarTP_Click(object sender, EventArgs e)
        {
            txtClaveTP.Text = "";
           
            txtNombreTP.Text = "";
            txtStatusTP.Text = "";
            txtFotoTP.Text = "";
            ptbFotoTP.Image = frmReposteria.Properties.Resources.imagen5;
            txtNombreTP.Enabled = false;
            btnGuardarTP.Enabled = false;
            btnModificarTP.Enabled = false;
            btnBorrarTP.Enabled = false;
           
            txtClaveTP.Enabled = false;
            txtStatusTP.Enabled = false;
            btnBuscarTP.Enabled = true;

        }

        private void btnnCerrarTP_Click(object sender, EventArgs e)
        {
            DialogResult tipo;
            tipo = MessageBox.Show("¿Deseas Salir?", "Tipo Producto ♥",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question,
                MessageBoxDefaultButton.Button2);
            if (tipo == DialogResult.Yes) this.Close();

        }

        private void txtClaveTP_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }

        }

        private void cmbTipoTP_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }

        }

        private void frmTipoProducto_Load(object sender, EventArgs e)
        {
            DBTipoProdu miBase = new DBTipoProdu();
            DataTable datos = miBase.ConsultarTodos();
            dgvListaTP.DataSource = datos;

       


            DBTipoProdu miBasee = new DBTipoProdu();
            //Limpiar el DtaGriView
            DataTable datoss = miBasee.ConsultarTodosDeshabilitar();
            //Poner Los Datos de Consulta en el DataGriView 
            dgvListaTPO.DataSource = datoss;
           

        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void btnBuscarTPO_Click(object sender, EventArgs e)
        {
            DBTipoProdu miBase = new DBTipoProdu();

            if (txtClaveTPO.Text != "")
            {
                DataTable datos = miBase.ConsultarH(int.Parse(txtClaveTPO.Text));
                if (datos.Rows.Count > 0)
                {
                    txtNombreTPO.Text = datos.Rows[0]["nombre"].ToString();
                    cmbTipoTPO.Text = datos.Rows[0]["tipoProducto"].ToString();
                    txtStatusTPO.Text = datos.Rows[0]["status"].ToString();
                    txtFotoTPO.Text = datos.Rows[0]["foto"].ToString();
                    ptbFotoTPO.Image = Image.FromFile(txtFotoTPO.Text);
                    txtClaveTPO.Enabled = false;
                   
                }
                else
                {
                    MessageBox.Show("No hay registro con ese Código", "Tipo Producto ♥");
                }

            }

            else
            {
                MessageBox.Show("Faltó capturar el Codigo", "Tipo Producto ♥");
                txtClaveTPO.Focus();
            }
        }

        private void btnLimpiarTPO_Click(object sender, EventArgs e)
        {
            txtClaveTPO.Text = "";
            cmbTipoTPO.Text = "";
            txtNombreTPO.Text = "";
            txtStatusTPO.Text = "";
            txtFotoTPO.Text = "";
            ptbFotoTPO.Image = frmReposteria.Properties.Resources.imagen5;
            txtNombreTPO.Enabled = false;
           
           
            txtClaveTPO.Enabled = true;
            txtStatusTPO.Enabled = false;
            btnBuscarTPO.Enabled = true;
        }

        private void btnCancelarTPO_Click(object sender, EventArgs e)
        {
            txtClaveTPO.Text = "";
            cmbTipoTPO.Text = "";
            txtNombreTPO.Text = "";
            txtStatusTPO.Text = "";
            txtFotoTPO.Text = "";
            ptbFotoTPO.Image = frmReposteria.Properties.Resources.imagen5;
            txtNombreTPO.Enabled = false;


            txtClaveTPO.Enabled = false;
            txtStatusTPO.Enabled = false;
            btnBuscarTPO.Enabled = true;
        }

        private void btnSalirTPO_Click(object sender, EventArgs e)
        {
            DialogResult tipo;
            tipo = MessageBox.Show("¿Deseas Salir?", "Tipo Producto ♥",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question,
                MessageBoxDefaultButton.Button2);
            if (tipo == DialogResult.Yes) this.Close();
        }

        private void btnHabilitarTPO_Click(object sender, EventArgs e)
        {
            DBTipoProdu mibase = new DBTipoProdu();

            TipoProducto docc = new TipoProducto();

            docc.Clave = int.Parse(txtClaveTPO.Text);
            docc.Nombre = txtNombreTPO.Text;
            docc.TipoDProducto = cmbTipoTPO.Text;

            mibase.Habilitar(docc);

            txtClaveTPO.Text = "";
            cmbTipoTPO.Text = "";
            txtNombreTPO.Text = "";
            txtStatusTPO.Text = "";
            txtFotoTPO.Text = "";

            ptbFotoTPO.Image = frmReposteria.Properties.Resources.imagen5;
            txtClaveTPO.Enabled = true;
          

            DBTipoProdu miBase = new DBTipoProdu();
            //Limpiar el DtaGriView
            dgvListaTP.DataSource = null;
            DataTable datos = miBase.ConsultarTodos();
            //Poner Los Datos de Consulta en el DataGriView 
            dgvListaTP.DataSource = datos;

            DBTipoProdu miBasee = new DBTipoProdu();
            //Limpiar el DtaGriView
            dgvListaTPO.DataSource = null;
            DataTable datoss = miBasee.ConsultarTodosDeshabilitar();
            //Poner Los Datos de Consulta en el DataGriView 

            dgvListaTPO.DataSource = datoss;
        }

        private void btnNuevoTPO_Click(object sender, EventArgs e)
        {
            txtClaveTPO.Enabled = true;
        }

        private void txtClaveTPO_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }

        }

        private void cmbTipoTPO_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }

        }

        private void cmbTipoTP_SelectedIndexChanged(object sender, EventArgs e)
        {
          
        }

        private void dgvListaTP_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
