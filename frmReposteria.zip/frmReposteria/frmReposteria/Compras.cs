﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace frmReposteria
{
    class Compras
    {
       
            private int folioCompra;
            private string empleado;
            private string tienda;
            private string tipoPago;
            private string fechaCompra;

    //    private int codigo;
     //   private float precioVenta;
     //   private float precioCompra;
     //   private string producto;
     //   private float totalVenta;
     //   private float totalCompra;
     //   private float utilidad;



        public Compras()
            {

                this.folioCompra = 0;
                this.fechaCompra = "";
                this.empleado = "";
                this.tienda = "";
                this.tipoPago = "";
     //       this.precioVenta = 0.0f;
       //     this.precioCompra = 0.0f;
        // this.producto = "";
           // this.totalVenta = 0.0f;
           // this.totalCompra = 0.0f;
            //this.utilidad = 0.0f;
            //this.codigo = 0;

        }
            public Compras(int folioCompra, string fechaCompra,  string empleado, string tienda, string tipoPago)
            {

                this.folioCompra = folioCompra;
                this.fechaCompra = fechaCompra;
                this.empleado = empleado;
                this.tienda = tienda;
                this.tipoPago = tipoPago;
           
          


        }

            public int FolioCompra
            {
                set { this.folioCompra = value; }
                get { return this.folioCompra; }
            }
          
            public string FechaCompra
            {
                set { this.fechaCompra = value; }
                get { return this.fechaCompra; }
            }
          
           
            public string Empleado
            {
                set { this.empleado = value; }
                get { return this.empleado; }
            }
            public string Tienda
            {
                set { this.tienda = value; }
                get { return this.tienda; }
            }
            public string TipoPago
            {
                set { this.tipoPago = value; }
                get { return this.tipoPago; }
            }

     
    }
}
